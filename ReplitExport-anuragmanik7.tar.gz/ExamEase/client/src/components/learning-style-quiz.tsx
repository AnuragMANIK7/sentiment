import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import { BookOpen, Brain, CheckCircle2 } from "lucide-react";

interface LearningStyleQuizProps {
  onComplete: (results: LearningStyleResult) => void;
}

interface LearningStyleResult {
  primaryStyle: string;
  styleScores: Record<string, number>;
  recommendations: string[];
  studyTechniques: string[];
}

const questions = [
  {
    id: 1,
    question: "When learning about Indian History, you prefer to:",
    options: [
      { text: "Read detailed textbooks and make notes", style: "visual", points: 3 },
      { text: "Listen to lectures or audio content", style: "auditory", points: 3 },
      { text: "Create timelines and practice writing", style: "kinesthetic", points: 3 },
      { text: "Discuss with peers and teach others", style: "social", points: 3 }
    ]
  },
  {
    id: 2,
    question: "For Current Affairs preparation, you find it most effective to:",
    options: [
      { text: "Read newspapers and highlight key points", style: "visual", points: 3 },
      { text: "Watch news debates and discussions", style: "auditory", points: 3 },
      { text: "Make summary notes and mind maps", style: "kinesthetic", points: 3 },
      { text: "Join study groups for news analysis", style: "social", points: 3 }
    ]
  },
  {
    id: 3,
    question: "When studying Geography, you learn best by:",
    options: [
      { text: "Looking at maps, charts, and diagrams", style: "visual", points: 3 },
      { text: "Listening to explanations of concepts", style: "auditory", points: 3 },
      { text: "Drawing maps and practicing diagrams", style: "kinesthetic", points: 3 },
      { text: "Explaining locations to study partners", style: "social", points: 3 }
    ]
  },
  {
    id: 4,
    question: "For Essay writing practice, you prefer to:",
    options: [
      { text: "Read sample essays and analyze structure", style: "visual", points: 3 },
      { text: "Listen to expert discussions on topics", style: "auditory", points: 3 },
      { text: "Practice writing regularly with timers", style: "kinesthetic", points: 3 },
      { text: "Brainstorm ideas with fellow aspirants", style: "social", points: 3 }
    ]
  },
  {
    id: 5,
    question: "When preparing for interviews, you feel most confident after:",
    options: [
      { text: "Reading about various topics extensively", style: "visual", points: 3 },
      { text: "Listening to mock interview recordings", style: "auditory", points: 3 },
      { text: "Practicing answers out loud regularly", style: "kinesthetic", points: 3 },
      { text: "Having mock interviews with others", style: "social", points: 3 }
    ]
  },
  {
    id: 6,
    question: "Your ideal study environment includes:",
    options: [
      { text: "Good lighting, organized notes, and visual aids", style: "visual", points: 2 },
      { text: "Quiet space for listening to audio content", style: "auditory", points: 2 },
      { text: "Space to move around and write freely", style: "kinesthetic", points: 2 },
      { text: "Area where you can discuss with others", style: "social", points: 2 }
    ]
  },
  {
    id: 7,
    question: "When you encounter a difficult concept, you:",
    options: [
      { text: "Look for diagrams or visual explanations", style: "visual", points: 2 },
      { text: "Find audio explanations or lectures", style: "auditory", points: 2 },
      { text: "Try to solve related problems", style: "kinesthetic", points: 2 },
      { text: "Ask someone to explain it to you", style: "social", points: 2 }
    ]
  },
  {
    id: 8,
    question: "Your memory works best when you:",
    options: [
      { text: "Associate information with visual images", style: "visual", points: 2 },
      { text: "Repeat information verbally", style: "auditory", points: 2 },
      { text: "Write and rewrite key points", style: "kinesthetic", points: 2 },
      { text: "Explain concepts to others", style: "social", points: 2 }
    ]
  }
];

const learningStyleDescriptions: Record<string, {
  title: string;
  description: string;
  techniques: string[];
}> = {
  visual: {
    title: "Visual Learner",
    description: "You learn best through seeing and visual aids",
    techniques: [
      "Use highlighters and color coding",
      "Create mind maps and flowcharts", 
      "Make visual timelines for history",
      "Use diagrams for geography",
      "Watch educational videos"
    ]
  },
  auditory: {
    title: "Auditory Learner", 
    description: "You learn best through listening and verbal instruction",
    techniques: [
      "Listen to educational podcasts",
      "Record yourself reading notes",
      "Join discussion groups",
      "Use mnemonics and rhymes",
      "Attend live lectures"
    ]
  },
  kinesthetic: {
    title: "Kinesthetic Learner",
    description: "You learn best through hands-on practice and movement", 
    techniques: [
      "Take frequent breaks to move",
      "Practice answer writing daily",
      "Use flashcards and active recall",
      "Make physical models of concepts",
      "Study while walking"
    ]
  },
  social: {
    title: "Social Learner",
    description: "You learn best through interaction and collaboration",
    techniques: [
      "Form study groups",
      "Teach concepts to others", 
      "Join online forums",
      "Participate in group discussions",
      "Find a study partner"
    ]
  }
};

export default function LearningStyleQuiz({ onComplete }: LearningStyleQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState<LearningStyleResult | null>(null);

  const handleAnswer = () => {
    if (!selectedOption) return;
    
    setAnswers(prev => ({
      ...prev,
      [questions[currentQuestion].id]: selectedOption
    }));
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setSelectedOption("");
    } else {
      calculateResults();
    }
  };

  const calculateResults = () => {
    const styleScores: Record<string, number> = { visual: 0, auditory: 0, kinesthetic: 0, social: 0 };
    
    // Calculate scores based on answers
    Object.entries(answers).forEach(([questionId, optionText]) => {
      const question = questions.find(q => q.id === parseInt(questionId));
      const option = question?.options.find(opt => opt.text === optionText);
      if (option && option.style in styleScores) {
        styleScores[option.style] += option.points;
      }
    });

    // Add current question answer
    const currentOption = questions[currentQuestion].options.find(opt => opt.text === selectedOption);
    if (currentOption && currentOption.style in styleScores) {
      styleScores[currentOption.style] += currentOption.points;
    }

    // Find primary learning style
    const primaryStyle = Object.entries(styleScores).reduce((a, b) => 
      styleScores[a[0]] > styleScores[b[0]] ? a : b
    )[0];

    const styleInfo = learningStyleDescriptions[primaryStyle as keyof typeof learningStyleDescriptions];
    
    const quizResults: LearningStyleResult = {
      primaryStyle,
      styleScores,
      recommendations: [
        `As a ${styleInfo.title.toLowerCase()}, focus on ${styleInfo.description.toLowerCase()}`,
        "Combine your primary style with secondary techniques for best results",
        "Regular practice and revision are key regardless of learning style",
        "Adapt your environment to support your learning preferences"
      ],
      studyTechniques: styleInfo.techniques
    };

    setResults(quizResults);
    setShowResults(true);
    onComplete(quizResults);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setSelectedOption("");
    setShowResults(false);
    setResults(null);
  };

  if (showResults && results) {
    const maxScore = Math.max(...Object.values(results.styleScores));
    
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-600" />
            Your Learning Style Results
          </CardTitle>
          <CardDescription>
            Personalized study recommendations for UPSC preparation
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Primary Learning Style */}
          <div className="text-center p-4 bg-primary/10 rounded-lg">
            <h3 className="text-lg font-semibold text-primary">
              {learningStyleDescriptions[results.primaryStyle].title}
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              {learningStyleDescriptions[results.primaryStyle].description}
            </p>
          </div>

          {/* Style Scores */}
          <div className="space-y-3">
            <h4 className="font-medium">Learning Style Breakdown:</h4>
            {Object.entries(results.styleScores).map(([style, score]) => (
              <div key={style} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="capitalize">{learningStyleDescriptions[style].title}</span>
                  <span>{score} points</span>
                </div>
                <Progress value={(score / maxScore) * 100} className="h-2" />
              </div>
            ))}
          </div>

          {/* Study Techniques */}
          <div className="space-y-3">
            <h4 className="font-medium">Recommended Study Techniques:</h4>
            <ul className="space-y-2">
              {results.studyTechniques.map((technique, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>{technique}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* General Recommendations */}
          <div className="space-y-3">
            <h4 className="font-medium">UPSC-Specific Recommendations:</h4>
            <ul className="space-y-2">
              {results.recommendations.map((rec, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <Brain className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>

          <Button onClick={resetQuiz} variant="outline" className="w-full">
            Take Quiz Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-primary" />
          Learning Style Assessment
        </CardTitle>
        <CardDescription>
          Question {currentQuestion + 1} of {questions.length}
        </CardDescription>
        <Progress value={progress} className="w-full" />
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-lg font-medium mb-4">{question.question}</h3>
          
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2">
                <input
                  type="radio"
                  value={option.text}
                  id={`option-${index}`}
                  checked={selectedOption === option.text}
                  onChange={(e) => setSelectedOption(e.target.value)}
                  className="h-4 w-4 text-primary focus:ring-primary border-gray-300"
                />
                <Label 
                  htmlFor={`option-${index}`} 
                  className="text-sm cursor-pointer flex-1"
                >
                  {option.text}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-2">
          {currentQuestion > 0 && (
            <Button 
              variant="outline" 
              onClick={() => {
                setCurrentQuestion(prev => prev - 1);
                setSelectedOption("");
              }}
            >
              Previous
            </Button>
          )}
          <Button 
            onClick={handleAnswer}
            disabled={!selectedOption}
            className="ml-auto"
          >
            {currentQuestion === questions.length - 1 ? "Complete Assessment" : "Next"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}