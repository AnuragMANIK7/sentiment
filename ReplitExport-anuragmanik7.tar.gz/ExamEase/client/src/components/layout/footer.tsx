import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-white border-t border-border mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">UPSC AI Tools</h3>
            <p className="text-sm text-muted-foreground">
              Empowering UPSC aspirants with AI-powered tools for better learning, mental health support, and content creation.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-foreground mb-3">Tools</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/mental-health" className="hover:text-primary transition-colors">
                  Mental Health Coach
                </Link>
              </li>
              <li>
                <Link href="/prompt-generator" className="hover:text-primary transition-colors">
                  Prompt Generator
                </Link>
              </li>
              <li>
                <Link href="/thumbnail-creator" className="hover:text-primary transition-colors">
                  Thumbnail Creator
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-foreground mb-3">Resources</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Study Guides</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Mental Health Tips</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Content Templates</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Best Practices</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-foreground mb-3">Support</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border mt-8 pt-6 text-center">
          <p className="text-sm text-muted-foreground">
            &copy; 2024 UPSC AI Tools. All rights reserved. Powered by advanced AI for educational excellence.
          </p>
        </div>
      </div>
    </footer>
  );
}
