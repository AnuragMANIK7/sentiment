import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  BookOpen, 
  Target, 
  Clock, 
  Brain, 
  Users, 
  Eye, 
  Headphones, 
  Hand,
  Calendar,
  Award,
  TrendingUp,
  CheckCircle,
  AlertCircle,
  Star,
  ExternalLink,
  Loader2
} from "lucide-react";

interface LearningStyleResult {
  dominantStyle?: string;
  primaryStyle?: string;
  scores?: {
    visual: number;
    auditory: number;
    kinesthetic: number;
    social: number;
  };
  studyTechniques?: string[];
  recommendations?: string[];
  timestamp?: string;
}

interface UPSCStudyPlan {
  phase: string;
  duration: string;
  subjects: string[];
  techniques: string[];
  resources: string[];
  milestones: string[];
}

interface EnhancedInsightsProps {
  learningStyleResults: LearningStyleResult | null;
  username?: string;
}

export default function EnhancedLearningInsights({ learningStyleResults, username }: EnhancedInsightsProps) {
  const [selectedTimeframe, setSelectedTimeframe] = useState<'3months' | '6months' | '12months'>('6months');
  const [studyPlan, setStudyPlan] = useState<UPSCStudyPlan[]>([]);

  // Fetch personalized resources from aspirants methodology
  const { data: aspirantsData, isLoading: isLoadingAspirants } = useQuery({
    queryKey: ['/api/learning/personalized-resources', learningStyleResults?.dominantStyle || learningStyleResults?.primaryStyle, selectedTimeframe],
    queryFn: async () => {
      if (!learningStyleResults) return null;
      
      // Convert learning style data to expected format
      const normalizedLearningStyle = {
        dominantStyle: learningStyleResults.dominantStyle || learningStyleResults.primaryStyle || 'visual',
        scores: learningStyleResults.scores || {
          visual: 25,
          auditory: 25, 
          kinesthetic: 25,
          social: 25
        }
      };
      
      const response = await apiRequest('POST', '/api/learning/personalized-resources', {
        learningStyle: normalizedLearningStyle,
        timeframe: selectedTimeframe
      });
      return response.json();
    },
    enabled: !!learningStyleResults && !!(learningStyleResults.dominantStyle || learningStyleResults.primaryStyle),
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  useEffect(() => {
    if (learningStyleResults) {
      generatePersonalizedStudyPlan();
    }
  }, [learningStyleResults, selectedTimeframe]);

  const generatePersonalizedStudyPlan = () => {
    if (!learningStyleResults) return;

    const dominantStyle = learningStyleResults?.dominantStyle || learningStyleResults?.primaryStyle || 'visual';
    const plans: UPSCStudyPlan[] = [];

    // Base UPSC study phases adapted to learning style
    const phases = getAdaptedPhases(dominantStyle, selectedTimeframe);
    setStudyPlan(phases);
  };

  const getAdaptedPhases = (style: string | undefined, timeframe: string): UPSCStudyPlan[] => {
    if (!style) return [];
    
    const safeStyle = style;
    const basePlans = {
      '3months': [
        {
          phase: "Foundation Building",
          duration: "Month 1",
          subjects: ["Polity", "History", "Geography Basics"],
          techniques: getStyleSpecificTechniques(safeStyle, "foundation"),
          resources: getStyleSpecificResources(safeStyle, "foundation"),
          milestones: ["Complete NCERT 6-12", "Basic current affairs coverage", "100 MCQs daily"]
        },
        {
          phase: "Intensive Preparation",
          duration: "Month 2",
          subjects: ["Economics", "Environment", "Current Affairs"],
          techniques: getStyleSpecificTechniques(safeStyle, "intensive"),
          resources: getStyleSpecificResources(safeStyle, "intensive"),
          milestones: ["Subject-wise test series", "Previous year analysis", "Essay writing practice"]
        },
        {
          phase: "Final Revision",
          duration: "Month 3",
          subjects: ["All subjects", "Mock tests", "Answer writing"],
          techniques: getStyleSpecificTechniques(safeStyle, "revision"),
          resources: getStyleSpecificResources(safeStyle, "revision"),
          milestones: ["Full-length mocks", "Time management", "Stress management"]
        }
      ],
      '6months': [
        {
          phase: "Foundation & Conceptual Clarity",
          duration: "Months 1-2",
          subjects: ["Polity", "History", "Geography", "Basic Economics"],
          techniques: getStyleSpecificTechniques(safeStyle, "foundation"),
          resources: getStyleSpecificResources(safeStyle, "foundation"),
          milestones: ["Complete NCERT 6-12", "Standard reference books", "Daily current affairs"]
        },
        {
          phase: "Advanced Preparation",
          duration: "Months 3-4",
          subjects: ["Advanced Economics", "Environment", "S&T", "International Relations"],
          techniques: getStyleSpecificTechniques(safeStyle, "advanced"),
          resources: getStyleSpecificResources(safeStyle, "advanced"),
          milestones: ["Subject-wise mastery", "Analytical thinking", "Answer writing skills"]
        },
        {
          phase: "Test Series & Revision",
          duration: "Months 5-6",
          subjects: ["Mock tests", "Previous years", "Current affairs integration"],
          techniques: getStyleSpecificTechniques(safeStyle, "test"),
          resources: getStyleSpecificResources(safeStyle, "test"),
          milestones: ["Weekly full tests", "Performance analysis", "Strategy refinement"]
        }
      ],
      '12months': [
        {
          phase: "Comprehensive Foundation",
          duration: "Months 1-4",
          subjects: ["All static subjects", "Basic current affairs"],
          techniques: getStyleSpecificTechniques(safeStyle, "comprehensive"),
          resources: getStyleSpecificResources(safeStyle, "comprehensive"),
          milestones: ["Subject completion", "Note making", "Concept clarity"]
        },
        {
          phase: "Advanced Study & Integration",
          duration: "Months 5-8",
          subjects: ["Advanced topics", "Interlinkages", "Current affairs"],
          techniques: getStyleSpecificTechniques(safeStyle, "integration"),
          resources: getStyleSpecificResources(safeStyle, "integration"),
          milestones: ["Cross-subject connections", "Analytical skills", "Answer writing"]
        },
        {
          phase: "Intensive Test Series",
          duration: "Months 9-10",
          subjects: ["Mock tests", "Sectional tests", "Time management"],
          techniques: getStyleSpecificTechniques(safeStyle, "intensive"),
          resources: getStyleSpecificResources(safeStyle, "intensive"),
          milestones: ["Regular testing", "Performance tracking", "Weak area improvement"]
        },
        {
          phase: "Final Preparation",
          duration: "Months 11-12",
          subjects: ["Revision", "Current affairs", "Strategy refinement"],
          techniques: getStyleSpecificTechniques(safeStyle, "final"),
          resources: getStyleSpecificResources(safeStyle, "final"),
          milestones: ["Complete revision", "Mock test mastery", "Exam confidence"]
        }
      ]
    };

    return basePlans[timeframe as keyof typeof basePlans] || [];
  };

  const getStyleSpecificTechniques = (style: string, phase: string): string[] => {
    const techniques = {
      visual: {
        foundation: ["Mind maps for concepts", "Flowcharts for processes", "Infographics for data", "Color-coded notes"],
        intensive: ["Visual timelines", "Diagram-based learning", "Chart analysis", "Map-based geography"],
        advanced: ["Visual case studies", "Graphical data interpretation", "Conceptual diagrams", "Visual mnemonics"],
        comprehensive: ["Comprehensive mind maps", "Visual note compilation", "Subject-wise flowcharts", "Timeline integration"],
        integration: ["Cross-subject visual links", "Integrated mind maps", "Visual current affairs", "Comparative charts"],
        test: ["Visual analysis of options", "Diagram-based elimination", "Graphical time management", "Visual revision"],
        revision: ["Quick visual reviews", "Diagram flashcards", "Visual summary sheets", "Last-minute charts"],
        final: ["Visual strategy cards", "Quick reference diagrams", "Visual stress management", "Pattern recognition"]
      },
      auditory: {
        foundation: ["Audio lectures", "Discussion groups", "Verbal repetition", "Podcast learning"],
        intensive: ["Recorded note reviews", "Group discussions", "Verbal explanations", "Audio current affairs"],
        advanced: ["Debate practice", "Verbal case analysis", "Audio book reviews", "Discussion forums"],
        comprehensive: ["Audio note compilation", "Verbal concept explanations", "Discussion sessions", "Audio summaries"],
        integration: ["Verbal cross-connections", "Audio current affairs integration", "Discussion-based learning", "Verbal analysis"],
        test: ["Verbal strategy discussion", "Audio question practice", "Spoken elimination", "Verbal time management"],
        revision: ["Audio revision sessions", "Verbal quick reviews", "Spoken summaries", "Audio flashcards"],
        final: ["Verbal strategy rehearsal", "Audio confidence building", "Spoken stress management", "Final discussions"]
      },
      kinesthetic: {
        foundation: ["Hands-on activities", "Physical note-taking", "Walking while studying", "Interactive learning"],
        intensive: ["Active problem solving", "Physical current affairs tracking", "Hands-on map work", "Active recall"],
        advanced: ["Physical case study analysis", "Hands-on data work", "Active participation", "Physical mnemonics"],
        comprehensive: ["Physical note organization", "Hands-on concept building", "Active subject integration", "Physical timelines"],
        integration: ["Active cross-subject work", "Physical current affairs integration", "Hands-on analysis", "Active connections"],
        test: ["Physical mock test practice", "Active elimination", "Hands-on time management", "Physical strategy"],
        revision: ["Active revision sessions", "Physical quick reviews", "Hands-on summaries", "Active flashcards"],
        final: ["Physical strategy practice", "Active confidence building", "Hands-on stress management", "Physical preparation"]
      },
      social: {
        foundation: ["Study groups", "Peer discussions", "Collaborative learning", "Mentorship"],
        intensive: ["Group study sessions", "Peer teaching", "Collaborative analysis", "Social current affairs"],
        advanced: ["Group case studies", "Peer review", "Collaborative problem solving", "Social learning"],
        comprehensive: ["Study group formation", "Peer note sharing", "Collaborative concept building", "Social integration"],
        integration: ["Group integration sessions", "Peer current affairs discussion", "Collaborative analysis", "Social connections"],
        test: ["Group mock tests", "Peer strategy discussion", "Social test analysis", "Group time management"],
        revision: ["Group revision sessions", "Peer quick reviews", "Social summaries", "Collaborative flashcards"],
        final: ["Group strategy sessions", "Peer confidence building", "Social stress management", "Final group preparation"]
      }
    };

    return techniques[style as keyof typeof techniques]?.[phase as keyof typeof techniques.visual] || [];
  };

  const getStyleSpecificResources = (style: string, phase: string): string[] => {
    // Enhanced resources based on aspirants repository methodology
    const resources = {
      visual: {
        foundation: ["NCERT Mind Maps Collection", "Visual atlases with interactive maps", "Current Affairs Infographics", "Geography Atlas & Maps"],
        intensive: ["Polity Flowcharts & Diagrams", "Visual current affairs magazines", "Chart-based economics books", "AI Study Planner"],
        advanced: ["Advanced visual learning modules", "Interactive visualization tools", "Visual case study platforms", "Smart Revision Assistant"],
        comprehensive: ["Comprehensive visual learning suite", "AI-powered visual content", "Visual encyclopedia platforms", "Adaptive Learning Platform"],
        integration: ["Cross-subject visual connections", "Integrated mind mapping tools", "Visual current affairs integration", "Question Bank with AI Analysis"],
        test: ["Interactive Quiz Platform", "Visual test analysis tools", "Chart-based mock tests", "AI performance tracking"],
        revision: ["Visual revision scheduling", "Quick reference visual guides", "AI-optimized flashcards", "Visual summary generators"],
        final: ["Final visual strategy tools", "Quick reference charts", "Visual confidence builders", "Last-minute visual aids"]
      },
      auditory: {
        foundation: ["UPSC Audio Lectures Series", "Educational podcasts for beginners", "Current Affairs Podcast", "Discussion-based learning"],
        intensive: ["Advanced audio content", "Expert interview recordings", "Audio-based test series", "Peer Discussion Forums"],
        advanced: ["Economics Audio Books", "Expert commentary series", "Advanced audio analysis", "Mentor-Student Connect"],
        comprehensive: ["Complete audio learning suite", "AI-powered audio content", "Comprehensive audio courses", "Group Study Video Calls"],
        integration: ["Cross-subject audio discussions", "Integrated audio learning", "Audio current affairs", "Social learning platforms"],
        test: ["Audio test explanations", "Verbal test strategies", "Discussion-based assessments", "Audio performance analysis"],
        revision: ["Audio revision schedules", "Quick audio reviews", "Verbal summary sessions", "AI-optimized audio content"],
        final: ["Final audio preparation", "Quick audio references", "Verbal confidence building", "Last-minute audio guides"]
      },
      kinesthetic: {
        foundation: ["Interactive learning modules", "Hands-on NCERT activities", "Physical map exercises", "Answer Writing Practice Sheets"],
        intensive: ["Interactive current affairs", "Hands-on case studies", "Mock Interview Simulator", "Physical test practice"],
        advanced: ["Advanced interactive tools", "Hands-on analysis platforms", "Kinesthetic learning apps", "Field Study Guides"],
        comprehensive: ["Complete hands-on learning", "Interactive course platforms", "Physical learning resources", "Activity-based modules"],
        integration: ["Cross-subject activities", "Integrated hands-on learning", "Physical current affairs", "Interactive connections"],
        test: ["Interactive Quiz Platform", "Hands-on test practice", "Physical mock exams", "Activity-based assessments"],
        revision: ["Activity-based revision", "Quick hands-on reviews", "Physical flashcard systems", "Interactive summaries"],
        final: ["Final hands-on preparation", "Quick physical practice", "Activity-based confidence building", "Last-minute interactive tools"]
      },
      social: {
        foundation: ["UPSC Study Groups Platform", "Collaborative learning tools", "Peer Discussion Forums", "Group study guides"],
        intensive: ["Advanced group activities", "Peer teaching platforms", "Social learning networks", "Group Study Video Calls"],
        advanced: ["Expert mentorship programs", "Advanced group projects", "Social analysis tools", "Mentor-Student Connect"],
        comprehensive: ["Complete social learning suite", "Comprehensive group platforms", "Social learning ecosystems", "Collaborative platforms"],
        integration: ["Cross-subject group work", "Integrated social learning", "Social current affairs", "Peer collaboration tools"],
        test: ["Group test sessions", "Peer assessment tools", "Social mock exams", "Collaborative test analysis"],
        revision: ["Group revision sessions", "Quick peer reviews", "Social flashcard sharing", "Collaborative summaries"],
        final: ["Final group preparation", "Quick peer connections", "Social confidence building", "Last-minute collaboration"]
      }
    };

    return resources[style as keyof typeof resources]?.[phase as keyof typeof resources.visual] || [];
  };

  const getStyleIcon = (style: string) => {
    const icons = {
      visual: Eye,
      auditory: Headphones,
      kinesthetic: Hand,
      social: Users
    };
    return icons[style as keyof typeof icons] || BookOpen;
  };

  const getStyleColor = (style: string) => {
    const colors = {
      visual: "text-blue-600 dark:text-blue-400",
      auditory: "text-green-600 dark:text-green-400",
      kinesthetic: "text-orange-600 dark:text-orange-400",
      social: "text-purple-600 dark:text-purple-400"
    };
    return colors[style as keyof typeof colors] || "text-gray-600 dark:text-gray-400";
  };

  const getPersonalizedMotivation = (style: string): string[] => {
    const motivations = {
      visual: [
        "Create colorful study schedules and track progress visually",
        "Use mind maps to see the big picture of UPSC syllabus",
        "Visualize your success - create a vision board for your IAS goals",
        "Use charts and graphs to track your mock test performance"
      ],
      auditory: [
        "Join study groups and participate in discussions regularly",
        "Record yourself explaining concepts and listen back",
        "Find study partners to discuss current affairs daily",
        "Listen to expert lectures and podcasts during commute"
      ],
      kinesthetic: [
        "Take breaks every 45 minutes for physical activity",
        "Use flashcards and physical note-taking for better retention",
        "Walk while reviewing notes for better memory consolidation",
        "Practice writing answers by hand to improve speed and content"
      ],
      social: [
        "Form or join UPSC study groups in your area",
        "Participate in online forums and discussion platforms",
        "Find a study buddy for mutual motivation and accountability",
        "Engage with successful candidates for guidance and inspiration"
      ]
    };
    return motivations[style as keyof typeof motivations] || [];
  };

  if (!learningStyleResults) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Brain className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <p className="text-gray-600 dark:text-gray-400">
            Complete the learning style assessment to see personalized UPSC preparation insights
          </p>
        </CardContent>
      </Card>
    );
  }

  const StyleIcon = getStyleIcon(learningStyleResults?.dominantStyle || learningStyleResults?.primaryStyle || 'visual');

  return (
    <div className="space-y-6">
      {/* Learning Style Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <StyleIcon className={`h-5 w-5 ${getStyleColor(learningStyleResults?.dominantStyle || learningStyleResults?.primaryStyle || 'visual')}`} />
            Your UPSC Learning Profile
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-3">Dominant Learning Style</h3>
              <Badge variant="secondary" className="text-lg p-2">
                {(learningStyleResults?.dominantStyle || learningStyleResults?.primaryStyle)
                  ? (learningStyleResults.dominantStyle || learningStyleResults.primaryStyle)!.charAt(0).toUpperCase() + 
                    (learningStyleResults.dominantStyle || learningStyleResults.primaryStyle)!.slice(1)
                  : 'Unknown'} Learner
              </Badge>
              
              <div className="mt-4 space-y-2">
                {learningStyleResults?.scores && Object.entries(learningStyleResults.scores).map(([style, score]) => (
                  <div key={style}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="capitalize">{style}</span>
                      <span>{score}%</span>
                    </div>
                    <Progress value={score} className="h-2" />
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-3">Personalized Motivation Tips</h3>
              <ul className="space-y-2">
                {getPersonalizedMotivation(learningStyleResults?.dominantStyle || learningStyleResults?.primaryStyle || 'visual').map((tip, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <Star className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Aspirants Repository Resources */}
      {aspirantsData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              AI-Powered Learning Resources
              <Badge variant="outline" className="text-xs">
                aayushpagare21-compcoder/aspirants
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {aspirantsData.resources.slice(0, 6).map((resource: any, index: number) => (
                <Card key={index} className="border-l-4 border-l-blue-500 hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-sm">{resource.name}</h4>
                      <Badge variant="secondary" className="text-xs">
                        {resource.type}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600 dark:text-gray-400 mb-3">
                      {resource.description}
                    </p>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 text-yellow-500" />
                        <span className="text-xs">{resource.rating}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {resource.difficulty}
                      </Badge>
                    </div>
                    {resource.url && (
                      <a 
                        href={resource.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors"
                      >
                        <ExternalLink className="h-3 w-3" />
                        Access Resource
                      </a>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
            {aspirantsData.resources.length > 6 && (
              <div className="mt-4 text-center">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    // Create a modal or expand view for all resources
                    const allResourcesWindow = window.open('', '_blank');
                    if (allResourcesWindow) {
                      allResourcesWindow.document.write(`
                        <html>
                          <head><title>All UPSC Learning Resources</title></head>
                          <body style="font-family: Arial, sans-serif; padding: 20px;">
                            <h1>Complete UPSC Learning Resources (${aspirantsData.resources.length} total)</h1>
                            ${aspirantsData.resources.map((resource: any) => `
                              <div style="border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px;">
                                <h3>${resource.name}</h3>
                                <p><strong>Category:</strong> ${resource.category} | <strong>Type:</strong> ${resource.type} | <strong>Difficulty:</strong> ${resource.difficulty}</p>
                                <p>${resource.description}</p>
                                <p><strong>Rating:</strong> ${resource.rating}/5</p>
                                ${resource.url ? `<p><a href="${resource.url}" target="_blank" style="color: #0066cc;">Access Resource →</a></p>` : ''}
                              </div>
                            `).join('')}
                          </body>
                        </html>
                      `);
                    }
                  }}
                >
                  View All {aspirantsData.resources.length} Resources
                  <ExternalLink className="h-3 w-3 ml-1" />
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Study Plan Tabs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Personalized UPSC Study Plan
            {isLoadingAspirants && (
              <Loader2 className="h-4 w-4 animate-spin" />
            )}
          </CardTitle>
          <div className="flex gap-2">
            {(['3months', '6months', '12months'] as const).map((timeframe) => (
              <button
                key={timeframe}
                onClick={() => setSelectedTimeframe(timeframe)}
                className={`px-3 py-1 rounded text-sm ${
                  selectedTimeframe === timeframe
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary hover:bg-secondary/80'
                }`}
              >
                {timeframe === '3months' ? '3 Months' : 
                 timeframe === '6months' ? '6 Months' : '12 Months'}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {studyPlan.map((phase, index) => (
              <Card key={index} className="border-l-4 border-l-primary">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {phase.phase}
                    <Badge variant="outline">{phase.duration}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2 flex items-center gap-1">
                      <BookOpen className="h-4 w-4" />
                      Key Subjects
                    </h4>
                    <div className="flex flex-wrap gap-1">
                      {phase.subjects.map((subject, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {subject}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2 flex items-center gap-1">
                      <Brain className="h-4 w-4" />
                      {((learningStyleResults?.dominantStyle || learningStyleResults?.primaryStyle) || 'Visual').charAt(0).toUpperCase() + 
                       ((learningStyleResults?.dominantStyle || learningStyleResults?.primaryStyle) || 'visual').slice(1)} Learning Techniques
                    </h4>
                    <ul className="text-sm space-y-1">
                      {phase.techniques.map((technique, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle className="h-3 w-3 text-green-500 mt-1 flex-shrink-0" />
                          {technique}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2 flex items-center gap-1">
                      <Award className="h-4 w-4" />
                      Key Milestones
                    </h4>
                    <ul className="text-sm space-y-1">
                      {phase.milestones.map((milestone, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Target className="h-3 w-3 text-blue-500 mt-1 flex-shrink-0" />
                          {milestone}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2 flex items-center gap-1">
                      <TrendingUp className="h-4 w-4" />
                      Recommended Resources
                    </h4>
                    <ul className="text-sm space-y-1">
                      {phase.resources.map((resource, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <AlertCircle className="h-3 w-3 text-orange-500 mt-1 flex-shrink-0" />
                          {resource}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Performance Tracking Suggestion */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Track Your Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <Clock className="h-8 w-8 mx-auto mb-2 text-blue-600" />
              <h3 className="font-medium">Daily Study Hours</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Track consistent study habits</p>
            </div>
            <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <Target className="h-8 w-8 mx-auto mb-2 text-green-600" />
              <h3 className="font-medium">Mock Test Scores</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Monitor improvement trends</p>
            </div>
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <Award className="h-8 w-8 mx-auto mb-2 text-purple-600" />
              <h3 className="font-medium">Subject Mastery</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Track subject-wise progress</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}