import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Camera, 
  Square, 
  Play, 
  Brain, 
  Heart, 
  Activity, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Eye,
  FileText,
  Download,
  Users,
  BookOpen,
  Microscope,
  Code,
  ChevronRight,
  Upload,
  Pause
} from 'lucide-react';

interface AdvancedAnalysisResult {
  depressionRiskScore: number;
  severityLevel: string;
  confidence: number;
  modalityScores: {
    audio: number;
    facial: number;
    behavioral: number;
    temporal: number;
  };
  clinicalIndicators: {
    speechPatterns: string[];
    facialExpressions: string[];
    behavioralCues: string[];
    temporalPatterns: string[];
  };
  riskFactors: string[];
  protectiveFactors: string[];
  interventionRecommendations: string[];
  monitoringNeeds: string[];
  researchFindings: {
    nonVerbalCues: string[];
    multimodalConfidence: number;
    temporalConsistency: number;
  };
}

interface AdvancedHealthSession {
  id: string;
  studentName: string;
  sessionType: string;
  depressionRiskScore: string;
  severityLevel: string;
  confidence: string;
  modalityScores: any;
  clinicalIndicators: any;
  riskFactors: any;
  protectiveFactors: any;
  interventionRecommendations: any;
  monitoringNeeds: any;
  researchFindings: any;
  flaggedForProfessionalReview: boolean;
  processingTimeMs: number;
  createdAt: string;
}

interface AdvancedHealthAnalysisProps {
  username?: string;
}

export default function AdvancedHealthAnalysis({ username }: AdvancedHealthAnalysisProps) {
  const [studentName, setStudentName] = useState(username || '');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordedVideoBlob, setRecordedVideoBlob] = useState<Blob | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AdvancedAnalysisResult | null>(null);
  const [currentTab, setCurrentTab] = useState('record');
  const [naturalLanguageSummary, setNaturalLanguageSummary] = useState<string | null>(null);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingInterval = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Function to download analysis reports
  const downloadAnalysisReport = (analysisData: AdvancedAnalysisResult, format: 'json' | 'txt') => {
    if (!analysisData) {
      toast({
        title: "No Analysis Data",
        description: "Please complete an analysis first before downloading reports.",
        variant: "destructive",
      });
      return;
    }

    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `depression_analysis_${studentName || 'anonymous'}_${timestamp}`;

    if (format === 'json') {
      // Structured JSON format as suggested by Perplexity
      const structuredData = {
        sessionId: analysisData.sessionId,
        studentName: studentName || 'anonymous',
        timestamp: new Date().toISOString(),
        analysis: {
          depressionRiskScore: analysisData.depressionRiskScore,
          severityLevel: analysisData.severityLevel,
          confidence: analysisData.confidence,
          modalityScores: analysisData.modalityScores,
          clinicalIndicators: analysisData.clinicalIndicators,
          riskFactors: analysisData.riskFactors,
          protectiveFactors: analysisData.protectiveFactors,
          interventionRecommendations: analysisData.interventionRecommendations,
          monitoringNeeds: analysisData.monitoringNeeds,
          researchFindings: analysisData.researchFindings
        },
        metadata: {
          researchBased: true,
          methodology: "Multimodal Temporal Transformer (ECIR 2024)",
          modalitiesAnalyzed: ["audio", "facial", "behavioral", "temporal"],
          confidence: analysisData.confidence,
          processingTimeMs: analysisData.processingTimeMs
        },
        processingTime: analysisData.processingTimeMs
      };

      const jsonBlob = new Blob([JSON.stringify(structuredData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(jsonBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } else {
      // Text summary format
      const textReport = generateTextSummary(analysisData, studentName);
      const textBlob = new Blob([textReport], { type: 'text/plain' });
      const url = URL.createObjectURL(textBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }

    toast({
      title: "Report Downloaded",
      description: `${format.toUpperCase()} report has been downloaded successfully.`,
    });
  };

  // Function to generate text summary
  const generateTextSummary = (data: AdvancedAnalysisResult, student: string) => {
    return `DEPRESSION ANALYSIS REPORT
==========================

Student: ${student || 'Anonymous'}
Date: ${new Date().toLocaleDateString()}
Time: ${new Date().toLocaleTimeString()}
Session ID: ${data.sessionId}

EXECUTIVE SUMMARY
-----------------
Risk Score: ${Math.round(data.depressionRiskScore)}%
Severity Level: ${data.severityLevel?.toUpperCase()}
Analysis Confidence: ${Math.round(data.confidence * 100)}%
Processing Time: ${data.processingTimeMs}ms

MULTIMODAL ANALYSIS BREAKDOWN
-----------------------------
${data.modalityScores ? Object.entries(data.modalityScores)
  .map(([modality, score]) => `${modality.charAt(0).toUpperCase() + modality.slice(1)}: ${Math.round(Number(score))}%`)
  .join('\n') : 'No modality scores available'}

CLINICAL INDICATORS
-------------------
${data.clinicalIndicators ? Object.entries(data.clinicalIndicators)
  .map(([category, indicators]) => {
    const categoryName = category.replace(/([A-Z])/g, ' $1').trim();
    const indicatorList = Array.isArray(indicators) 
      ? indicators.map(indicator => `  • ${indicator}`).join('\n')
      : `  • ${String(indicators)}`;
    return `${categoryName.charAt(0).toUpperCase() + categoryName.slice(1)}:\n${indicatorList}`;
  }).join('\n\n') : 'No clinical indicators available'}

RISK ASSESSMENT
---------------
Risk Factors:
${data.riskFactors?.map(factor => `  • ${factor}`).join('\n') || '  • None identified'}

Protective Factors:
${data.protectiveFactors?.map(factor => `  • ${factor}`).join('\n') || '  • None identified'}

INTERVENTION RECOMMENDATIONS
----------------------------
${data.interventionRecommendations?.map(rec => `  • ${rec}`).join('\n') || '  • No specific recommendations'}

MONITORING REQUIREMENTS
-----------------------
${data.monitoringNeeds?.map(need => `  • ${need}`).join('\n') || '  • Standard monitoring protocols'}

RESEARCH FINDINGS
-----------------
${data.researchFindings ? `
Non-Verbal Cues Detected:
${data.researchFindings.nonVerbalCues?.map(cue => `  • ${cue}`).join('\n') || '  • None identified'}

Multimodal Confidence: ${Math.round((data.researchFindings.multimodalConfidence || 0) * 100)}%
Temporal Consistency: ${Math.round((data.researchFindings.temporalConsistency || 0) * 100)}%
` : 'No research findings available'}

METHODOLOGY
-----------
Analysis Method: Multimodal Temporal Transformer (ECIR 2024)
Data Sources: Video, Audio, Facial Expression, Behavioral Patterns
Research-Based: Yes
Validated Approach: Early Depression Detection using Multimodal Analysis

DISCLAIMER
----------
This analysis is for research and educational purposes only. 
It should not be used as the sole basis for clinical decisions.
Professional mental health consultation is recommended for comprehensive assessment.

Report Generated: ${new Date().toISOString()}
`;
  };

  // Function to download simple summary
  const downloadSimpleSummary = (data: AdvancedAnalysisResult) => {
    if (!data) {
      toast({
        title: "No Analysis Data",
        description: "Please complete an analysis first.",
        variant: "destructive",
      });
      return;
    }

    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `simple_summary_${studentName || 'anonymous'}_${timestamp}.txt`;

    const bestModality = data.modalityScores ? 
      Object.entries(data.modalityScores)
        .sort(([,a], [,b]) => Number(b) - Number(a))[0]?.[0] : 'unknown';

    const riskInterpretation = 
      data.depressionRiskScore < 25 ? 'Low Risk - Good mental health indicators' :
      data.depressionRiskScore < 50 ? 'Mild Concern - Some stress indicators detected' :
      data.depressionRiskScore < 75 ? 'Moderate Risk - Professional consultation recommended' :
      'High Risk - Immediate professional support needed';

    const simpleSummary = `MENTAL HEALTH ANALYSIS - SIMPLE SUMMARY
==========================================

Student: ${studentName || 'Anonymous'}
Date: ${new Date().toLocaleDateString()}
Analysis ID: ${data.sessionId}

OVERALL RESULT
--------------
Risk Level: ${data.severityLevel?.toUpperCase()}
Risk Score: ${Math.round(data.depressionRiskScore)}%
Confidence: ${Math.round(data.confidence * 100)}%

INTERPRETATION
--------------
${riskInterpretation}

KEY FINDINGS
------------
Best Analysis Source: ${bestModality?.charAt(0).toUpperCase() + bestModality?.slice(1)}
Processing Time: ${Math.round((data.processingTimeMs || 0) / 1000)} seconds
Research-Based Method: Yes (ECIR 2024 Standards)

TOP RECOMMENDATIONS
-------------------
${data.interventionRecommendations?.slice(0, 3).map((rec, idx) => `${idx + 1}. ${rec}`).join('\n') || 'No specific recommendations available'}

MONITORING NEEDS
----------------
${data.monitoringNeeds?.slice(0, 3).map((need, idx) => `${idx + 1}. ${need}`).join('\n') || 'Standard monitoring protocols'}

IMPORTANT NOTE
--------------
This analysis is for educational purposes only. 
For clinical decisions, consult a qualified mental health professional.

Generated: ${new Date().toLocaleString()}
`;

    const textBlob = new Blob([simpleSummary], { type: 'text/plain' });
    const url = URL.createObjectURL(textBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Simple Summary Downloaded",
      description: "Concise analysis summary has been downloaded.",
    });
  };

  // Generate natural language summary using NLX-JSON-to-Text approach
  const generateNaturalLanguageSummary = async (analysisData: AdvancedAnalysisResult) => {
    setIsGeneratingSummary(true);
    try {
      const response = await apiRequest('POST', '/api/advanced-depression/generate-summary', {
        analysisData,
        studentName
      });
      const data = await response.json();
      setNaturalLanguageSummary(data.summary);
    } catch (error) {
      console.error("Failed to generate natural language summary:", error);
      toast({
        title: "Summary Generation Failed",
        description: "Could not generate natural language summary",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  // Save analysis results to local reports storage
  const saveAnalysisToReports = (analysisData: AdvancedAnalysisResult) => {
    if (!studentName) return;
    
    try {
      const reportEntry = {
        id: `report_${Date.now()}`,
        sessionId: analysisData.sessionId,
        studentName,
        timestamp: new Date().toISOString(),
        analysisData,
        riskScore: analysisData.depressionRiskScore,
        severityLevel: analysisData.severityLevel,
        confidence: analysisData.confidence,
        summary: `Risk: ${Math.round(analysisData.depressionRiskScore)}%, Level: ${analysisData.severityLevel}, Confidence: ${Math.round(analysisData.confidence * 100)}%`
      };

      // Get existing reports from localStorage
      const existingReports = JSON.parse(localStorage.getItem('advancedHealthReports') || '[]');
      
      // Add new report
      const updatedReports = [reportEntry, ...existingReports].slice(0, 50); // Keep only last 50 reports
      
      // Save back to localStorage
      localStorage.setItem('advancedHealthReports', JSON.stringify(updatedReports));
      
      console.log(`💾 Analysis report saved locally for ${studentName}`);
    } catch (error) {
      console.error('Failed to save analysis report locally:', error);
    }
  };

  // Get reports for current user
  const getUserReports = () => {
    if (!studentName) return [];
    
    try {
      const allReports = JSON.parse(localStorage.getItem('advancedHealthReports') || '[]');
      return allReports.filter((report: any) => report.studentName === studentName);
    } catch (error) {
      console.error('Failed to load reports:', error);
      return [];
    }
  };

  // Fetch research information
  const { data: researchInfo } = useQuery({
    queryKey: ['/api/advanced-depression/research-info'],
  });

  // Fetch previous sessions
  const { data: previousSessions } = useQuery<AdvancedHealthSession[]>({
    queryKey: ['/api/advanced-depression/sessions'],
    enabled: !!studentName,
  });

  // Fetch reports
  const { data: reports } = useQuery({
    queryKey: ['/api/advanced-depression/reports', studentName],
    enabled: !!studentName,
  });

  // Analysis mutation
  const analyzeMutation = useMutation({
    mutationFn: async (data: { studentName: string; videoBase64: string; sessionType: string }) => {
      const startTime = Date.now();
      const response = await apiRequest('POST', '/api/advanced-depression/analyze', data);
      const result = await response.json();
      const processingTime = Date.now() - startTime;
      return { ...result, processingTime };
    },
    onSuccess: (result) => {
      setAnalysisResult(result);
      setCurrentTab('results');
      queryClient.invalidateQueries({ queryKey: ['/api/advanced-depression/sessions'] });
      
      // Save analysis to local reports
      saveAnalysisToReports(result);
      
      // Auto-generate natural language summary
      generateNaturalLanguageSummary(result);
      
      toast({
        title: "Analysis Complete",
        description: `Advanced multimodal analysis completed in ${Math.round((result.processingTime || 0) / 1000)}s`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to complete multimodal analysis",
        variant: "destructive",
      });
    },
  });

  // PDF Report generation mutation
  const generateReportMutation = useMutation({
    mutationFn: async (data: { analysisData: AdvancedAnalysisResult; studentName: string }) => {
      const response = await apiRequest('POST', '/api/advanced-depression/generate-report', data);
      return response.blob();
    },
    onSuccess: (pdfBlob) => {
      // Create download link for PDF
      const url = window.URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `advanced_health_report_${studentName}_${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Report Generated",
        description: "PDF report has been downloaded successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Report Generation Failed",
        description: error.message || "Failed to generate PDF report",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    return () => {
      if (recordingInterval.current) {
        clearInterval(recordingInterval.current);
      }
      if (videoPreviewUrl) {
        URL.revokeObjectURL(videoPreviewUrl);
      }
    };
  }, [videoPreviewUrl]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: 1280, 
          height: 720, 
          frameRate: 24 
        },
        audio: {
          sampleRate: 44100,
          channelCount: 2,
          echoCancellation: true,
          noiseSuppression: true
        }
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      const chunks: BlobPart[] = [];
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'video/webm;codecs=vp8,opus'
      });

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: mediaRecorder.mimeType });
        setRecordedVideoBlob(blob);
        setIsRecording(false);
        setRecordingDuration(0);
        
        // Create preview URL
        const previewUrl = URL.createObjectURL(blob);
        setVideoPreviewUrl(previewUrl);
        
        if (recordingInterval.current) {
          clearInterval(recordingInterval.current);
          recordingInterval.current = null;
        }
        
        stream.getTracks().forEach(track => track.stop());
        if (videoRef.current) {
          videoRef.current.srcObject = null;
        }
      };
      
      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start(1000);
      setIsRecording(true);
      
      // Duration counter
      const startTime = Date.now();
      recordingInterval.current = setInterval(() => {
        setRecordingDuration(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);
    } catch (error) {
      toast({
        title: "Camera Access Failed",
        description: "Please allow camera and microphone access for video analysis",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  const handleAnalyze = async () => {
    if (!recordedVideoBlob || !studentName) {
      toast({
        title: "Missing Information",
        description: "Please provide student name and record a video",
        variant: "destructive",
      });
      return;
    }

    try {
      // Convert video blob to base64
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const base64 = (reader.result as string).split(',')[1];
          if (!base64) {
            throw new Error("Failed to convert video to base64");
          }
          
          analyzeMutation.mutate({
            studentName,
            videoBase64: base64,
            sessionType: 'comprehensive'
          });
        } catch (error) {
          toast({
            title: "Video Processing Error",
            description: "Failed to process video for analysis",
            variant: "destructive",
          });
        }
      };
      
      reader.onerror = () => {
        toast({
          title: "File Read Error",
          description: "Unable to read video file",
          variant: "destructive",
        });
      };
      
      reader.readAsDataURL(recordedVideoBlob);
    } catch (error) {
      toast({
        title: "Analysis Error",
        description: "Failed to start video analysis",
        variant: "destructive",
      });
    }
  };

  const handleGenerateReport = () => {
    if (!analysisResult || !studentName) {
      toast({
        title: "Missing Data",
        description: "Please complete analysis and provide student name",
        variant: "destructive",
      });
      return;
    }

    generateReportMutation.mutate({
      analysisData: analysisResult,
      studentName: studentName
    });
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getSeverityBadge = (severity?: string) => {
    if (!severity) return 'bg-gray-100 text-gray-800';
    switch (severity.toLowerCase()) {
      case 'minimal': return 'bg-green-100 text-green-800';
      case 'mild': return 'bg-yellow-100 text-yellow-800';
      case 'moderate': return 'bg-orange-100 text-orange-800';
      case 'severe': return 'bg-red-100 text-red-800';
      case 'very_severe': return 'bg-red-200 text-red-900';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'minimal': return 'text-green-600 dark:text-green-400';
      case 'mild': return 'text-yellow-600 dark:text-yellow-400';
      case 'moderate': return 'text-orange-600 dark:text-orange-400';
      case 'severe': return 'text-red-600 dark:text-red-400';
      case 'very_severe': return 'text-red-800 dark:text-red-300';
      default: return 'text-gray-600 dark:text-gray-400';
    }
  };



  return (
    <div className="space-y-6">
      {/* Research Information Header */}
      {researchInfo && (
        <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/50 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-800 dark:text-blue-200">
              <BookOpen className="h-5 w-5" />
              Advanced Research-Based Analysis System
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-medium text-blue-700 dark:text-blue-300 mb-2">Research Methodology</h4>
                <p className="text-blue-600 dark:text-blue-400">{(researchInfo as any)?.methodology?.title}</p>
                <p className="text-blue-600 dark:text-blue-400 mt-1">{(researchInfo as any)?.methodology?.description}</p>
              </div>
              <div>
                <h4 className="font-medium text-blue-700 dark:text-blue-300 mb-2">Analysis Features</h4>
                <ul className="list-disc list-inside text-blue-600 dark:text-blue-400 space-y-1">
                  {((researchInfo as any)?.features || []).slice(0, 3).map((feature: string, index: number) => (
                    <li key={index}>{feature}</li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={currentTab} onValueChange={setCurrentTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="record">Record Video</TabsTrigger>
          <TabsTrigger value="results">Analysis Results</TabsTrigger>
          <TabsTrigger value="history">Session History</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="record" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Video Recording for Multimodal Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="studentName">Student Name</Label>
                <Input
                  id="studentName"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="Enter student name for tracking"
                />
              </div>

              <div className="space-y-4">
                <div className="aspect-video bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden relative">
                  {isRecording ? (
                    <video
                      ref={videoRef}
                      className="w-full h-full object-cover"
                      muted
                      playsInline
                    />
                  ) : videoPreviewUrl ? (
                    <video
                      src={videoPreviewUrl}
                      className="w-full h-full object-cover"
                      controls
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
                      <div className="text-center">
                        <Camera className="h-12 w-12 mx-auto mb-2" />
                        <p>Video preview will appear here</p>
                      </div>
                    </div>
                  )}
                  
                  {isRecording && (
                    <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full flex items-center gap-2">
                      <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                      <span className="text-sm font-medium">
                        Recording {formatDuration(recordingDuration)}
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex gap-3">
                  {!isRecording ? (
                    <Button 
                      onClick={startRecording} 
                      className="flex items-center gap-2"
                      disabled={!studentName}
                    >
                      <Play className="h-4 w-4" />
                      Start Recording
                    </Button>
                  ) : (
                    <Button 
                      onClick={stopRecording} 
                      variant="destructive"
                      className="flex items-center gap-2"
                    >
                      <Square className="h-4 w-4" />
                      Stop Recording
                    </Button>
                  )}
                  
                  {recordedVideoBlob && (
                    <Button 
                      onClick={handleAnalyze}
                      disabled={analyzeMutation.isPending || !studentName}
                      className="flex items-center gap-2"
                    >
                      <Brain className="h-4 w-4" />
                      {analyzeMutation.isPending ? 'Analyzing...' : 'Analyze Video'}
                    </Button>
                  )}
                </div>

                {analyzeMutation.isPending && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                      <Activity className="h-4 w-4 animate-spin" />
                      Running advanced multimodal depression analysis...
                    </div>
                    <Progress value={33} className="w-full" />
                    <p className="text-xs text-gray-500 dark:text-gray-500">
                      Processing video through ECIR 2024 research methodology
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          {analysisResult ? (
            <div className="space-y-6">
              {/* Risk Score Overview */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5" />
                    Depression Risk Assessment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold mb-2">
                        {Math.round(analysisResult.depressionRiskScore)}%
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Risk Score</p>
                    </div>
                    <div className="text-center">
                      <Badge className={getSeverityBadge(analysisResult.severityLevel)}>
                        {analysisResult.severityLevel?.replace('_', ' ').toUpperCase() || 'UNKNOWN'}
                      </Badge>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">Severity Level</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-semibold mb-2">
                        {Math.round(analysisResult.confidence * 100)}%
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Confidence</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Modality Scores */}
              <Card>
                <CardHeader>
                  <CardTitle>Multimodal Analysis Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysisResult.modalityScores && typeof analysisResult.modalityScores === 'object' ? 
                      Object.entries(analysisResult.modalityScores).map(([modality, score]) => (
                        <div key={modality}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="capitalize">{modality} Analysis</span>
                            <span>{Math.round(Number(score))}%</span>
                          </div>
                          <Progress value={Number(score)} className="w-full" />
                        </div>
                      )) : (
                        <p className="text-gray-500">No modality data available</p>
                      )
                    }
                  </div>
                </CardContent>
              </Card>

              {/* Clinical Indicators */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Microscope className="h-5 w-5" />
                    Clinical Indicators
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    {analysisResult.clinicalIndicators && typeof analysisResult.clinicalIndicators === 'object' && Object.entries(analysisResult.clinicalIndicators).map(([category, indicators]) => (
                      <div key={category}>
                        <h4 className="font-medium mb-2 capitalize">
                          {category?.replace(/([A-Z])/g, ' $1').trim() || 'Unknown'}
                        </h4>
                        <ul className="list-disc list-inside text-sm space-y-1 text-gray-600 dark:text-gray-400">
                          {Array.isArray(indicators) ? indicators.map((indicator: string, index: number) => (
                            <li key={index}>{indicator}</li>
                          )) : null}
                        </ul>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Risk and Protective Factors */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
                      <AlertTriangle className="h-5 w-5" />
                      Risk Factors
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc list-inside text-sm space-y-1">
                      {Array.isArray(analysisResult.riskFactors) ? analysisResult.riskFactors.map((factor, index) => (
                        <li key={index}>{factor}</li>
                      )) : null}
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-green-600 dark:text-green-400">
                      <CheckCircle className="h-5 w-5" />
                      Protective Factors
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc list-inside text-sm space-y-1">
                      {Array.isArray(analysisResult.protectiveFactors) ? analysisResult.protectiveFactors.map((factor, index) => (
                        <li key={index}>{factor}</li>
                      )) : null}
                    </ul>
                  </CardContent>
                </Card>
              </div>

              {/* Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="h-5 w-5" />
                    Intervention Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Recommended Interventions</h4>
                      <ul className="list-disc list-inside text-sm space-y-1">
                        {Array.isArray(analysisResult.interventionRecommendations) ? analysisResult.interventionRecommendations.map((rec, index) => (
                          <li key={index}>{rec}</li>
                        )) : null}
                      </ul>
                    </div>
                    <Separator />
                    <div>
                      <h4 className="font-medium mb-2">Monitoring Requirements</h4>
                      <ul className="list-disc list-inside text-sm space-y-1">
                        {Array.isArray(analysisResult.monitoringNeeds) ? analysisResult.monitoringNeeds.map((need, index) => (
                          <li key={index}>{need}</li>
                        )) : null}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Generate PDF Report Button */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="h-5 w-5" />
                    Download Report
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={handleGenerateReport}
                    disabled={generateReportMutation.isPending}
                    className="w-full flex items-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    {generateReportMutation.isPending ? 'Generating PDF...' : 'Generate Comprehensive PDF Report'}
                  </Button>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                    Download a detailed PDF report with visualizations, clinical insights, and recommendations
                  </p>
                </CardContent>
              </Card>

              {/* Research Findings */}
              {analysisResult?.researchFindings && (
                <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    Research Findings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Non-Verbal Cues Detected</h4>
                      <ul className="list-disc list-inside text-sm space-y-1">
                        {analysisResult?.researchFindings?.nonVerbalCues?.map((cue, index) => (
                          <li key={index}>{cue}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4 mt-4">
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Multimodal Confidence</p>
                        <div className="text-lg font-semibold">
                          {Math.round((analysisResult?.researchFindings?.multimodalConfidence || 0) * 100)}%
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Temporal Consistency</p>
                        <div className="text-lg font-semibold">
                          {Math.round((analysisResult?.researchFindings?.temporalConsistency || 0) * 100)}%
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* Export Options */}
              <div className="flex gap-4 mb-6">
                <Button 
                  onClick={() => downloadAnalysisReport(analysisResult, 'json')}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Download JSON Report
                </Button>
                <Button 
                  onClick={() => downloadAnalysisReport(analysisResult, 'txt')}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <FileText className="h-4 w-4" />
                  Download Text Summary
                </Button>
                <Button 
                  onClick={() => downloadSimpleSummary(analysisResult)}
                  className="flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Download Simple Summary
                </Button>
                <Button 
                  onClick={() => generateNaturalLanguageSummary(analysisResult)}
                  disabled={isGeneratingSummary}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  {isGeneratingSummary ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900"></div>
                      Generating...
                    </>
                  ) : (
                    <>
                      <FileText className="h-4 w-4" />
                      Generate AI Summary
                    </>
                  )}
                </Button>
              </div>

              {/* Comprehensive Analysis Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Clinical Analysis Report
                  </CardTitle>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                    Structured analysis following multimodal depression detection methodology (ECIR 2024)
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* Final Summary Analysis */}
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 p-6 rounded-lg border-l-4 border-l-blue-500">
                      <h3 className="font-bold text-xl text-blue-900 dark:text-blue-100 mb-4">
                        Final Analysis Summary
                      </h3>
                      
                      {/* Key Findings */}
                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div className="bg-white dark:bg-gray-800 p-4 rounded shadow-sm">
                          <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Overall Assessment</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span>Risk Level:</span>
                              <span className={`font-semibold ${
                                analysisResult.severityLevel === 'low' ? 'text-green-600' :
                                analysisResult.severityLevel === 'mild' ? 'text-yellow-600' :
                                analysisResult.severityLevel === 'moderate' ? 'text-orange-600' : 'text-red-600'
                              }`}>
                                {analysisResult.severityLevel?.toUpperCase()}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span>Risk Score:</span>
                              <span className="font-semibold">{Math.round(analysisResult.depressionRiskScore)}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Confidence:</span>
                              <span className="font-semibold">{Math.round(analysisResult.confidence * 100)}%</span>
                            </div>
                          </div>
                        </div>

                        <div className="bg-white dark:bg-gray-800 p-4 rounded shadow-sm">
                          <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Analysis Quality</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span>Best Modality:</span>
                              <span className="font-semibold">
                                {analysisResult.modalityScores ? 
                                  Object.entries(analysisResult.modalityScores)
                                    .sort(([,a], [,b]) => Number(b) - Number(a))[0]?.[0]?.charAt(0).toUpperCase() + 
                                    Object.entries(analysisResult.modalityScores)
                                      .sort(([,a], [,b]) => Number(b) - Number(a))[0]?.[0]?.slice(1) || 'N/A'
                                  : 'N/A'
                                }
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span>Processing Time:</span>
                              <span className="font-semibold">{Math.round((analysisResult.processingTimeMs || 0) / 1000)}s</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Research Based:</span>
                              <span className="font-semibold text-green-600">Yes</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Simple Interpretation */}
                      <div className="bg-white dark:bg-gray-800 p-4 rounded shadow-sm">
                        <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">What This Means</h4>
                        <div className="prose prose-sm dark:prose-invert">
                          {analysisResult.depressionRiskScore < 25 && (
                            <p className="text-green-700 dark:text-green-300">
                              <strong>Low Risk:</strong> The analysis indicates minimal signs of depression. The student appears to be in good mental health with stable emotional patterns.
                            </p>
                          )}
                          {analysisResult.depressionRiskScore >= 25 && analysisResult.depressionRiskScore < 50 && (
                            <p className="text-yellow-700 dark:text-yellow-300">
                              <strong>Mild Concern:</strong> Some indicators suggest mild stress or early warning signs. Preventive measures and regular monitoring are recommended.
                            </p>
                          )}
                          {analysisResult.depressionRiskScore >= 50 && analysisResult.depressionRiskScore < 75 && (
                            <p className="text-orange-700 dark:text-orange-300">
                              <strong>Moderate Risk:</strong> Several concerning patterns detected. Professional consultation and active intervention strategies are advised.
                            </p>
                          )}
                          {analysisResult.depressionRiskScore >= 75 && (
                            <p className="text-red-700 dark:text-red-300">
                              <strong>High Risk:</strong> Multiple serious indicators present. Immediate professional mental health support is strongly recommended.
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Quick Action Items */}
                      <div className="mt-4 bg-gray-50 dark:bg-gray-900 p-4 rounded">
                        <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Immediate Actions Needed</h4>
                        <div className="grid md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-green-600 dark:text-green-400">Recommended:</span>
                            <ul className="mt-1 space-y-1">
                              {analysisResult.interventionRecommendations?.slice(0, 3).map((rec, idx) => (
                                <li key={idx} className="flex items-start gap-1">
                                  <span className="text-green-600">•</span>
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <span className="font-medium text-blue-600 dark:text-blue-400">Monitor:</span>
                            <ul className="mt-1 space-y-1">
                              {analysisResult.monitoringNeeds?.slice(0, 3).map((need, idx) => (
                                <li key={idx} className="flex items-start gap-1">
                                  <span className="text-blue-600">•</span>
                                  <span>{need}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* NLX-Generated Natural Language Summary */}
                    {naturalLanguageSummary && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <FileText className="h-5 w-5" />
                            AI-Generated Natural Language Summary
                          </CardTitle>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            Using NLX-JSON-to-Text methodology for professional interpretation
                          </p>
                        </CardHeader>
                        <CardContent>
                          <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                            <pre className="whitespace-pre-wrap text-sm font-mono">
                              {naturalLanguageSummary}
                            </pre>
                          </div>
                          <div className="mt-4 flex gap-2">
                            <Button
                              onClick={() => {
                                const blob = new Blob([naturalLanguageSummary], { type: 'text/plain' });
                                const url = URL.createObjectURL(blob);
                                const link = document.createElement('a');
                                link.href = url;
                                link.download = `ai_summary_${studentName || 'anonymous'}_${new Date().toISOString().split('T')[0]}.txt`;
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                                URL.revokeObjectURL(url);
                                toast({
                                  title: "AI Summary Downloaded",
                                  description: "Natural language summary has been downloaded.",
                                });
                              }}
                              variant="outline"
                              size="sm"
                            >
                              <Download className="h-4 w-4 mr-2" />
                              Download Summary
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Detailed Findings */}
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold mb-3">Clinical Indicators</h4>
                        <div className="space-y-2">
                          {analysisResult.clinicalIndicators && Object.entries(analysisResult.clinicalIndicators).map(([category, indicators]) => (
                            <div key={category} className="text-sm">
                              <span className="font-medium capitalize">{category.replace(/([A-Z])/g, ' $1').trim()}:</span>
                              <ul className="ml-4 mt-1 text-gray-600 dark:text-gray-400">
                                {Array.isArray(indicators) ? indicators.map((indicator, idx) => (
                                  <li key={idx} className="list-disc">{indicator}</li>
                                )) : <li className="list-disc">{String(indicators)}</li>}
                              </ul>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3">Risk Assessment</h4>
                        <div className="space-y-3">
                          <div>
                            <span className="text-sm font-medium text-red-600 dark:text-red-400">Risk Factors:</span>
                            <ul className="ml-4 mt-1 text-sm text-gray-600 dark:text-gray-400">
                              {analysisResult.riskFactors?.map((factor, idx) => (
                                <li key={idx} className="list-disc">{factor}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <span className="text-sm font-medium text-green-600 dark:text-green-400">Protective Factors:</span>
                            <ul className="ml-4 mt-1 text-sm text-gray-600 dark:text-gray-400">
                              {analysisResult.protectiveFactors?.map((factor, idx) => (
                                <li key={idx} className="list-disc">{factor}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Recommendations */}
                    <div>
                      <h4 className="font-semibold mb-3">Recommended Interventions</h4>
                      <div className="bg-green-50 dark:bg-green-950/20 p-4 rounded-lg">
                        <ul className="space-y-2">
                          {analysisResult.interventionRecommendations?.map((recommendation, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm">
                              <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                              <span>{recommendation}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Monitoring Plan */}
                    <div>
                      <h4 className="font-semibold mb-3">Monitoring Requirements</h4>
                      <div className="bg-amber-50 dark:bg-amber-950/20 p-4 rounded-lg">
                        <ul className="space-y-2">
                          {analysisResult.monitoringNeeds?.map((need, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm">
                              <Clock className="h-4 w-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                              <span>{need}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Technical Analysis */}
                    <div>
                      <h4 className="font-semibold mb-3">Technical Analysis Breakdown</h4>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
                          <div className="font-medium">Modality Scores</div>
                          {analysisResult.modalityScores && Object.entries(analysisResult.modalityScores).map(([key, value]) => (
                            <div key={key} className="flex justify-between mt-1">
                              <span className="capitalize">{key}:</span>
                              <span>{Math.round(Number(value))}%</span>
                            </div>
                          ))}
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
                          <div className="font-medium">Session Info</div>
                          <div className="flex justify-between mt-1">
                            <span>Processing Time:</span>
                            <span>{analysisResult.processingTimeMs}ms</span>
                          </div>
                          <div className="flex justify-between mt-1">
                            <span>Session ID:</span>
                            <span className="truncate ml-2">{analysisResult.sessionId}</span>
                          </div>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
                          <div className="font-medium">Research Metrics</div>
                          {analysisResult.researchFindings && (
                            <>
                              <div className="flex justify-between mt-1">
                                <span>Multimodal Confidence:</span>
                                <span>{Math.round((analysisResult.researchFindings.multimodalConfidence || 0) * 100)}%</span>
                              </div>
                              <div className="flex justify-between mt-1">
                                <span>Temporal Consistency:</span>
                                <span>{Math.round((analysisResult.researchFindings.temporalConsistency || 0) * 100)}%</span>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Raw JSON Data (Collapsible) */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="h-5 w-5" />
                    Technical JSON Data
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                    <details className="group">
                      <summary className="cursor-pointer font-medium mb-2 flex items-center gap-2">
                        <ChevronRight className="h-4 w-4 group-open:rotate-90 transition-transform" />
                        View Complete JSON Analysis Results
                      </summary>
                      <pre className="text-xs overflow-auto max-h-96 bg-white dark:bg-gray-800 p-3 rounded border">
                        {JSON.stringify(analysisResult, null, 2)}
                      </pre>
                    </details>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Brain className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600 dark:text-gray-400">
                  No analysis results yet. Record a video to start the advanced depression analysis.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Analysis History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {previousSessions && previousSessions.length > 0 ? (
                <ScrollArea className="h-96">
                  <div className="space-y-4">
                    {previousSessions.map((session) => (
                      <Card key={session.id} className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h4 className="font-medium">{session.studentName}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {new Date(session.createdAt).toLocaleDateString()} at{' '}
                                {new Date(session.createdAt).toLocaleTimeString()}
                              </p>
                            </div>
                            <Badge className={getSeverityBadge(session.severityLevel)}>
                              {session.severityLevel?.replace('_', ' ') || 'unknown'}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600 dark:text-gray-400">Risk Score:</span>
                              <div className="font-medium">{Math.round(parseFloat(session.depressionRiskScore))}%</div>
                            </div>
                            <div>
                              <span className="text-gray-600 dark:text-gray-400">Confidence:</span>
                              <div className="font-medium">{Math.round(parseFloat(session.confidence) * 100)}%</div>
                            </div>
                            <div>
                              <span className="text-gray-600 dark:text-gray-400">Processing Time:</span>
                              <div className="font-medium">{Math.round(session.processingTimeMs / 1000)}s</div>
                            </div>
                          </div>
                          {session.flaggedForProfessionalReview && (
                            <div className="mt-2 flex items-center gap-2 text-amber-600 dark:text-amber-400">
                              <AlertTriangle className="h-4 w-4" />
                              <span className="text-sm">Flagged for professional review</span>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="text-center py-8">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 dark:text-gray-400">
                    No previous analysis sessions found.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Analysis Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <FileText className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Advanced reporting system coming soon.
                </p>
                <Button variant="outline" disabled>
                  <Download className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}