import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  PlayCircle, 
  X, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle, 
  Star,
  BookOpen,
  Brain,
  MessageSquare,
  Camera,
  Lightbulb,
  ImageIcon,
  BarChart3,
  Users
} from "lucide-react";
import { useLocation } from "wouter";

interface TutorialStep {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  route: string;
  highlights: string[];
  action?: {
    text: string;
    target: string;
  };
}

const tutorialSteps: TutorialStep[] = [
  {
    id: "welcome",
    title: "Welcome to UPSC AI Tools",
    description: "Your comprehensive AI-powered coaching platform for UPSC preparation with mental health support.",
    icon: <Star className="h-6 w-6" />,
    route: "/",
    highlights: [
      "AI-powered mental health coaching",
      "Advanced video analysis capabilities", 
      "Content creation tools for studying",
      "Performance analytics and tracking"
    ]
  },
  {
    id: "mental-health-coach",
    title: "Mental Health Coach",
    description: "Get personalized mental health support, stress management techniques, and study planning guidance.",
    icon: <MessageSquare className="h-6 w-6" />,
    route: "/mental-health",
    highlights: [
      "24/7 AI mental health support",
      "Personalized study planning",
      "Stress management techniques",
      "Learning style assessment"
    ],
    action: {
      text: "Try asking: 'I'm feeling stressed about my upcoming exam'",
      target: "chat-input"
    }
  },
  {
    id: "video-analysis",
    title: "Advanced Mental Health Analysis",
    description: "Record video interviews with AI-powered facial expression analysis and comprehensive mental health monitoring.",
    icon: <Camera className="h-6 w-6" />,
    route: "/mental-health-analysis",
    highlights: [
      "Video interview recording",
      "Real-time facial expression analysis",
      "Emotion detection and scoring",
      "Professional mental health reports"
    ],
    action: {
      text: "Click 'Start Recording' to begin a video assessment",
      target: "start-recording-btn"
    }
  },
  {
    id: "prompt-generator",
    title: "AI Prompt Generator",
    description: "Generate optimized content prompts for YouTube videos, study materials, and educational content.",
    icon: <Lightbulb className="h-6 w-6" />,
    route: "/prompt-generator",
    highlights: [
      "YouTube content optimization",
      "Educational prompt templates",
      "SEO-optimized descriptions",
      "Content strategy suggestions"
    ],
    action: {
      text: "Try generating a prompt for 'UPSC History preparation tips'",
      target: "prompt-input"
    }
  },
  {
    id: "prompt-analytics",
    title: "Prompt Performance Analytics",
    description: "Track your prompt performance, user feedback, and optimization insights with detailed analytics.",
    icon: <BarChart3 className="h-6 w-6" />,
    route: "/prompt-analytics",
    highlights: [
      "Real-time performance metrics",
      "User feedback tracking",
      "Success rate analysis",
      "Content optimization insights"
    ]
  },
  {
    id: "thumbnail-creator",
    title: "AI Thumbnail Creator",
    description: "Create professional YouTube thumbnails using AI with customizable styles and UPSC-focused templates.",
    icon: <ImageIcon className="h-6 w-6" />,
    route: "/thumbnail-creator",
    highlights: [
      "AI-powered thumbnail generation",
      "UPSC-focused templates",
      "Multiple art styles available",
      "High-quality downloads"
    ],
    action: {
      text: "Try creating a thumbnail with 'UPSC Strategy Guide'",
      target: "thumbnail-input"
    }
  }
];

export function TutorialSystem() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [hasSeenTutorial, setHasSeenTutorial] = useState(false);
  const [, setLocation] = useLocation();

  useEffect(() => {
    const seenTutorial = localStorage.getItem("upsc-tutorial-seen");
    const completed = localStorage.getItem("upsc-tutorial-completed");
    
    if (completed) {
      setCompletedSteps(JSON.parse(completed));
    }
    
    if (!seenTutorial) {
      setIsOpen(true);
    } else {
      setHasSeenTutorial(true);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    localStorage.setItem("upsc-tutorial-seen", "true");
    setHasSeenTutorial(true);
  };

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleGoToStep = (route: string) => {
    const stepId = tutorialSteps[currentStep].id;
    const newCompleted = [...completedSteps, stepId];
    setCompletedSteps(newCompleted);
    localStorage.setItem("upsc-tutorial-completed", JSON.stringify(newCompleted));
    
    setLocation(route);
    setIsOpen(false);
  };

  const markStepComplete = (stepId: string) => {
    if (!completedSteps.includes(stepId)) {
      const newCompleted = [...completedSteps, stepId];
      setCompletedSteps(newCompleted);
      localStorage.setItem("upsc-tutorial-completed", JSON.stringify(newCompleted));
    }
  };

  const currentStepData = tutorialSteps[currentStep];
  const progress = ((currentStep + 1) / tutorialSteps.length) * 100;

  return (
    <>
      {/* Tutorial Trigger Button */}
      {hasSeenTutorial && (
        <Button
          onClick={() => setIsOpen(true)}
          variant="outline"
          size="sm"
          className="fixed bottom-4 right-4 z-50 shadow-lg bg-background border-2"
        >
          <BookOpen className="h-4 w-4 mr-2" />
          Tutorial
        </Button>
      )}

      {/* Tutorial Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                {currentStepData.icon}
                Interactive Tutorial
              </DialogTitle>
              <Button variant="ghost" size="sm" onClick={handleClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="space-y-6">
            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{currentStep + 1} of {tutorialSteps.length}</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>

            {/* Current Step Content */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    {currentStepData.icon}
                  </div>
                  <div>
                    <h3 className="text-xl">{currentStepData.title}</h3>
                    <Badge variant="secondary" className="mt-1">
                      Step {currentStep + 1}
                    </Badge>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  {currentStepData.description}
                </p>

                {/* Key Features */}
                <div className="space-y-2">
                  <h4 className="font-medium">Key Features:</h4>
                  <ul className="space-y-1">
                    {currentStepData.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        {highlight}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Suggestion */}
                {currentStepData.action && (
                  <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
                    <p className="text-sm text-blue-800 dark:text-blue-200">
                      <strong>Try this:</strong> {currentStepData.action.text}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex items-center justify-between">
              <Button 
                variant="outline" 
                onClick={handlePrevious}
                disabled={currentStep === 0}
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>

              <div className="flex gap-2">
                <Button 
                  onClick={() => handleGoToStep(currentStepData.route)}
                  className="px-6"
                >
                  <PlayCircle className="h-4 w-4 mr-2" />
                  Try It Now
                </Button>

                {currentStep < tutorialSteps.length - 1 ? (
                  <Button onClick={handleNext}>
                    Next
                    <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                ) : (
                  <Button onClick={handleClose} variant="default">
                    Finish Tutorial
                  </Button>
                )}
              </div>
            </div>

            {/* Step Overview */}
            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">Tutorial Overview</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {tutorialSteps.map((step, index) => (
                  <Button
                    key={step.id}
                    variant={index === currentStep ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setCurrentStep(index)}
                    className="justify-start h-auto p-2"
                  >
                    <div className="flex items-center gap-2">
                      {completedSteps.includes(step.id) ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        step.icon
                      )}
                      <span className="text-xs truncate">{step.title}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Hook for other components to mark tutorial steps as complete
export function useTutorial() {
  const markStepComplete = (stepId: string) => {
    const completed = JSON.parse(localStorage.getItem("upsc-tutorial-completed") || "[]");
    if (!completed.includes(stepId)) {
      const newCompleted = [...completed, stepId];
      localStorage.setItem("upsc-tutorial-completed", JSON.stringify(newCompleted));
    }
  };

  const resetTutorial = () => {
    localStorage.removeItem("upsc-tutorial-seen");
    localStorage.removeItem("upsc-tutorial-completed");
    window.location.reload();
  };

  return { markStepComplete, resetTutorial };
}