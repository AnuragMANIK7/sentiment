import { useState, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Camera, 
  AlertTriangle, 
  Shield, 
  TrendingUp,
  BarChart3,
  Eye,
  Mic,
  Activity,
  Clock,
  BookOpen,
  ExternalLink
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AdvancedAnalysisResult {
  sessionId: string;
  analysis: {
    depressionRiskScore: number;
    severityLevel: 'minimal' | 'mild' | 'moderate' | 'severe' | 'very_severe';
    confidence: number;
    modalityScores: {
      audio: number;
      facial: number;
      behavioral: number;
      temporal: number;
    };
    clinicalIndicators: {
      speechPatterns: string[];
      facialExpressions: string[];
      behavioralCues: string[];
      temporalPatterns: string[];
    };
    riskFactors: string[];
    protectiveFactors: string[];
    interventionRecommendations: string[];
    monitoringNeeds: string[];
    researchFindings: {
      nonVerbalCues: string[];
      multimodalConfidence: number;
      temporalConsistency: number;
    };
  };
  metadata: {
    researchBased: boolean;
    methodology: string;
    modalitiesAnalyzed: string[];
    confidence: number;
  };
}

interface ResearchInfo {
  methodology: {
    title: string;
    conference: string;
    authors: string[];
    repository: string;
  };
  approach: {
    type: string;
    modalities: string[];
    architecture: string;
    datasets: string[];
  };
  performance: {
    achievement: string;
    specialization: string;
    interpretability: string;
  };
  clinicalNote: string;
}

export default function AdvancedDepressionAnalysis() {
  const [studentName, setStudentName] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordedVideoBlob, setRecordedVideoBlob] = useState<Blob | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AdvancedAnalysisResult | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingInterval = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Research information query
  const { data: researchInfo } = useQuery<ResearchInfo>({
    queryKey: ['/api/advanced-depression/research-info'],
  });

  // Advanced analysis mutation
  const analyzeMutation = useMutation({
    mutationFn: async (data: { studentName: string; videoBase64: string; sessionType: string }) => {
      const response = await apiRequest('POST', '/api/advanced-depression/analyze', data);
      return await response.json() as AdvancedAnalysisResult;
    },
    onSuccess: (data) => {
      setAnalysisResult(data);
      toast({
        title: "Advanced Analysis Complete",
        description: `Depression risk analysis completed for ${studentName}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to perform advanced depression analysis",
        variant: "destructive",
      });
    },
  });

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 1280, height: 720 }, 
        audio: true 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        
        const mediaRecorder = new MediaRecorder(stream, { 
          mimeType: MediaRecorder.isTypeSupported('video/mp4') ? 'video/mp4' : 'video/webm' 
        });
        
        const chunks: BlobPart[] = [];
        
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            chunks.push(event.data);
          }
        };
        
        mediaRecorder.onstop = () => {
          const blob = new Blob(chunks, { type: mediaRecorder.mimeType });
          setRecordedVideoBlob(blob);
          setIsRecording(false);
          setRecordingDuration(0);
          
          if (recordingInterval.current) {
            clearInterval(recordingInterval.current);
            recordingInterval.current = null;
          }
          
          stream.getTracks().forEach(track => track.stop());
          if (videoRef.current) {
            videoRef.current.srcObject = null;
          }
        };
        
        mediaRecorderRef.current = mediaRecorder;
        mediaRecorder.start(1000);
        setIsRecording(true);
        
        // Duration counter
        const startTime = Date.now();
        recordingInterval.current = setInterval(() => {
          setRecordingDuration(Math.floor((Date.now() - startTime) / 1000));
        }, 1000);
      }
    } catch (error) {
      toast({
        title: "Camera Access Failed",
        description: "Please allow camera and microphone access for video analysis",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
    }
  };

  const handleAnalyze = async () => {
    if (!recordedVideoBlob || !studentName) {
      toast({
        title: "Missing Information",
        description: "Please provide student name and record a video",
        variant: "destructive",
      });
      return;
    }

    // Convert video blob to base64
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      analyzeMutation.mutate({
        studentName,
        videoBase64: base64,
        sessionType: 'comprehensive'
      });
    };
    reader.readAsDataURL(recordedVideoBlob);
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'minimal': return 'text-green-600';
      case 'mild': return 'text-yellow-600';
      case 'moderate': return 'text-orange-600';
      case 'severe': return 'text-red-600';
      case 'very_severe': return 'text-red-800';
      default: return 'text-gray-600';
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'minimal': return 'bg-green-100 text-green-800 border-green-300';
      case 'mild': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'moderate': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'severe': return 'bg-red-100 text-red-800 border-red-300';
      case 'very_severe': return 'bg-red-200 text-red-900 border-red-400';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Research Information Header */}
      {researchInfo && (
        <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-800 dark:text-blue-200">
              <BookOpen className="h-5 w-5" />
              Research-Based Analysis System
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm text-blue-700 dark:text-blue-300">
              <p className="font-medium">{researchInfo.methodology.title}</p>
              <p className="text-xs mt-1">{researchInfo.methodology.conference} • {researchInfo.methodology.authors.slice(0, 2).join(", ")} et al.</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4 text-xs">
              <div>
                <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">Multimodal Approach</h4>
                <ul className="space-y-1 text-blue-600 dark:text-blue-400">
                  {researchInfo.approach.modalities.map((modality, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                      {modality}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">Performance</h4>
                <p className="text-blue-600 dark:text-blue-400">{researchInfo.performance.achievement}</p>
                <p className="text-blue-600 dark:text-blue-400 mt-1">{researchInfo.performance.specialization}</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-2 border-t border-blue-200 dark:border-blue-800">
              <p className="text-xs text-blue-600 dark:text-blue-400">
                {researchInfo.clinicalNote}
              </p>
              <Button variant="outline" size="sm" asChild className="border-blue-300 text-blue-700">
                <a href={researchInfo.methodology.repository} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-3 w-3 mr-1" />
                  View Research
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Video Recording and Analysis */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="h-5 w-5" />
              Multimodal Video Capture
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="advancedStudentName">Student Name *</Label>
              <Input
                id="advancedStudentName"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder="Enter student name for advanced analysis"
              />
            </div>

            <div className="bg-muted border-2 border-dashed border-border rounded-lg aspect-video flex items-center justify-center relative">
              {isRecording ? (
                <div className="relative w-full h-full bg-black rounded-lg">
                  <video
                    ref={videoRef}
                    autoPlay
                    muted
                    className="w-full h-full object-cover rounded-lg"
                  />
                  <div className="absolute top-2 left-2 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center gap-2 z-10">
                    <div className="w-2 h-2 bg-white rounded-full animate-ping" />
                    ADVANCED REC {formatDuration(recordingDuration)}
                  </div>
                  <div className="absolute top-2 right-2 bg-blue-600 text-white px-2 py-1 rounded text-xs z-10">
                    MULTIMODAL
                  </div>
                </div>
              ) : recordedVideoBlob ? (
                <div className="text-center text-muted-foreground">
                  <Brain className="h-12 w-12 mx-auto mb-2 text-blue-600" />
                  <p className="text-sm">Advanced video captured!</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Ready for multimodal depression analysis
                  </p>
                </div>
              ) : (
                <div className="text-center text-muted-foreground">
                  <Camera className="h-12 w-12 mx-auto mb-2" />
                  <p className="text-sm">Start advanced multimodal recording</p>
                  <p className="text-xs mt-1">Captures facial expressions, speech patterns, and behavioral cues</p>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              {!isRecording && !recordedVideoBlob ? (
                <Button onClick={startRecording} className="flex-1" disabled={!studentName}>
                  <Camera className="h-4 w-4 mr-2" />
                  Start Advanced Recording
                </Button>
              ) : isRecording ? (
                <Button onClick={stopRecording} variant="destructive" className="flex-1">
                  <Activity className="h-4 w-4 mr-2" />
                  Stop Recording ({formatDuration(recordingDuration)})
                </Button>
              ) : (
                <div className="flex gap-2 flex-1">
                  <Button 
                    onClick={() => {
                      setRecordedVideoBlob(null);
                    }} 
                    variant="outline" 
                    className="flex-1"
                  >
                    Record Again
                  </Button>
                  <Button 
                    onClick={handleAnalyze}
                    disabled={analyzeMutation.isPending}
                    className="flex-1"
                  >
                    {analyzeMutation.isPending ? "Analyzing..." : "🧠 Advanced Analysis"}
                  </Button>
                </div>
              )}
            </div>

            {recordedVideoBlob && (
              <div className="text-xs text-muted-foreground bg-blue-50 dark:bg-blue-950 p-2 rounded">
                ✓ Video ready for advanced multimodal depression analysis using ECIR 2024 research methodology.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Analysis Results */}
        {analysisResult && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Advanced Analysis Results
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Risk Score and Severity */}
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className={`text-3xl font-bold ${getSeverityColor(analysisResult.analysis.severityLevel)}`}>
                    {analysisResult.analysis.depressionRiskScore}%
                  </div>
                  <div className="text-sm text-muted-foreground">Depression Risk</div>
                </div>
                
                <div className="text-center">
                  <Badge className={getSeverityBadge(analysisResult.analysis.severityLevel)}>
                    {analysisResult.analysis.severityLevel.replace('_', ' ').toUpperCase()}
                  </Badge>
                  <div className="text-sm text-muted-foreground mt-1">Severity Level</div>
                </div>
              </div>

              {/* Modality Scores */}
              <div className="space-y-3">
                <h4 className="font-medium flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  Modality Analysis
                </h4>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Mic className="h-3 w-3" />
                    <span className="text-xs font-medium">Audio/Speech:</span>
                    <Progress value={analysisResult.analysis.modalityScores.audio} className="flex-1 h-2" />
                    <span className="text-xs">{Math.round(analysisResult.analysis.modalityScores.audio)}%</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Eye className="h-3 w-3" />
                    <span className="text-xs font-medium">Facial:</span>
                    <Progress value={analysisResult.analysis.modalityScores.facial} className="flex-1 h-2" />
                    <span className="text-xs">{Math.round(analysisResult.analysis.modalityScores.facial)}%</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Activity className="h-3 w-3" />
                    <span className="text-xs font-medium">Behavioral:</span>
                    <Progress value={analysisResult.analysis.modalityScores.behavioral} className="flex-1 h-2" />
                    <span className="text-xs">{Math.round(analysisResult.analysis.modalityScores.behavioral)}%</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Clock className="h-3 w-3" />
                    <span className="text-xs font-medium">Temporal:</span>
                    <Progress value={analysisResult.analysis.modalityScores.temporal} className="flex-1 h-2" />
                    <span className="text-xs">{Math.round(analysisResult.analysis.modalityScores.temporal)}%</span>
                  </div>
                </div>
              </div>

              {/* Research Confidence */}
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded border border-green-200 dark:border-green-800">
                <div className="flex items-center gap-2 text-green-800 dark:text-green-200 text-sm">
                  <Shield className="h-4 w-4" />
                  <span className="font-medium">Research Confidence</span>
                </div>
                <div className="mt-1 text-xs text-green-700 dark:text-green-300">
                  Multimodal: {Math.round(analysisResult.analysis.researchFindings.multimodalConfidence * 100)}% • 
                  Temporal: {Math.round(analysisResult.analysis.researchFindings.temporalConsistency * 100)}%
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Detailed Analysis Results */}
      {analysisResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Comprehensive Analysis Report
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Clinical Indicators */}
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-3">Clinical Indicators Detected</h4>
                <div className="space-y-3">
                  <div>
                    <h5 className="text-sm font-medium text-muted-foreground mb-1">Speech Patterns</h5>
                    <ul className="text-xs space-y-1">
                      {analysisResult.analysis.clinicalIndicators.speechPatterns.map((pattern, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1 h-1 bg-red-500 rounded-full mt-1.5 flex-shrink-0" />
                          {pattern}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h5 className="text-sm font-medium text-muted-foreground mb-1">Facial Expressions</h5>
                    <ul className="text-xs space-y-1">
                      {analysisResult.analysis.clinicalIndicators.facialExpressions.map((expression, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1 h-1 bg-orange-500 rounded-full mt-1.5 flex-shrink-0" />
                          {expression}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3">Behavioral & Temporal Patterns</h4>
                <div className="space-y-3">
                  <div>
                    <h5 className="text-sm font-medium text-muted-foreground mb-1">Behavioral Cues</h5>
                    <ul className="text-xs space-y-1">
                      {analysisResult.analysis.clinicalIndicators.behavioralCues.map((cue, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1 h-1 bg-blue-500 rounded-full mt-1.5 flex-shrink-0" />
                          {cue}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h5 className="text-sm font-medium text-muted-foreground mb-1">Temporal Patterns</h5>
                    <ul className="text-xs space-y-1">
                      {analysisResult.analysis.clinicalIndicators.temporalPatterns.map((pattern, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1 h-1 bg-purple-500 rounded-full mt-1.5 flex-shrink-0" />
                          {pattern}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Intervention Recommendations */}
            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">AI-Generated Intervention Recommendations</h4>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h5 className="text-sm font-medium text-green-700 dark:text-green-300 mb-2">Recommended Interventions</h5>
                  <ul className="text-xs space-y-1">
                    {analysisResult.analysis.interventionRecommendations.map((rec, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-1 h-1 bg-green-500 rounded-full mt-1.5 flex-shrink-0" />
                        {rec}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h5 className="text-sm font-medium text-blue-700 dark:text-blue-300 mb-2">Monitoring Needs</h5>
                  <ul className="text-xs space-y-1">
                    {analysisResult.analysis.monitoringNeeds.map((need, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-1 h-1 bg-blue-500 rounded-full mt-1.5 flex-shrink-0" />
                        {need}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Research Findings */}
            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg border">
              <h4 className="font-medium mb-3 flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Research-Based Non-Verbal Cues Detected
              </h4>
              <ul className="text-xs space-y-1">
                {analysisResult.analysis.researchFindings.nonVerbalCues.map((cue, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <div className="w-1 h-1 bg-indigo-500 rounded-full mt-1.5 flex-shrink-0" />
                    {cue}
                  </li>
                ))}
              </ul>
            </div>

            {/* Professional Review Flag */}
            {analysisResult.analysis.depressionRiskScore > 60 && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center gap-2 text-red-800">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="font-medium">Professional Review Recommended</span>
                </div>
                <p className="text-sm text-red-700 mt-1">
                  Based on multimodal analysis, this student shows significant depression risk indicators and should be referred for professional mental health assessment.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}