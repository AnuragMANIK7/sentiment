import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { User } from "lucide-react";

interface UsernameInputProps {
  onUsernameSet: (username: string) => void;
  currentUsername?: string;
}

export default function UsernameInput({ onUsernameSet, currentUsername }: UsernameInputProps) {
  const [username, setUsername] = useState(currentUsername || "");
  const [isEditing, setIsEditing] = useState(!currentUsername);

  // Load username from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("upsc_username");
    if (saved && !currentUsername) {
      setUsername(saved);
      onUsernameSet(saved);
      setIsEditing(false);
    }
  }, [currentUsername, onUsernameSet]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim().length >= 2) {
      const trimmedUsername = username.trim();
      localStorage.setItem("upsc_username", trimmedUsername);
      onUsernameSet(trimmedUsername);
      setIsEditing(false);
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  if (!isEditing && currentUsername) {
    return (
      <div className="flex items-center gap-2 p-2 bg-muted rounded-lg">
        <User className="w-4 h-4" />
        <span className="text-sm font-medium">{currentUsername}</span>
        <Button variant="ghost" size="sm" onClick={handleEdit}>
          Change
        </Button>
      </div>
    );
  }

  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="w-5 h-5" />
          {currentUsername ? "Change Username" : "Enter Your Name"}
        </CardTitle>
        <CardDescription>
          Your name will be used to save your chat history and generated content across all modules.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Enter your username (e.g., john_doe)"
            className="flex-1"
            minLength={2}
            required
          />
          <Button type="submit" disabled={username.trim().length < 2}>
            {currentUsername ? "Update" : "Save"}
          </Button>
          {currentUsername && (
            <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
              Cancel
            </Button>
          )}
        </form>
      </CardContent>
    </Card>
  );
}