import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Camera, Play, Pause, RotateCcw, Eye, Brain, AlertTriangle, Target } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'easy' | 'medium' | 'hard';
  subject: string;
}

interface FacialMetrics {
  attentionScore: number;
  drowsinessLevel: number;
  emotion: string;
  confidence: number;
  blinkRate: number;
  eyeOpenness: number;
  faceDetected: boolean;
}

interface QuizSession {
  id: string;
  studentName: string;
  questions: QuizQuestion[];
  startTime: string;
  endTime?: string;
  adaptiveMode: boolean;
  timeLimit: number;
}

export default function FacialAnalysisQuiz() {
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [currentSession, setCurrentSession] = useState<QuizSession | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [facialMetrics, setFacialMetrics] = useState<FacialMetrics | null>(null);
  const [alertCount, setAlertCount] = useState(0);
  const [studentName, setStudentName] = useState("");
  const [quizTopic, setQuizTopic] = useState("");
  const [difficultyLevel, setDifficultyLevel] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [showQuizPopup, setShowQuizPopup] = useState(false);
  const [popupQuestion, setPopupQuestion] = useState<QuizQuestion | null>(null);
  const [popupAnswer, setPopupAnswer] = useState<number | null>(null);
  const [hasTriggeredQuiz, setHasTriggeredQuiz] = useState(false);
  const [timeLimit, setTimeLimit] = useState(30);
  const [adaptiveMode, setAdaptiveMode] = useState(true);
  const [analysisInterval, setAnalysisInterval] = useState<NodeJS.Timeout | null>(null);

  // Cleanup intervals on unmount
  useEffect(() => {
    return () => {
      if (analysisInterval) {
        clearInterval(analysisInterval);
      }
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [analysisInterval, stream]);

  // Generate quiz questions
  const generateQuizMutation = useMutation({
    mutationFn: async (params: {
      topic: string;
      difficulty: string;
      questionCount: number;
      adaptiveMode: boolean;
      timeLimit: number;
    }) => {
      const response = await apiRequest('POST', '/api/facial-quiz/generate', {
        ...params,
        studentName: 'Anonymous'
      });
      return await response.json() as QuizSession;
    },
    onSuccess: (data) => {
      setCurrentSession(data);
      setCurrentQuestionIndex(0);
      setSelectedAnswers({});
      setAlertCount(0);
      toast({
        title: "Quiz Generated",
        description: `Created ${data.questions.length} questions on ${quizTopic}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Quiz Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Start facial monitoring
  const startCamera = async () => {
    try {
      console.log("Requesting camera access...");
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: 640, 
          height: 480,
          facingMode: 'user'
        }
      });
      
      console.log("Camera stream obtained:", mediaStream);
      setStream(mediaStream);
      setIsRecording(true);
      
      // Set video stream after state is set
      setTimeout(() => {
        if (videoRef.current && mediaStream) {
          videoRef.current.srcObject = mediaStream;
          console.log("Video stream assigned to video element");
        }
      }, 100);
      
      // Start facial analysis simulation
      startFacialAnalysis();
      
      toast({
        title: "Camera Started",
        description: "Facial monitoring is now active",
      });
    } catch (error: any) {
      console.error("Camera error:", error);
      toast({
        title: "Camera Access Failed",
        description: error.message || "Unable to access camera for facial monitoring",
        variant: "destructive",
      });
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (analysisInterval) {
      clearInterval(analysisInterval);
      setAnalysisInterval(null);
    }
    setIsRecording(false);
    setFacialMetrics(null);
  };

  const startFacialAnalysis = () => {
    // Clear any existing interval
    if (analysisInterval) {
      clearInterval(analysisInterval);
    }
    
    // Simulate facial analysis metrics
    const interval = setInterval(() => {
      const metrics: FacialMetrics = {
        attentionScore: Math.random() * 100,
        drowsinessLevel: Math.random() * 100,
        emotion: ['focused', 'confused', 'tired', 'alert'][Math.floor(Math.random() * 4)],
        confidence: 0.8 + Math.random() * 0.2,
        blinkRate: 15 + Math.random() * 10,
        eyeOpenness: 0.7 + Math.random() * 0.3,
        faceDetected: true
      };
      
      setFacialMetrics(metrics);
      
      // Check for attention alerts and auto-trigger quiz popup
      if (metrics.drowsinessLevel > 60 || metrics.attentionScore < 40) {
        setAlertCount(prev => prev + 1);
        if (metrics.drowsinessLevel > 60 && !hasTriggeredQuiz && !showQuizPopup) {
          setHasTriggeredQuiz(true);
          toast({
            title: "Drowsiness Detected",
            description: "Engagement question appearing to restore focus...",
            variant: "destructive",
          });
          // Auto-trigger popup quiz when drowsiness is detected
          triggerPopupQuiz();
        }
      } else if (metrics.drowsinessLevel < 30 && metrics.attentionScore > 70) {
        // Reset trigger when attention is restored
        setHasTriggeredQuiz(false);
      }
    }, 2000);
    
    setAnalysisInterval(interval);
  };

  // Generate random popup quiz question
  const triggerPopupQuiz = () => {
    const topics = ["Indian History", "Geography", "Polity", "Economics", "Current Affairs", "Science & Technology"];
    const randomTopic = topics[Math.floor(Math.random() * topics.length)];
    
    generateSingleQuestionMutation.mutate({
      topic: randomTopic,
      difficulty: "medium",
      questionCount: 1,
      adaptiveMode: false,
      timeLimit: 30,
    });
  };

  // Generate single question for popup
  const generateSingleQuestionMutation = useMutation({
    mutationFn: async (params: {
      topic: string;
      difficulty: string;
      questionCount: number;
      adaptiveMode: boolean;
      timeLimit: number;
    }) => {
      const response = await apiRequest('POST', '/api/facial-quiz/generate', {
        ...params,
        studentName: 'Anonymous'
      });
      return await response.json() as QuizSession;
    },
    onSuccess: (data) => {
      if (data.questions && data.questions.length > 0) {
        setPopupQuestion(data.questions[0]);
        setShowQuizPopup(true);
        setPopupAnswer(null);
      }
    },
    onError: (error) => {
      console.error("Failed to generate popup question:", error);
    },
  });

  const handlePopupAnswer = (answerIndex: number) => {
    setPopupAnswer(answerIndex);
    
    if (popupQuestion && answerIndex === popupQuestion.correctAnswer) {
      toast({
        title: "Correct Answer!",
        description: "Well done! Focus restored.",
      });
      setTimeout(() => {
        setShowQuizPopup(false);
        setPopupQuestion(null);
        setPopupAnswer(null);
      }, 1500);
    } else {
      toast({
        title: "Incorrect Answer",
        description: `Correct answer: ${popupQuestion?.options[popupQuestion.correctAnswer]}`,
        variant: "destructive",
      });
      setTimeout(() => {
        setShowQuizPopup(false);
        setPopupQuestion(null);
        setPopupAnswer(null);
      }, 3000);
    }
  };

  const handleAnswerSelect = (questionId: string, answerIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }));
  };

  const handleNextQuestion = () => {
    if (currentSession && currentQuestionIndex < currentSession.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const submitQuizMutation = useMutation({
    mutationFn: async (params: {
      sessionId: string;
      answers: Record<string, number>;
      facialData: any[];
    }) => {
      const response = await apiRequest('/api/facial-quiz/submit', 'POST', params);
      return response as unknown as { score: number; totalQuestions: number; feedback: string };
    },
    onSuccess: (data) => {
      toast({
        title: "Quiz Submitted",
        description: `Score: ${data.score}%. Facial attention analysis included.`,
      });
      setCurrentSession(null);
      stopCamera();
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmitQuiz = () => {
    if (!currentSession) return;
    
    submitQuizMutation.mutate({
      sessionId: currentSession.id,
      answers: selectedAnswers,
      facialData: [] // In real app, this would contain captured facial metrics
    });
  };

  const currentQuestion = currentSession?.questions[currentQuestionIndex];
  const progress = currentSession ? ((currentQuestionIndex + 1) / currentSession.questions.length) * 100 : 0;

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">UPSC Facial Analysis Quiz</h1>
        <p className="text-muted-foreground">
          Smart popup questions appear when drowsiness is detected
        </p>
        
        {/* Auto-trigger notification */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mx-auto max-w-2xl">
          <div className="flex items-center gap-2 text-blue-800">
            <Target className="h-4 w-4" />
            <span className="font-medium">Smart Engagement System</span>
          </div>
          <p className="text-sm text-blue-600 mt-1">
            When drowsiness level exceeds 60%, a random UPSC question popup appears. 
            Answer correctly to close the popup and restore focus.
          </p>
        </div>
      </div>

      {!currentSession ? (
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Quiz Setup */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Quiz Configuration
              </CardTitle>
              <CardDescription>
                Set up your personalized UPSC quiz with facial monitoring
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="studentName">Your Name</Label>
                  <Input
                    id="studentName"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="Enter your name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timeLimit">Time Limit (minutes)</Label>
                  <Input
                    id="timeLimit"
                    type="number"
                    value={timeLimit}
                    onChange={(e) => setTimeLimit(Number(e.target.value))}
                    min="5"
                    max="120"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="monitoring">Drowsiness Monitoring</Label>
                <div className="p-3 bg-gray-50 rounded border text-sm text-gray-600">
                  📊 Real-time monitoring active
                  <br />
                  🎯 Random UPSC questions appear when drowsiness detected
                  <br />
                  ✅ Answer correctly to close popup and restore focus
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Alert Thresholds</Label>
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span>Drowsiness trigger:</span>
                      <Badge variant="destructive">60%</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Attention threshold:</span>
                      <Badge variant="outline">40%</Badge>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Mode</Label>
                  <Button
                    variant={adaptiveMode ? "default" : "outline"}
                    size="sm"
                    onClick={() => setAdaptiveMode(!adaptiveMode)}
                    className="w-full"
                  >
                    {adaptiveMode ? "Adaptive Mode" : "Standard Mode"}
                  </Button>
                </div>
              </div>

              <Button
                onClick={() => generateQuizMutation.mutate({
                  topic: quizTopic,
                  difficulty: difficultyLevel,
                  questionCount: 10,
                  adaptiveMode,
                  timeLimit
                })}
                disabled={!studentName || !quizTopic || generateQuizMutation.isPending}
                className="w-full"
                size="lg"
              >
                {generateQuizMutation.isPending ? "Generating Quiz..." : "Generate Quiz"}
              </Button>
            </CardContent>
          </Card>

          {/* Camera Setup */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Facial Monitoring Setup
              </CardTitle>
              <CardDescription>
                Enable camera for attention and drowsiness detection
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                {isRecording && stream ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    muted
                    playsInline
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  <div className="text-center">
                    <Camera className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                    <p className="text-gray-500">
                      {isRecording ? 'Loading camera preview...' : 'Camera preview will appear here'}
                    </p>
                  </div>
                )}
              </div>
              
              <div className="flex gap-2">
                <Button
                  onClick={isRecording ? stopCamera : startCamera}
                  variant={isRecording ? "destructive" : "default"}
                  className="flex-1"
                >
                  {isRecording ? (
                    <>
                      <Pause className="h-4 w-4 mr-2" />
                      Stop Camera
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Start Camera
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Quiz Progress */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-4">
                  <Badge variant="outline">
                    Question {currentQuestionIndex + 1} of {currentSession.questions.length}
                  </Badge>
                  {alertCount > 0 && (
                    <Badge variant="destructive" className="flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" />
                      {alertCount} Alerts
                    </Badge>
                  )}
                </div>
                <div className="text-sm text-muted-foreground">
                  {Math.round(progress)}% Complete
                </div>
              </div>
              <Progress value={progress} className="h-2" />
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quiz Question */}
            <div className="lg:col-span-2 space-y-6">
              {currentQuestion && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {currentQuestion.question}
                    </CardTitle>
                    <div className="flex gap-2">
                      <Badge variant="secondary">{currentQuestion.subject}</Badge>
                      <Badge variant="outline" className="capitalize">
                        {currentQuestion.difficulty}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {currentQuestion.options.map((option, index) => (
                      <button
                        key={index}
                        onClick={() => handleAnswerSelect(currentQuestion.id, index)}
                        className={`w-full text-left p-4 rounded-lg border-2 transition-colors ${
                          selectedAnswers[currentQuestion.id] === index
                            ? "border-blue-500 bg-blue-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full border-2 ${
                            selectedAnswers[currentQuestion.id] === index
                              ? "border-blue-500 bg-blue-500"
                              : "border-gray-300"
                          }`}>
                            {selectedAnswers[currentQuestion.id] === index && (
                              <div className="w-full h-full rounded-full bg-white scale-50"></div>
                            )}
                          </div>
                          <span>{option}</span>
                        </div>
                      </button>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Navigation */}
              <div className="flex justify-between">
                <Button
                  onClick={handlePreviousQuestion}
                  disabled={currentQuestionIndex === 0}
                  variant="outline"
                >
                  Previous
                </Button>
                <div className="flex gap-2">
                  {currentQuestionIndex === currentSession.questions.length - 1 ? (
                    <Button
                      onClick={handleSubmitQuiz}
                      disabled={submitQuizMutation.isPending}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {submitQuizMutation.isPending ? "Submitting..." : "Submit Quiz"}
                    </Button>
                  ) : (
                    <Button onClick={handleNextQuestion}>
                      Next
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {/* Facial Monitoring Panel */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Eye className="h-4 w-4" />
                    Live Monitoring
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Camera Feed */}
                  <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                    {isRecording && stream ? (
                      <video
                        ref={videoRef}
                        autoPlay
                        muted
                        playsInline
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Camera className="h-8 w-8 text-gray-400" />
                        <div className="ml-2 text-sm text-gray-500">
                          {isRecording ? 'Loading camera...' : 'Camera off'}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Metrics */}
                  {facialMetrics && (
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm">
                          <span>Attention Score</span>
                          <span className={`font-medium ${
                            facialMetrics.attentionScore > 70 ? 'text-green-600' :
                            facialMetrics.attentionScore > 40 ? 'text-yellow-600' : 'text-red-600'
                          }`}>
                            {Math.round(facialMetrics.attentionScore)}%
                          </span>
                        </div>
                        <Progress value={facialMetrics.attentionScore} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between text-sm">
                          <span>Drowsiness Level</span>
                          <span className={`font-medium ${
                            facialMetrics.drowsinessLevel < 30 ? 'text-green-600' :
                            facialMetrics.drowsinessLevel < 70 ? 'text-yellow-600' : 'text-red-600'
                          }`}>
                            {Math.round(facialMetrics.drowsinessLevel)}%
                          </span>
                        </div>
                        <Progress value={facialMetrics.drowsinessLevel} className="h-2" />
                      </div>

                      <Separator />

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Emotion</span>
                          <Badge variant="secondary" className="capitalize">
                            {facialMetrics.emotion}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Eye Openness</span>
                          <span>{Math.round(facialMetrics.eyeOpenness * 100)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Blink Rate</span>
                          <span>{Math.round(facialMetrics.blinkRate)}/min</span>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}

      {/* Drowsiness Quiz Popup */}
      <Dialog open={showQuizPopup} onOpenChange={setShowQuizPopup}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Drowsiness Detected - Focus Restoration Quiz
            </DialogTitle>
          </DialogHeader>
          
          {popupQuestion && (
            <div className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-sm text-yellow-800">
                  <strong>Topic:</strong> {popupQuestion.subject} | <strong>Difficulty:</strong> {popupQuestion.difficulty}
                </p>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">{popupQuestion.question}</h3>
                
                <div className="space-y-2">
                  {popupQuestion.options.map((option, index) => (
                    <Button
                      key={index}
                      variant={
                        popupAnswer === index
                          ? index === popupQuestion.correctAnswer
                            ? "default"
                            : "destructive"
                          : "outline"
                      }
                      className="w-full text-left justify-start p-4 h-auto"
                      onClick={() => handlePopupAnswer(index)}
                      disabled={popupAnswer !== null}
                    >
                      <span className="font-medium mr-2">{String.fromCharCode(65 + index)}.</span>
                      {option}
                    </Button>
                  ))}
                </div>
                
                {popupAnswer !== null && (
                  <div className="mt-4 p-4 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="text-sm text-blue-800">
                      {popupAnswer === popupQuestion.correctAnswer
                        ? "✅ Correct! Well done. Your focus is being restored."
                        : `❌ Incorrect. The correct answer is: ${popupQuestion.options[popupQuestion.correctAnswer]}`
                      }
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}