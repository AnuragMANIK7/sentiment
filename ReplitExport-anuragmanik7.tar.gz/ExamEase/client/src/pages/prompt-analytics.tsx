import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertPromptFeedbackSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Area, AreaChart
} from "recharts";
import { 
  TrendingUp, TrendingDown, Users, Clock, Star, AlertCircle,
  Activity, Target, Zap, ThumbsUp, MessageSquare, BarChart3
} from "lucide-react";
import type { z } from "zod";

type FeedbackFormData = z.infer<typeof insertPromptFeedbackSchema>;

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function PromptAnalytics() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPromptId, setSelectedPromptId] = useState<string>("all");
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);

  // Fetch analytics data
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/prompts/analytics", selectedPromptId],
    queryFn: () => fetch(`/api/prompts/analytics/${selectedPromptId}`).then(res => res.json()),
    enabled: true,
  });

  // Fetch all prompts for selection
  const { data: prompts } = useQuery({
    queryKey: ["/api/prompts"],
  });

  // Fetch usage metrics
  const { data: usageMetrics } = useQuery({
    queryKey: ["/api/prompts/usage-metrics", selectedPromptId],
    queryFn: () => fetch(`/api/prompts/usage-metrics/${selectedPromptId}`).then(res => res.json()),
    enabled: true,
  });

  // Feedback form
  const form = useForm<FeedbackFormData>({
    resolver: zodResolver(insertPromptFeedbackSchema.omit({ promptId: true })),
    defaultValues: {
      rating: 5,
      effectiveness: "very_effective",
    },
  });

  const feedbackMutation = useMutation({
    mutationFn: async (data: FeedbackFormData) => {
      const response = await fetch(`/api/prompts/${selectedPromptId}/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to submit feedback");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Feedback Submitted",
        description: "Thank you for your feedback! It helps us improve our prompts.",
      });
      setShowFeedbackForm(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/prompts/analytics"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit feedback",
        variant: "destructive",
      });
    },
  });

  const onSubmitFeedback = (data: FeedbackFormData) => {
    feedbackMutation.mutate(data);
  };

  if (analyticsLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  const categoryData = analytics?.categoryBreakdown ? 
    Object.entries(analytics.categoryBreakdown).map(([name, value]) => ({ name, value })) : 
    [];

  // Default analytics data for empty state
  const defaultAnalytics = {
    totalUsage: 0,
    averageRating: 0,
    averageGenerationTime: 0,
    successRate: 0,
    categoryBreakdown: {},
    recentTrends: []
  };

  const displayAnalytics = analytics || defaultAnalytics;

  return (
    <div className="container mx-auto py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">Prompt Analytics</h1>
          <p className="text-muted-foreground">Track performance and optimize your content generation</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={selectedPromptId} onValueChange={setSelectedPromptId}>
            <SelectTrigger className="w-60">
              <SelectValue placeholder="All prompts" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All prompts</SelectItem>
              {Array.isArray(prompts) && prompts.map((prompt: any) => (
                <SelectItem key={prompt.id} value={prompt.id}>
                  {prompt.category} - {prompt.contentTopic || "General"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedPromptId && selectedPromptId !== "all" && (
            <Button 
              variant="outline" 
              onClick={() => setShowFeedbackForm(true)}
              className="flex items-center gap-2"
            >
              <MessageSquare className="h-4 w-4" />
              Give Feedback
            </Button>
          )}
        </div>
      </div>

      {analytics && (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Usage</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{displayAnalytics.totalUsage.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  +20.1% from last month
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{displayAnalytics.averageRating.toFixed(1)}</div>
                <div className="flex items-center text-xs text-muted-foreground">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +0.3 from last week
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{displayAnalytics.successRate.toFixed(1)}%</div>
                <p className="text-xs text-muted-foreground">
                  Excellent performance
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg Generation Time</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{(displayAnalytics.averageGenerationTime / 1000).toFixed(1)}s</div>
                <div className="flex items-center text-xs text-muted-foreground">
                  <TrendingDown className="h-3 w-3 mr-1" />
                  -0.2s improvement
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts and Analytics */}
          <Tabs defaultValue="trends" className="space-y-4">
            <TabsList>
              <TabsTrigger value="trends">Usage Trends</TabsTrigger>
              <TabsTrigger value="categories">Categories</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="feedback">User Feedback</TabsTrigger>
            </TabsList>

            <TabsContent value="trends" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Usage & Rating Trends</CardTitle>
                  <CardDescription>Daily usage patterns and user satisfaction over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={displayAnalytics.recentTrends}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis yAxisId="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Area 
                        yAxisId="left"
                        type="monotone" 
                        dataKey="usage" 
                        stroke="#8884d8" 
                        fill="#8884d8"
                        fillOpacity={0.3}
                        name="Usage Count"
                      />
                      <Line 
                        yAxisId="right"
                        type="monotone" 
                        dataKey="rating" 
                        stroke="#82ca9d" 
                        strokeWidth={2}
                        name="Average Rating"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="categories" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Category Distribution</CardTitle>
                    <CardDescription>Usage breakdown by content type</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Category Performance</CardTitle>
                    <CardDescription>Success rate by content type</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={categoryData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="performance" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5" />
                      Speed Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Average Response Time</span>
                      <Badge variant="secondary">{(displayAnalytics.averageGenerationTime / 1000).toFixed(1)}s</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Fastest Generation</span>
                      <Badge variant="secondary">0.8s</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">95th Percentile</span>
                      <Badge variant="secondary">3.2s</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5" />
                      Quality Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Success Rate</span>
                      <Badge variant="secondary">{displayAnalytics.successRate.toFixed(1)}%</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">User Satisfaction</span>
                      <Badge variant="secondary">{displayAnalytics.averageRating.toFixed(1)}/5</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Retry Rate</span>
                      <Badge variant="secondary">2.1%</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Usage Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Total Generations</span>
                      <Badge variant="secondary">{displayAnalytics.totalUsage.toLocaleString()}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Unique Sessions</span>
                      <Badge variant="secondary">{Math.floor(displayAnalytics.totalUsage * 0.7).toLocaleString()}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Peak Daily Usage</span>
                      <Badge variant="secondary">
                        {displayAnalytics.recentTrends.length > 0 ? Math.max(...displayAnalytics.recentTrends.map((t: any) => t.usage)).toLocaleString() : "0"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="feedback" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent User Feedback</CardTitle>
                    <CardDescription>Latest reviews and suggestions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="border-l-4 border-green-500 pl-4">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="flex text-yellow-400">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className="h-4 w-4 fill-current" />
                            ))}
                          </div>
                          <span className="text-sm text-muted-foreground">2 hours ago</span>
                        </div>
                        <p className="text-sm">"Excellent prompts for YouTube content. Very detailed and actionable!"</p>
                      </div>
                      <div className="border-l-4 border-blue-500 pl-4">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="flex text-yellow-400">
                            {[...Array(4)].map((_, i) => (
                              <Star key={i} className="h-4 w-4 fill-current" />
                            ))}
                            <Star className="h-4 w-4" />
                          </div>
                          <span className="text-sm text-muted-foreground">1 day ago</span>
                        </div>
                        <p className="text-sm">"Good quality but could use more specific examples for UPSC content."</p>
                      </div>
                      <div className="border-l-4 border-green-500 pl-4">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="flex text-yellow-400">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className="h-4 w-4 fill-current" />
                            ))}
                          </div>
                          <span className="text-sm text-muted-foreground">2 days ago</span>
                        </div>
                        <p className="text-sm">"Perfect for creating engaging educational content. Highly recommended!"</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Feedback Summary</CardTitle>
                    <CardDescription>Overall user sentiment and suggestions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">5 Stars</span>
                          <span className="text-sm text-muted-foreground">68%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-green-500 h-2 rounded-full" style={{ width: '68%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">4 Stars</span>
                          <span className="text-sm text-muted-foreground">22%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-blue-500 h-2 rounded-full" style={{ width: '22%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">3 Stars</span>
                          <span className="text-sm text-muted-foreground">7%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '7%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">2 Stars</span>
                          <span className="text-sm text-muted-foreground">2%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '2%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">1 Star</span>
                          <span className="text-sm text-muted-foreground">1%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-red-500 h-2 rounded-full" style={{ width: '1%' }}></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </>
      )}

      {/* Feedback Form Modal */}
      {showFeedbackForm && selectedPromptId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Share Your Feedback</CardTitle>
              <CardDescription>Help us improve our prompt generation</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmitFeedback)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="rating"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rating</FormLabel>
                        <FormControl>
                          <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue="5">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="5">⭐⭐⭐⭐⭐ Excellent</SelectItem>
                              <SelectItem value="4">⭐⭐⭐⭐ Good</SelectItem>
                              <SelectItem value="3">⭐⭐⭐ Average</SelectItem>
                              <SelectItem value="2">⭐⭐ Poor</SelectItem>
                              <SelectItem value="1">⭐ Very Poor</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="effectiveness"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How effective was this prompt?</FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} defaultValue="very_effective">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="very_effective">Very Effective</SelectItem>
                              <SelectItem value="effective">Effective</SelectItem>
                              <SelectItem value="somewhat_effective">Somewhat Effective</SelectItem>
                              <SelectItem value="not_effective">Not Effective</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="useCase"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How did you use this prompt?</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., YouTube video script, blog post..." {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="feedback"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Additional Feedback (Optional)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Share your experience or suggestions for improvement..."
                            className="min-h-[80px]"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end gap-2 pt-4">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowFeedbackForm(false)}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" disabled={feedbackMutation.isPending}>
                      {feedbackMutation.isPending ? "Submitting..." : "Submit Feedback"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}