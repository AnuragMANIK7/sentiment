import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Image, Download, Clock } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Thumbnail } from "@shared/schema";

export default function ThumbnailCreator() {
  const [formData, setFormData] = useState({
    videoTitle: "",
    contentCategory: "",
    style: "professional",
    textOverlay: "",
    colorScheme: "blue",
    elements: {
      arrows: false,
      icons: false,
      branding: false,
      urgency: false,
    },
  });
  const [generatedThumbnail, setGeneratedThumbnail] = useState<Thumbnail | null>(null);
  const { toast } = useToast();

  const { data: recentThumbnails } = useQuery<Thumbnail[]>({
    queryKey: ["/api/thumbnails"],
  });

  const generateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/thumbnails", data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedThumbnail(data);
      queryClient.invalidateQueries({ queryKey: ["/api/thumbnails"] });
      toast({
        title: "Success",
        description: "Thumbnail generated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate thumbnail",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.videoTitle.trim()) {
      toast({
        title: "Error",
        description: "Please enter a video title",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate(formData);
  };

  const downloadThumbnail = (format: 'png' | 'jpg') => {
    if (!generatedThumbnail?.imageUrl) return;
    
    const link = document.createElement('a');
    link.href = generatedThumbnail.imageUrl;
    link.download = `${formData.videoTitle.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.${format}`;
    link.click();
  };

  const categories = [
    { value: "history", label: "History" },
    { value: "polity", label: "Polity & Constitution" },
    { value: "geography", label: "Geography" },
    { value: "economics", label: "Economics" },
    { value: "current-affairs", label: "Current Affairs" },
    { value: "general-studies", label: "General Studies" },
    { value: "optional-subjects", label: "Optional Subjects" },
  ];

  const styles = [
    { value: "professional", label: "Professional" },
    { value: "vibrant", label: "Vibrant" },
    { value: "minimalist", label: "Minimalist" },
    { value: "academic", label: "Academic" },
  ];

  const colorSchemes = [
    { value: "blue", label: "Blue", color: "bg-blue-500" },
    { value: "green", label: "Green", color: "bg-green-500" },
    { value: "purple", label: "Purple", color: "bg-purple-500" },
    { value: "red", label: "Red", color: "bg-red-500" },
    { value: "orange", label: "Orange", color: "bg-orange-500" },
    { value: "gray", label: "Gray", color: "bg-gray-500" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <div className="flex items-center mb-4">
          <Image className="h-6 w-6 text-accent mr-3" />
          <h1 className="text-2xl font-bold text-foreground">AI Thumbnail Creator</h1>
        </div>
        <p className="text-muted-foreground">
          Create stunning, AI-powered YouTube thumbnails optimized for educational content and maximum engagement.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Creation Form */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Thumbnail Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="videoTitle">Video Topic/Title *</Label>
                  <Input
                    id="videoTitle"
                    value={formData.videoTitle}
                    onChange={(e) => setFormData(prev => ({ ...prev, videoTitle: e.target.value }))}
                    placeholder="e.g., Indian Constitution - Fundamental Rights Explained"
                  />
                </div>

                <div>
                  <Label htmlFor="contentCategory">Content Category</Label>
                  <Select value={formData.contentCategory} onValueChange={(value) => setFormData(prev => ({ ...prev, contentCategory: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category..." />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Thumbnail Style</Label>
                  <div className="grid grid-cols-2 gap-3 mt-2">
                    {styles.map((style) => (
                      <Label
                        key={style.value}
                        className={`flex items-center p-3 border rounded-lg cursor-pointer hover:bg-muted transition-colors ${
                          formData.style === style.value ? 'border-accent bg-accent/10' : 'border-border'
                        }`}
                      >
                        <input
                          type="radio"
                          name="thumbnailStyle"
                          value={style.value}
                          checked={formData.style === style.value}
                          onChange={(e) => setFormData(prev => ({ ...prev, style: e.target.value }))}
                          className="sr-only"
                        />
                        <span className="text-sm">{style.label}</span>
                      </Label>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="textOverlay">Text Overlay</Label>
                  <Input
                    id="textOverlay"
                    value={formData.textOverlay}
                    onChange={(e) => setFormData(prev => ({ ...prev, textOverlay: e.target.value }))}
                    placeholder="Main text to display on thumbnail"
                  />
                </div>

                <div>
                  <Label>Color Scheme</Label>
                  <div className="flex gap-2 mt-2">
                    {colorSchemes.map((scheme) => (
                      <button
                        key={scheme.value}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, colorScheme: scheme.value }))}
                        className={`w-8 h-8 rounded border-2 transition-all ${scheme.color} ${
                          formData.colorScheme === scheme.value ? 'border-accent scale-110' : 'border-border'
                        }`}
                        title={scheme.label}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <Label>Additional Elements</Label>
                  <div className="space-y-2 mt-2">
                    {Object.entries({
                      arrows: "Add arrows/pointers",
                      icons: "Include subject icons",
                      branding: "Add institute branding",
                      urgency: "Add urgency indicators",
                    }).map(([key, label]) => (
                      <div key={key} className="flex items-center space-x-2">
                        <Checkbox
                          id={key}
                          checked={formData.elements[key as keyof typeof formData.elements]}
                          onCheckedChange={(checked) =>
                            setFormData(prev => ({
                              ...prev,
                              elements: { ...prev.elements, [key]: checked }
                            }))
                          }
                        />
                        <Label htmlFor={key} className="text-sm">
                          {label}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-accent hover:bg-accent/90"
                  disabled={generateMutation.isPending}
                >
                  <Image className="h-4 w-4 mr-2" />
                  {generateMutation.isPending ? "Generating..." : "Generate Thumbnail"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Preview & Gallery */}
        <div className="space-y-6">
          {/* Generated Thumbnail Preview */}
          <Card>
            <CardHeader>
              <CardTitle>Generated Thumbnail</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-muted border-2 border-dashed border-border rounded-lg aspect-video flex items-center justify-center mb-4">
                {generatedThumbnail?.imageUrl ? (
                  <img
                    src={generatedThumbnail.imageUrl}
                    alt="Generated thumbnail"
                    className="w-full h-full object-cover rounded-lg"
                    crossOrigin="anonymous"
                  />
                ) : (
                  <div className="text-center text-muted-foreground">
                    <Image className="h-12 w-12 mx-auto mb-2" />
                    <p className="text-sm">Your thumbnail will appear here</p>
                  </div>
                )}
              </div>

              {generatedThumbnail && (
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    onClick={() => downloadThumbnail('png')}
                    className="text-sm"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download PNG
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => downloadThumbnail('jpg')}
                    className="text-sm"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download JPG
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Thumbnails */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Recent Creations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {recentThumbnails && recentThumbnails.length > 0 ? (
                  recentThumbnails.map((thumbnail) => (
                    <div
                      key={thumbnail.id}
                      className="flex items-center gap-3 p-2 bg-muted rounded hover:bg-muted/80 transition-colors cursor-pointer"
                    >
                      <div className="w-12 h-7 bg-border rounded flex-shrink-0 overflow-hidden">
                        {thumbnail.imageUrl && (
                          <img
                            src={thumbnail.imageUrl}
                            alt={thumbnail.videoTitle}
                            className="w-full h-full object-cover"
                          />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">
                          {thumbnail.videoTitle}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {thumbnail.createdAt ? new Date(thumbnail.createdAt).toLocaleDateString() : 'Recent'}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No recent thumbnails. Create your first thumbnail to get started!
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
