import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Video, 
  Brain, 
  AlertTriangle, 
  TrendingUp, 
  Users, 
  Camera, 
  FileText, 
  BarChart3,
  Heart,
  Shield
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AdvancedDepressionAnalysis from "@/components/AdvancedDepressionAnalysis";

interface AnalysisResult {
  sessionId: string;
  analysis: {
    riskScore: number;
    alertLevel: 'low' | 'medium' | 'high' | 'critical';
    recommendations: string[];
    emotionSummary: string[];
    sentimentScore: number;
    flaggedForReview: boolean;
    reasoning?: {
      emotionFactors: string[];
      sentimentFactors: string[];
      riskFactors: string[];
      positiveFactors: string[];
      scoreBreakdown: {
        emotionScore: number;
        sentimentScore: number;
        riskIndicatorScore: number;
        finalScore: number;
      };
    };
    detailedAnalysis?: {
      emotionBreakdown: any[];
      sentimentDetails: any;
      keyFindings: {
        dominantEmotions: string[];
        riskIndicators: string[];
        keyPhrases: string[];
      };
    };
  };
}

interface MentalHealthSession {
  id: string;
  studentName: string;
  sessionType: string;
  riskScore: string;
  alertLevel: string;
  recommendations: any;
  flaggedForReview: boolean;
  createdAt: string;
}

interface Analytics {
  summary: {
    totalSessions: number;
    highRiskCount: number;
    averageRiskScore: number;
    riskPercentage: number;
  };
  distribution: Record<string, number>;
  recentTrends: Array<{
    date: string;
    riskScore: number;
    alertLevel: string;
  }>;
  flaggedStudents: Array<{
    studentName: string;
    riskScore: string;
    alertLevel: string;
    lastSession: string;
  }>;
}

export default function MentalHealthAnalysis() {
  const [activeTab, setActiveTab] = useState("interview");
  const [formData, setFormData] = useState({
    studentName: "",
    sessionType: "video_interview",
    videoUrl: "",
    textResponses: {
      stress_level: "",
      sleep_quality: "",
      study_motivation: "",
      social_support: "",
      coping_strategies: "",
      academic_pressure: "",
    },
  });
  const [isRecording, setIsRecording] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [recordedVideoBlob, setRecordedVideoBlob] = useState<Blob | null>(null);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [mediaRecorderState, setMediaRecorderState] = useState<'inactive' | 'recording' | 'paused'>('inactive');
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingInterval = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Fetch recent sessions
  const { data: recentSessions } = useQuery<MentalHealthSession[]>({
    queryKey: ["/api/mental-health/sessions"],
  });

  // Fetch analytics data
  const { data: analytics } = useQuery<Analytics>({
    queryKey: ["/api/mental-health/analytics"],
  });

  // Analysis mutation
  const analyzeMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/mental-health/analyze", data);
      return response.json();
    },
    onSuccess: (data) => {
      setAnalysisResult(data);
      queryClient.invalidateQueries({ queryKey: ["/api/mental-health/sessions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/mental-health/analytics"] });
      toast({
        title: "Analysis Complete",
        description: `Mental health analysis completed for ${formData.studentName}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "Failed to analyze mental health",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a student name",
        variant: "destructive",
      });
      return;
    }
    
    analyzeMutation.mutate(formData);
  };

  // Fixed recording with proper state management and MP4 support
  const startVideoRecording = async () => {
    try {
      console.log('🎥 Starting video recording...');
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 1280, height: 720 },
        audio: true 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        console.log('📹 Camera access granted, setting up recording...');
        
        // Use MP4 compatible format if available, fallback to webm
        const mimeType = MediaRecorder.isTypeSupported('video/mp4') ? 'video/mp4' : 'video/webm';
        console.log(`🎬 Using format: ${mimeType}`);
        
        const mediaRecorder = new MediaRecorder(stream, { mimeType });
        
        const chunks: BlobPart[] = [];
        
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            chunks.push(event.data);
            console.log(`📦 Recorded chunk: ${event.data.size} bytes`);
          }
        };
        
        mediaRecorder.onstop = () => {
          console.log('🛑 Recording stopped, processing video...');
          const blob = new Blob(chunks, { type: mimeType });
          setRecordedVideoBlob(blob);
          
          // Create URL for playback and download
          const videoUrl = URL.createObjectURL(blob);
          setRecordedVideoUrl(videoUrl);
          setFormData(prev => ({ ...prev, videoUrl }));
          
          console.log(`✅ Video blob created: ${blob.size} bytes`);
          
          // Reset states properly
          setIsRecording(false);
          setMediaRecorderState('inactive');
          setRecordingDuration(0);
          if (recordingInterval.current) {
            clearInterval(recordingInterval.current);
            recordingInterval.current = null;
          }
          
          // Stop the camera stream
          stream.getTracks().forEach(track => track.stop());
          if (videoRef.current) {
            videoRef.current.srcObject = null;
          }
          
          toast({
            title: "Recording Complete",
            description: "Video recorded successfully. You can now download or analyze it.",
          });
        };
        
        mediaRecorder.onstart = () => {
          console.log('🎬 MediaRecorder started - updating state');
          setIsRecording(true);
          setMediaRecorderState('recording');
          setRecordingDuration(0);
          // Force re-render
          setTimeout(() => {
            console.log('🔄 Force state update after MediaRecorder start');
            setIsRecording(true);
          }, 100);
        };
        
        mediaRecorderRef.current = mediaRecorder;
        
        // Set recording state immediately before starting
        setIsRecording(true);
        setMediaRecorderState('recording');
        setRecordingDuration(0);
        
        // Start recording
        mediaRecorder.start(1000);
        console.log('📹 MediaRecorder.start() called');
        
        // Start duration counter
        const startTime = Date.now();
        recordingInterval.current = setInterval(() => {
          const elapsed = Math.floor((Date.now() - startTime) / 1000);
          console.log(`⏰ Recording duration: ${elapsed} seconds`);
          setRecordingDuration(elapsed);
          
          // Force re-render every second to ensure UI updates
          setMediaRecorderState('recording');
        }, 1000);
        
        toast({
          title: "Recording Started",
          description: "Video recording in progress. Click 'Stop Recording' when finished.",
        });
      }
    } catch (error) {
      console.error('Recording error:', error);
      setIsRecording(false);
      setMediaRecorderState('inactive');
      toast({
        title: "Camera Access Failed",
        description: "Please allow camera and microphone access for video analysis",
        variant: "destructive",
      });
    }
  };

  const stopVideoRecording = () => {
    console.log('🛑 Stopping video recording...');
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      console.log('📹 MediaRecorder.stop() called');
    }
  };

  const downloadRecordedVideo = () => {
    if (recordedVideoBlob) {
      console.log('📥 Starting video download...');
      const url = URL.createObjectURL(recordedVideoBlob);
      const a = document.createElement('a');
      a.href = url;
      // Use .webm extension since that's the actual format recorded
      a.download = `mental-health-interview-${formData.studentName || 'recording'}-${new Date().toISOString().slice(0, 10)}.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Video Downloaded",
        description: "Video file saved to your device (WebM format, compatible with modern players)",
      });
      console.log('✅ Video download completed');
    } else {
      toast({
        title: "No Video Found",
        description: "Please record a video first before downloading",
        variant: "destructive",
      });
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getAlertBadgeColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRiskScoreColor = (score: number) => {
    if (score < 30) return 'text-green-600';
    if (score < 60) return 'text-yellow-600';
    if (score < 80) return 'text-orange-600';
    return 'text-red-600';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <div className="flex items-center mb-4">
          <Brain className="h-6 w-6 text-accent mr-3" />
          <h1 className="text-2xl font-bold text-foreground">Mental Health Analysis</h1>
        </div>
        <p className="text-muted-foreground">
          Comprehensive mental health monitoring using AI-powered facial expression analysis and text sentiment evaluation for UPSC aspirants.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="interview" className="flex items-center gap-2">
            <Video className="h-4 w-4" />
            Video Interview
          </TabsTrigger>
          <TabsTrigger value="advanced" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Advanced Analysis
          </TabsTrigger>
          <TabsTrigger value="assessment" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Text Assessment
          </TabsTrigger>
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="sessions" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Recent Sessions
          </TabsTrigger>
        </TabsList>

        {/* Video Interview Tab */}
        <TabsContent value="interview" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="h-5 w-5" />
                  Video Recording Setup
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="studentName">Student Name *</Label>
                  <Input
                    id="studentName"
                    value={formData.studentName}
                    onChange={(e) => setFormData(prev => ({ ...prev, studentName: e.target.value }))}
                    placeholder="Enter student name for analysis"
                  />
                </div>

                <div className="bg-muted border-2 border-dashed border-border rounded-lg aspect-video flex items-center justify-center relative">
                  {console.log('🎬 UI Render - isRecording:', isRecording, 'duration:', recordingDuration, 'hasBlob:', !!recordedVideoBlob)}
                  {isRecording ? (
                    <div className="relative w-full h-full bg-black rounded-lg">
                      <video
                        ref={videoRef}
                        autoPlay
                        muted
                        className="w-full h-full object-cover rounded-lg"
                      />
                      <div className="absolute top-2 left-2 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center gap-2 z-10 shadow-lg">
                        <div className="w-3 h-3 bg-white rounded-full animate-ping" />
                        REC {formatDuration(recordingDuration)}
                      </div>
                      <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 rounded text-xs z-10">
                        Recording: {formatDuration(recordingDuration)}
                      </div>
                      <div className="absolute top-2 right-2 bg-green-600 text-white px-2 py-1 rounded text-xs z-10">
                        LIVE
                      </div>
                    </div>
                  ) : recordedVideoBlob ? (
                    <div className="text-center text-muted-foreground">
                      <Video className="h-12 w-12 mx-auto mb-2 text-green-600" />
                      <p className="text-sm">Video recorded successfully!</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Size: {Math.round(recordedVideoBlob.size / 1024 / 1024 * 100) / 100} MB
                      </p>
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground">
                      <Camera className="h-12 w-12 mx-auto mb-2" />
                      <p className="text-sm">Click below to start video recording</p>
                      <p className="text-xs mt-1">HD quality with audio capture</p>
                    </div>
                  )}
                </div>

                {/* Advanced Analysis Info */}
                <div className="text-xs bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800 mb-4">
                  <div className="font-semibold text-blue-800 dark:text-blue-200 mb-1">
                    🧠 Advanced Depression Detection System
                  </div>
                  <div className="text-blue-600 dark:text-blue-300 text-xs">
                    Using multimodal analysis (BiLSTM + CNN) from Early Depression Detection research
                  </div>
                  <div className="text-xs text-blue-500 dark:text-blue-400 mt-1">
                    Status: Recording={isRecording.toString()}, Duration={recordingDuration}s, Video={!!recordedVideoBlob}
                  </div>
                </div>

                <div className="flex gap-2">
                  {!isRecording && !recordedVideoBlob ? (
                    <Button onClick={startVideoRecording} className="flex-1">
                      <Camera className="h-4 w-4 mr-2" />
                      Start Recording
                    </Button>
                  ) : isRecording ? (
                    <div className="flex gap-2 flex-1">
                      <Button 
                        onClick={stopVideoRecording} 
                        variant="destructive" 
                        className="flex-1 animate-pulse"
                        size="lg"
                      >
                        <Video className="h-4 w-4 mr-2" />
                        STOP RECORDING ({formatDuration(recordingDuration)})
                      </Button>
                      <div className="bg-red-100 dark:bg-red-900/20 px-4 py-3 rounded-lg border-2 border-red-300 flex items-center gap-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full animate-ping" />
                        <span className="text-sm font-bold text-red-700 dark:text-red-300">
                          REC: {formatDuration(recordingDuration)}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-2 flex-1">
                      <Button 
                        onClick={() => {
                          setRecordedVideoBlob(null);
                          setFormData(prev => ({ ...prev, videoUrl: "" }));
                        }} 
                        variant="outline" 
                        className="flex-1"
                      >
                        Record Again
                      </Button>
                      <Button 
                        onClick={() => downloadRecordedVideo()}
                        variant="outline"
                        className="flex-1"
                      >
                        📹 Download Video
                      </Button>
                      <Button 
                        onClick={handleSubmit}
                        disabled={analyzeMutation.isPending}
                        className="flex-1"
                      >
                        {analyzeMutation.isPending ? "Analyzing..." : "Analyze Video"}
                      </Button>
                    </div>
                  )}
                </div>

                {recordedVideoBlob && (
                  <div className="text-xs text-muted-foreground bg-green-50 dark:bg-green-950 p-2 rounded">
                    ✓ Video stored in browser memory. Ready for AI analysis including facial expression detection and sentiment analysis.
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Mental Health Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label>Current stress level (1-10)</Label>
                    <Input
                      type="number"
                      min="1"
                      max="10"
                      value={formData.textResponses.stress_level}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        textResponses: { ...prev.textResponses, stress_level: e.target.value }
                      }))}
                      placeholder="Rate your stress level"
                    />
                  </div>

                  <div>
                    <Label>Sleep quality</Label>
                    <Textarea
                      value={formData.textResponses.sleep_quality}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        textResponses: { ...prev.textResponses, sleep_quality: e.target.value }
                      }))}
                      placeholder="Describe your sleep patterns and quality"
                      rows={2}
                    />
                  </div>

                  <div>
                    <Label>Study motivation</Label>
                    <Textarea
                      value={formData.textResponses.study_motivation}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        textResponses: { ...prev.textResponses, study_motivation: e.target.value }
                      }))}
                      placeholder="How motivated do you feel about your UPSC preparation?"
                      rows={2}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-accent hover:bg-accent/90"
                    disabled={analyzeMutation.isPending}
                  >
                    <Brain className="h-4 w-4 mr-2" />
                    {analyzeMutation.isPending ? "Analyzing..." : "Start Mental Health Analysis"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Analysis Results */}
          {analysisResult && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  Analysis Results for {formData.studentName}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className={`text-3xl font-bold ${getRiskScoreColor(analysisResult.analysis.riskScore)}`}>
                      {analysisResult.analysis.riskScore}%
                    </div>
                    <div className="text-sm text-muted-foreground">Risk Score</div>
                  </div>
                  
                  <div className="text-center">
                    <Badge className={getAlertBadgeColor(analysisResult.analysis.alertLevel)}>
                      {analysisResult.analysis.alertLevel.toUpperCase()}
                    </Badge>
                    <div className="text-sm text-muted-foreground mt-1">Alert Level</div>
                  </div>
                  
                  <div className="text-center">
                    <div className={`text-3xl font-bold ${analysisResult.analysis.sentimentScore >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {analysisResult.analysis.sentimentScore > 0 ? '+' : ''}{(analysisResult.analysis.sentimentScore * 100).toFixed(0)}%
                    </div>
                    <div className="text-sm text-muted-foreground">Sentiment</div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Dominant Emotions Detected:</h4>
                  <div className="flex flex-wrap gap-2">
                    {analysisResult.analysis.emotionSummary.map((emotion, index) => (
                      <Badge key={index} variant="secondary">
                        {emotion}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">AI Recommendations:</h4>
                  <ul className="list-disc list-inside space-y-1">
                    {analysisResult.analysis.recommendations.map((rec, index) => (
                      <li key={index} className="text-sm text-muted-foreground">{rec}</li>
                    ))}
                  </ul>
                </div>

                {analysisResult.analysis.flaggedForReview && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <div className="flex items-center gap-2 text-red-800">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="font-medium">Flagged for Professional Review</span>
                    </div>
                    <p className="text-sm text-red-700 mt-1">
                      This student has been flagged for follow-up with a mental health professional.
                    </p>
                  </div>
                )}

                {/* Detailed Reasoning Section */}
                {analysisResult.analysis.reasoning && (
                  <div className="border-t pt-4 mt-4">
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                      <Brain className="h-4 w-4" />
                      Detailed Analysis Reasoning
                    </h4>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      {/* Score Breakdown */}
                      <div className="space-y-3">
                        <h5 className="text-sm font-medium text-muted-foreground">Score Breakdown</h5>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Emotion Score:</span>
                            <span className="font-medium">{analysisResult.analysis.reasoning.scoreBreakdown.emotionScore}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Sentiment Score:</span>
                            <span className="font-medium">{analysisResult.analysis.reasoning.scoreBreakdown.sentimentScore}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Risk Indicators:</span>
                            <span className="font-medium">{analysisResult.analysis.reasoning.scoreBreakdown.riskIndicatorScore}</span>
                          </div>
                          <div className="flex justify-between text-sm font-bold border-t pt-2">
                            <span>Final Score:</span>
                            <span>{analysisResult.analysis.reasoning.scoreBreakdown.finalScore}</span>
                          </div>
                        </div>
                      </div>

                      {/* Key Factors */}
                      <div className="space-y-3">
                        <h5 className="text-sm font-medium text-muted-foreground">Key Analysis Factors</h5>
                        <div className="space-y-2">
                          {analysisResult.analysis.reasoning.emotionFactors.length > 0 && (
                            <div>
                              <span className="text-xs font-medium text-orange-600">Emotion Factors:</span>
                              <ul className="text-xs text-muted-foreground ml-2">
                                {analysisResult.analysis.reasoning.emotionFactors.map((factor, i) => (
                                  <li key={i}>• {factor}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          {analysisResult.analysis.reasoning.riskFactors.length > 0 && (
                            <div>
                              <span className="text-xs font-medium text-red-600">Risk Factors:</span>
                              <ul className="text-xs text-muted-foreground ml-2">
                                {analysisResult.analysis.reasoning.riskFactors.map((factor, i) => (
                                  <li key={i}>• {factor}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {analysisResult.analysis.reasoning.positiveFactors.length > 0 && (
                            <div>
                              <span className="text-xs font-medium text-green-600">Positive Factors:</span>
                              <ul className="text-xs text-muted-foreground ml-2">
                                {analysisResult.analysis.reasoning.positiveFactors.map((factor, i) => (
                                  <li key={i}>• {factor}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Export Section */}
                <div className="border-t pt-4 mt-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Export Complete Package</h4>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={async () => {
                          try {
                            const response = await fetch(`/api/mental-health/export/${analysisResult.sessionId}`);
                            const blob = await response.blob();
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `mental-health-report-${formData.studentName}-${analysisResult.sessionId.slice(0, 8)}.json`;
                            document.body.appendChild(a);
                            a.click();
                            window.URL.revokeObjectURL(url);
                            document.body.removeChild(a);
                            toast({
                              title: "Report Exported",
                              description: "Mental health analysis report downloaded successfully",
                            });
                          } catch (error) {
                            toast({
                              title: "Export Failed",
                              description: "Failed to export analysis report",
                              variant: "destructive",
                            });
                          }
                        }}
                      >
                        📊 Analysis Report
                      </Button>
                      {recordedVideoBlob && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={async () => {
                            const url = URL.createObjectURL(recordedVideoBlob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `video-${formData.studentName}-${analysisResult.sessionId.slice(0, 8)}.webm`;
                            document.body.appendChild(a);
                            a.click();
                            document.body.removeChild(a);
                            URL.revokeObjectURL(url);
                            toast({
                              title: "Video Downloaded",
                              description: "Original recording saved with analysis",
                            });
                          }}
                        >
                          🎥 Video File
                        </Button>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Downloads comprehensive analysis report (JSON) and original video recording (WebM/MP4 compatible).
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Advanced Depression Analysis Tab */}
        <TabsContent value="advanced" className="space-y-6">
          <AdvancedDepressionAnalysis />
        </TabsContent>

        {/* Text Assessment Tab */}
        <TabsContent value="assessment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Comprehensive Text-Based Assessment</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="studentNameText">Student Name *</Label>
                  <Input
                    id="studentNameText"
                    value={formData.studentName}
                    onChange={(e) => setFormData(prev => ({ ...prev, studentName: e.target.value }))}
                    placeholder="Enter student name"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>Academic Pressure</Label>
                    <Textarea
                      value={formData.textResponses.academic_pressure}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        textResponses: { ...prev.textResponses, academic_pressure: e.target.value }
                      }))}
                      placeholder="Describe the academic pressure you're experiencing..."
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label>Social Support</Label>
                    <Textarea
                      value={formData.textResponses.social_support}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        textResponses: { ...prev.textResponses, social_support: e.target.value }
                      }))}
                      placeholder="How would you describe your support system?"
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label>Coping Strategies</Label>
                    <Textarea
                      value={formData.textResponses.coping_strategies}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        textResponses: { ...prev.textResponses, coping_strategies: e.target.value }
                      }))}
                      placeholder="What methods do you use to manage stress?"
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label>Current Challenges</Label>
                    <Textarea
                      value={formData.textResponses.study_motivation}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        textResponses: { ...prev.textResponses, study_motivation: e.target.value }
                      }))}
                      placeholder="What are your biggest challenges right now?"
                      rows={3}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-accent hover:bg-accent/90"
                  disabled={analyzeMutation.isPending}
                  onClick={() => setFormData(prev => ({ ...prev, sessionType: "text_quiz" }))}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  {analyzeMutation.isPending ? "Analyzing..." : "Analyze Text Responses"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="space-y-6">
          {analytics && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-foreground">{analytics.summary.totalSessions}</div>
                        <div className="text-sm text-muted-foreground">Total Sessions</div>
                      </div>
                      <Users className="h-8 w-8 text-accent" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-orange-600">{analytics.summary.highRiskCount}</div>
                        <div className="text-sm text-muted-foreground">High Risk</div>
                      </div>
                      <AlertTriangle className="h-8 w-8 text-orange-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-blue-600">{analytics.summary.averageRiskScore}</div>
                        <div className="text-sm text-muted-foreground">Avg Risk Score</div>
                      </div>
                      <TrendingUp className="h-8 w-8 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-red-600">{analytics.summary.riskPercentage}%</div>
                        <div className="text-sm text-muted-foreground">Risk Rate</div>
                      </div>
                      <Shield className="h-8 w-8 text-red-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Alert Level Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Object.entries(analytics.distribution).map(([level, count]) => (
                        <div key={level} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge className={getAlertBadgeColor(level)}>
                              {level.toUpperCase()}
                            </Badge>
                          </div>
                          <div className="text-right">
                            <div className="font-medium">{count}</div>
                            <div className="text-sm text-muted-foreground">
                              {analytics.summary.totalSessions > 0 
                                ? `${Math.round((count / analytics.summary.totalSessions) * 100)}%`
                                : '0%'
                              }
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Students Flagged for Review</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                      {analytics.flaggedStudents.length > 0 ? (
                        analytics.flaggedStudents.map((student, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-muted rounded">
                            <div>
                              <div className="font-medium">{student.studentName}</div>
                              <div className="text-sm text-muted-foreground">
                                Risk: {student.riskScore}% • {new Date(student.lastSession).toLocaleDateString()}
                              </div>
                            </div>
                            <Badge className={getAlertBadgeColor(student.alertLevel)}>
                              {student.alertLevel.toUpperCase()}
                            </Badge>
                          </div>
                        ))
                      ) : (
                        <div className="text-center text-muted-foreground py-4">
                          No students currently flagged for review
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        {/* Recent Sessions Tab */}
        <TabsContent value="sessions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Mental Health Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {recentSessions && recentSessions.length > 0 ? (
                  recentSessions.map((session) => (
                    <div key={session.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{session.studentName}</div>
                        <div className="text-sm text-muted-foreground">
                          {session.sessionType.replace('_', ' ')} • {new Date(session.createdAt).toLocaleString()}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className={`font-bold ${getRiskScoreColor(parseFloat(session.riskScore || '0'))}`}>
                            {session.riskScore}%
                          </div>
                          <div className="text-xs text-muted-foreground">Risk Score</div>
                        </div>
                        
                        <Badge className={getAlertBadgeColor(session.alertLevel)}>
                          {session.alertLevel?.toUpperCase() || 'UNKNOWN'}
                        </Badge>
                        
                        {session.flaggedForReview && (
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        )}

                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={async () => {
                            try {
                              const response = await fetch(`/api/mental-health/export/${session.id}`);
                              const blob = await response.blob();
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `mental-health-report-${session.studentName}-${session.id.slice(0, 8)}.json`;
                              document.body.appendChild(a);
                              a.click();
                              window.URL.revokeObjectURL(url);
                              document.body.removeChild(a);
                              toast({
                                title: "Report Exported",
                                description: `Analysis report for ${session.studentName} downloaded successfully`,
                              });
                            } catch (error) {
                              toast({
                                title: "Export Failed",
                                description: "Failed to export analysis report",
                                variant: "destructive",
                              });
                            }
                          }}
                        >
                          Export
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    No mental health sessions recorded yet. Start your first analysis above!
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}