import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Sparkles, Image, Brain, Users, Zap, Shield } from "lucide-react";

export default function Dashboard() {
  const features = [
    {
      icon: Heart,
      title: "Mental Health Coach",
      description: "AI-powered mental health support with personalized study plans and stress management for UPSC aspirants.",
      href: "/mental-health",
      color: "bg-gradient-secondary",
      iconBg: "bg-secondary/10",
      iconColor: "text-secondary",
      buttonClass: "bg-secondary hover:bg-secondary/90"
    },
    {
      icon: Brain,
      title: "Mental Health Analysis",
      description: "Advanced multimodal AI analysis using video interviews, facial expression detection, and comprehensive mental health monitoring.",
      href: "/mental-health-analysis",
      color: "bg-gradient-to-br from-purple-500 to-pink-500",
      iconBg: "bg-purple-50",
      iconColor: "text-purple-600",
      buttonClass: "bg-purple-600 hover:bg-purple-700"
    },
    {
      icon: Sparkles,
      title: "Prompt Generator", 
      description: "Advanced AI prompt generator for YouTube content analysis, SEO optimization, and script evaluation.",
      href: "/prompt-generator",
      color: "bg-gradient-primary",
      iconBg: "bg-primary/10",
      iconColor: "text-primary",
      buttonClass: "bg-primary hover:bg-primary/90"
    },
    {
      icon: Image,
      title: "Thumbnail Creator",
      description: "AI-powered YouTube thumbnail generator with custom designs optimized for educational content.",
      href: "/thumbnail-creator", 
      color: "bg-gradient-accent",
      iconBg: "bg-accent/10",
      iconColor: "text-accent",
      buttonClass: "bg-accent hover:bg-accent/90"
    }
  ];

  const benefits = [
    {
      icon: Brain,
      title: "AI-Powered",
      description: "Advanced AI algorithms designed specifically for educational content and mental health support",
      color: "text-primary"
    },
    {
      icon: Users,
      title: "Student-Focused", 
      description: "Tailored specifically for UPSC aspirants and competitive exam preparation needs",
      color: "text-secondary"
    },
    {
      icon: Zap,
      title: "Instant Results",
      description: "Get immediate assistance and content generation to boost productivity and learning",
      color: "text-accent"
    },
    {
      icon: Shield,
      title: "Privacy First",
      description: "No login required, secure processing, and privacy-focused design for peace of mind",
      color: "text-muted-foreground"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <section className="text-center mb-12">
        <h1 className="text-4xl font-bold text-foreground mb-4">
          AI-Powered Learning & Content Tools
        </h1>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
          Comprehensive suite of AI tools designed to support UPSC aspirants and coaching institute staff with mental health support, content creation, and productivity enhancement.
        </p>
      </section>

      {/* Feature Cards */}
      <section className="mb-16">
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <Card key={feature.title} className="feature-card hover:shadow-xl transition-all duration-300 overflow-hidden">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${feature.iconBg} rounded-lg flex items-center justify-center mb-4 module-icon`}>
                    <Icon className={`h-6 w-6 ${feature.iconColor}`} />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{feature.description}</p>
                  <Link href={feature.href}>
                    <Button className={`w-full ${feature.buttonClass} text-white font-medium transition-colors`}>
                      {feature.title === "Mental Health Coach" && "Start Coaching Session"}
                      {feature.title === "Prompt Generator" && "Generate Prompts"}
                      {feature.title === "Thumbnail Creator" && "Create Thumbnail"}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="bg-muted rounded-xl p-8">
        <h2 className="text-2xl font-bold text-foreground text-center mb-8">
          Why Choose Our AI Tools?
        </h2>
        <div className="grid md:grid-cols-4 gap-6">
          {benefits.map((benefit) => {
            const Icon = benefit.icon;
            return (
              <div key={benefit.title} className="text-center">
                <div className="w-12 h-12 bg-background rounded-lg flex items-center justify-center mx-auto mb-3 shadow-sm">
                  <Icon className={`h-6 w-6 ${benefit.color}`} />
                </div>
                <h4 className="font-semibold text-foreground mb-2">{benefit.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{benefit.description}</p>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
