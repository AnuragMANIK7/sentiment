import React, { useState, useEffect } from 'react';
import { FileText, Download, CheckCircle, AlertTriangle, Calendar, User } from 'lucide-react';

interface ReportEntry {
  id: string;
  sessionId: string;
  studentName: string;
  timestamp: string;
  analysisData: any;
  riskScore: number;
  severityLevel: string;
  confidence: number;
  summary: string;
}

export default function AnalysisReports() {
  const [reports, setReports] = useState<ReportEntry[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [students, setStudents] = useState<string[]>([]);

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = () => {
    try {
      const allReports = JSON.parse(localStorage.getItem('advancedHealthReports') || '[]');
      setReports(allReports);
      
      // Extract unique student names
      const uniqueStudents = Array.from(new Set(allReports.map((r: ReportEntry) => r.studentName)));
      setStudents(uniqueStudents);
    } catch (error) {
      console.error('Failed to load reports:', error);
      setReports([]);
    }
  };

  const filteredReports = selectedStudent 
    ? reports.filter(report => report.studentName === selectedStudent)
    : reports;

  const downloadReport = (report: ReportEntry, format: 'json' | 'summary') => {
    const filename = `${report.studentName}_analysis_${format}_${new Date(report.timestamp).toISOString().split('T')[0]}.${format === 'json' ? 'json' : 'txt'}`;
    
    let content = '';
    if (format === 'json') {
      content = JSON.stringify(report.analysisData, null, 2);
    } else {
      content = `Advanced Depression Analysis Report

Student: ${report.studentName}
Date: ${new Date(report.timestamp).toLocaleString()}
Session ID: ${report.sessionId}

ANALYSIS RESULTS
================
Risk Score: ${Math.round(report.riskScore)}%
Severity Level: ${report.severityLevel}
Confidence: ${Math.round(report.confidence * 100)}%

SUMMARY
=======
${report.summary}

DETAILED FINDINGS
================
${JSON.stringify(report.analysisData, null, 2)}

This report was generated using the multimodal depression detection methodology
from the ECIR 2024 research paper "Reading Between the Frames".
`;
    }

    const blob = new Blob([content], { type: format === 'json' ? 'application/json' : 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getRiskColor = (riskScore: number) => {
    if (riskScore < 25) return 'text-green-600 dark:text-green-400';
    if (riskScore < 50) return 'text-yellow-600 dark:text-yellow-400';
    if (riskScore < 75) return 'text-orange-600 dark:text-orange-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getRiskBadgeColor = (riskScore: number) => {
    if (riskScore < 25) return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    if (riskScore < 50) return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    if (riskScore < 75) return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
    return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
  };

  const clearAllReports = () => {
    if (window.confirm('Are you sure you want to clear all saved reports? This action cannot be undone.')) {
      localStorage.removeItem('advancedHealthReports');
      setReports([]);
      setStudents([]);
      setSelectedStudent('');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Analysis Reports
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            View and download saved advanced health analysis reports
          </p>
        </div>

        {/* Controls */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 mb-6 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div>
                <label htmlFor="student-filter" className="block text-sm font-medium mb-1">
                  Filter by Student
                </label>
                <select
                  id="student-filter"
                  value={selectedStudent}
                  onChange={(e) => setSelectedStudent(e.target.value)}
                  className="p-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 min-w-[200px]"
                >
                  <option value="">All Students</option>
                  {students.map(student => (
                    <option key={student} value={student}>{student}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                <FileText className="h-4 w-4" />
                <span>{filteredReports.length} reports found</span>
              </div>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={loadReports}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Refresh Reports
              </button>
              {reports.length > 0 && (
                <button
                  onClick={clearAllReports}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  Clear All Reports
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Reports List */}
        {filteredReports.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-12 text-center shadow-sm">
            <FileText className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              No Reports Found
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              {selectedStudent 
                ? `No analysis reports found for ${selectedStudent}`
                : 'No analysis reports have been saved yet. Complete an advanced health analysis to see reports here.'
              }
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredReports.map((report) => (
              <div key={report.id} className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                        {report.studentName}
                      </h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getRiskBadgeColor(report.riskScore)}`}>
                        {Math.round(report.riskScore)}% Risk
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(report.timestamp).toLocaleString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="h-4 w-4" />
                        Session: {report.sessionId.slice(-8)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => downloadReport(report, 'summary')}
                      className="px-3 py-2 text-sm bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-200 transition-colors"
                    >
                      <Download className="h-4 w-4 inline mr-1" />
                      Summary
                    </button>
                    <button
                      onClick={() => downloadReport(report, 'json')}
                      className="px-3 py-2 text-sm bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 transition-colors"
                    >
                      <Download className="h-4 w-4 inline mr-1" />
                      Full Data
                    </button>
                  </div>
                </div>
                
                {/* Analysis Summary Grid */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                    <div className="text-xs text-gray-600 dark:text-gray-400 mb-1">Risk Score</div>
                    <div className={`text-lg font-semibold ${getRiskColor(report.riskScore)}`}>
                      {Math.round(report.riskScore)}%
                    </div>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                    <div className="text-xs text-gray-600 dark:text-gray-400 mb-1">Severity</div>
                    <div className="text-lg font-medium capitalize">{report.severityLevel}</div>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                    <div className="text-xs text-gray-600 dark:text-gray-400 mb-1">Confidence</div>
                    <div className="text-lg font-medium">{Math.round(report.confidence * 100)}%</div>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                    <div className="text-xs text-gray-600 dark:text-gray-400 mb-1">Status</div>
                    <div className="flex items-center gap-1">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium">Complete</span>
                    </div>
                  </div>
                </div>
                
                {/* Summary */}
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">Analysis Summary</h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300">{report.summary}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}