import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Copy, Save, Clock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import UsernameInput from "@/components/username-input";
import type { Prompt } from "@shared/schema";

export default function PromptGenerator() {
  const [formData, setFormData] = useState({
    category: "",
    targetAudience: "",
    contentTopic: "",
    requirements: "",
    tone: "professional",
    outputLength: "medium",
  });
  const [generatedPrompt, setGeneratedPrompt] = useState("");
  const [username, setUsername] = useState<string>("");
  const { toast } = useToast();

  const { data: recentPrompts } = useQuery<Prompt[]>({
    queryKey: ["/api/prompts"],
  });

  const generateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/prompts", {
        ...data,
        username: username || undefined
      });
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedPrompt(data.generatedPrompt);
      toast({
        title: "Success",
        description: "Prompt generated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate prompt",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.category) {
      toast({
        title: "Error",
        description: "Please select a prompt category",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate(formData);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedPrompt);
    toast({
      title: "Copied",
      description: "Prompt copied to clipboard!",
    });
  };

  const categories = [
    { value: "youtube-seo", label: "YouTube SEO Analysis" },
    { value: "content-virality", label: "Content Virality Check" },
    { value: "script-analysis", label: "Script Analysis & Report" },
    { value: "educational-content", label: "Educational Content Creation" },
    { value: "social-media", label: "Social Media Optimization" },
  ];

  const tones = [
    { value: "professional", label: "Professional" },
    { value: "casual", label: "Casual" },
    { value: "academic", label: "Academic" },
    { value: "engaging", label: "Engaging" },
    { value: "authoritative", label: "Authoritative" },
  ];

  const outputLengths = [
    { value: "short", label: "Short (100-200 words)" },
    { value: "medium", label: "Medium (200-500 words)" },
    { value: "long", label: "Long (500+ words)" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <div className="flex items-center mb-4">
          <Sparkles className="h-6 w-6 text-primary mr-3" />
          <h1 className="text-2xl font-bold text-foreground">Advanced Prompt Generator</h1>
        </div>
        <p className="text-muted-foreground">
          Create sophisticated, structured prompts for YouTube content analysis, SEO optimization, and educational content creation.
        </p>
      </div>

      {/* Username Input */}
      <UsernameInput 
        onUsernameSet={setUsername} 
        currentUsername={username}
      />

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Prompt Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="category">Prompt Category *</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category..." />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="targetAudience">Target Audience</Label>
                  <Input
                    id="targetAudience"
                    value={formData.targetAudience}
                    onChange={(e) => setFormData(prev => ({ ...prev, targetAudience: e.target.value }))}
                    placeholder="e.g., UPSC aspirants, competitive exam students"
                  />
                </div>

                <div>
                  <Label htmlFor="contentTopic">Content Topic/Subject</Label>
                  <Input
                    id="contentTopic"
                    value={formData.contentTopic}
                    onChange={(e) => setFormData(prev => ({ ...prev, contentTopic: e.target.value }))}
                    placeholder="e.g., Indian History, Current Affairs, Public Administration"
                  />
                </div>

                <div>
                  <Label htmlFor="requirements">Specific Requirements</Label>
                  <Textarea
                    id="requirements"
                    rows={4}
                    value={formData.requirements}
                    onChange={(e) => setFormData(prev => ({ ...prev, requirements: e.target.value }))}
                    placeholder="Describe your specific needs, goals, and any additional context..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="tone">Tone</Label>
                    <Select value={formData.tone} onValueChange={(value) => setFormData(prev => ({ ...prev, tone: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {tones.map((tone) => (
                          <SelectItem key={tone.value} value={tone.value}>
                            {tone.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="outputLength">Output Length</Label>
                    <Select value={formData.outputLength} onValueChange={(value) => setFormData(prev => ({ ...prev, outputLength: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {outputLengths.map((length) => (
                          <SelectItem key={length.value} value={length.value}>
                            {length.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/90"
                  disabled={generateMutation.isPending}
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  {generateMutation.isPending ? "Generating..." : "Generate Advanced Prompt"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Generated Prompt Output */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Generated Prompt</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-muted rounded-lg p-4 min-h-96 mb-4">
                {generatedPrompt ? (
                  <div className="whitespace-pre-wrap text-sm font-mono leading-relaxed">
                    {generatedPrompt}
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground italic py-20">
                    Your enhanced prompt will appear here...
                  </div>
                )}
              </div>

              {generatedPrompt && (
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={copyToClipboard}
                    className="flex-1"
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Prompt
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <Save className="h-4 w-4 mr-2" />
                    Save Template
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Prompts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Recent Prompts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {recentPrompts && recentPrompts.length > 0 ? (
                  recentPrompts.map((prompt) => (
                    <div
                      key={prompt.id}
                      className="bg-muted rounded p-3 cursor-pointer hover:bg-muted/80 transition-colors"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {prompt.category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            {prompt.contentTopic && ` - ${prompt.contentTopic}`}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {prompt.createdAt ? new Date(prompt.createdAt).toLocaleDateString() : 'Recent'}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No recent prompts. Generate your first prompt to get started!
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
