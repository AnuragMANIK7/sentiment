import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, Send, User, Bot, BookOpen } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTutorial } from "@/components/tutorial-system";
import UsernameInput from "@/components/username-input";
import LearningStyleQuiz from "@/components/learning-style-quiz";
import AdvancedHealthAnalysis from "@/components/AdvancedHealthAnalysis";
import EnhancedLearningInsights from "@/components/enhanced-learning-insights";

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function MentalHealth() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your AI mental health coach. I'm here to help you with study planning and managing stress during your UPSC preparation. How are you feeling today?"
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [currentMood, setCurrentMood] = useState<number>(3);
  const [username, setUsername] = useState<string>("");
  const [learningStyleResults, setLearningStyleResults] = useState<any>(null);
  const { toast } = useToast();
  const { markStepComplete } = useTutorial();

  const chatMutation = useMutation({
    mutationFn: async (userMessage: string) => {
      const newMessages = [...messages, { role: "user" as const, content: userMessage }];
      const response = await apiRequest("POST", "/api/chat", { 
        messages: newMessages,
        username: username || undefined
      });
      return response.json();
    },
    onSuccess: (data) => {
      setMessages(prev => [...prev, { role: "user", content: inputMessage }, { role: "assistant", content: data.response }]);
      setInputMessage("");
      markStepComplete("mental-health-coach");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;
    chatMutation.mutate(inputMessage);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const moodEmojis = ["😞", "😔", "😐", "😊", "😄"];
  const moodLabels = ["Very Sad", "Sad", "Neutral", "Happy", "Very Happy"];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <div className="flex items-center mb-4">
          <Heart className="h-6 w-6 text-secondary mr-3" />
          <h1 className="text-2xl font-bold text-foreground">Mental Health Coach</h1>
        </div>
        <p className="text-muted-foreground">
          Get personalized support for your UPSC preparation journey with AI-powered mental health coaching.
        </p>
      </div>

      {/* Username Input */}
      <UsernameInput 
        onUsernameSet={setUsername} 
        currentUsername={username}
      />

      <Tabs defaultValue="chat" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="chat" className="flex items-center gap-2">
            <Heart className="w-4 h-4" />
            Chat Coach
          </TabsTrigger>
          <TabsTrigger value="advanced" className="flex items-center gap-2">
            <Bot className="w-4 h-4" />
            Advanced Analysis
          </TabsTrigger>
          <TabsTrigger value="learning" className="flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            Learning Style
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            My Insights
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="mt-6">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Chat Interface */}
            <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Chat with Your AI Coach</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Messages */}
              <div className="h-96 overflow-y-auto mb-4 space-y-4 border rounded-lg p-4 bg-muted/30">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex items-start gap-3 ${
                      message.role === "user" ? "justify-end" : ""
                    }`}
                  >
                    {message.role === "assistant" && (
                      <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                        <Bot className="h-4 w-4 text-white" />
                      </div>
                    )}
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        message.role === "user"
                          ? "chat-message-user"
                          : "chat-message-assistant"
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                    </div>
                    {message.role === "user" && (
                      <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                        <User className="h-4 w-4 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                ))}
                {chatMutation.isPending && (
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                      <Bot className="h-4 w-4 text-white" />
                    </div>
                    <div className="chat-message-assistant max-w-xs">
                      <p className="text-sm">Thinking...</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Message Input */}
              <div className="flex gap-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message here..."
                  disabled={chatMutation.isPending}
                  className="flex-1"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={chatMutation.isPending || !inputMessage.trim()}
                  className="bg-secondary hover:bg-secondary/90"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Mood Tracker */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Mood Check-in</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 gap-2 mb-4">
                {moodEmojis.map((emoji, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentMood(index + 1)}
                    className={`p-2 text-2xl rounded-lg transition-colors ${
                      currentMood === index + 1
                        ? "bg-primary/20 ring-2 ring-primary"
                        : "hover:bg-muted"
                    }`}
                    title={moodLabels[index]}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
              <p className="text-center text-sm text-muted-foreground">
                Current mood: {moodLabels[currentMood - 1]}
              </p>
            </CardContent>
          </Card>

          {/* Study Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Today's Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>History</span>
                  <span>75%</span>
                </div>
                <Progress value={75} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Polity</span>
                  <span>45%</span>
                </div>
                <Progress value={45} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Geography</span>
                  <span>60%</span>
                </div>
                <Progress value={60} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Quick Resources */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Resources</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start">
                Study Schedule Template
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                Stress Management Tips
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                Motivation Techniques
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </TabsContent>

    <TabsContent value="advanced" className="mt-6">
      <AdvancedHealthAnalysis username={username} />
    </TabsContent>

    <TabsContent value="learning" className="mt-6">
      <div className="max-w-2xl mx-auto">
        <LearningStyleQuiz 
          onComplete={(results) => {
            setLearningStyleResults(results);
            toast({
              title: "Learning Style Identified",
              description: `You are primarily a ${results.primaryStyle} learner!`,
            });
          }}
        />
      </div>
    </TabsContent>

    <TabsContent value="insights" className="mt-6">
      <EnhancedLearningInsights 
        learningStyleResults={learningStyleResults}
        username={username}
      />
    </TabsContent>
  </Tabs>
  </div>
  );
}
