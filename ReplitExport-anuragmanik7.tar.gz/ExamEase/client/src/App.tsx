import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TutorialSystem } from "@/components/tutorial-system";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import Dashboard from "@/pages/dashboard";
import MentalHealth from "@/pages/mental-health";
import MentalHealthAnalysis from "@/pages/mental-health-analysis";
import FacialAnalysisQuiz from "@/pages/facial-analysis-quiz";
import PromptGenerator from "@/pages/prompt-generator";
import ThumbnailCreator from "@/pages/thumbnail-creator";
import PromptAnalytics from "@/pages/prompt-analytics";
import AnalysisReports from "@/pages/analysis-reports";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/mental-health" component={MentalHealth} />
      <Route path="/mental-health-analysis" component={MentalHealthAnalysis} />
      <Route path="/facial-analysis-quiz" component={FacialAnalysisQuiz} />
      <Route path="/prompt-generator" component={PromptGenerator} />
      <Route path="/prompt-analytics" component={PromptAnalytics} />
      <Route path="/analysis-reports" component={AnalysisReports} />
      <Route path="/thumbnail-creator" component={ThumbnailCreator} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background flex flex-col">
          <Header />
          <main className="flex-1">
            <Router />
          </main>
          <Footer />
        </div>
        <Toaster />
        <TutorialSystem />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
