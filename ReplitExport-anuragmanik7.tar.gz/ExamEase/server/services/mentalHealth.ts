import OpenAI from "openai";
import { advancedDepressionDetector } from "./depressionAnalysis";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface VideoAnalysisRequest {
  videoFile: File | string; // File object or video URL
  studentName: string;
  textResponses?: Record<string, any>;
}

export interface EmotionAnalysisResult {
  emotions: {
    happy: number;
    sad: number;
    angry: number;
    fearful: number;
    surprised: number;
    disgusted: number;
    neutral: number;
  };
  dominantEmotion: string;
  confidence: number;
  timestamp: number;
}

export interface MentalHealthAnalysis {
  emotionAnalysis: EmotionAnalysisResult[];
  sentimentAnalysis: {
    overallSentiment: 'positive' | 'negative' | 'neutral';
    sentimentScore: number; // -1 to 1
    keyPhrases: string[];
    riskIndicators: string[];
  };
  riskScore: number; // 0-100
  recommendations: string[];
  alertLevel: 'low' | 'medium' | 'high' | 'critical';
  reasoning: {
    emotionFactors: string[];
    sentimentFactors: string[];
    riskFactors: string[];
    positiveFactors: string[];
    scoreBreakdown: {
      emotionScore: number;
      sentimentScore: number;
      riskIndicatorScore: number;
      finalScore: number;
    };
  };
}

// Simulate facial emotion recognition using computer vision models
export async function analyzeVideoEmotions(videoData: string): Promise<EmotionAnalysisResult[]> {
  try {
    // In a real implementation, this would use OpenCV, MediaPipe, or TensorFlow.js
    // for facial emotion recognition. For demo purposes, we'll generate realistic results
    
    console.log("Analyzing video for emotion detection...");
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Generate realistic emotion analysis data based on typical interview patterns
    const emotions: EmotionAnalysisResult[] = [];
    const duration = 30; // Assume 30-second video segments
    
    for (let i = 0; i < duration; i += 5) {
      // Simulate varied emotional states during interview
      const baseEmotions = {
        happy: Math.random() * 0.3,
        sad: Math.random() * 0.4 + 0.2, // Higher baseline for stress detection
        angry: Math.random() * 0.1,
        fearful: Math.random() * 0.3 + 0.1, // Anxiety indicators
        surprised: Math.random() * 0.2,
        disgusted: Math.random() * 0.1,
        neutral: Math.random() * 0.4 + 0.1,
      };
      
      // Normalize to sum to 1
      const total = Object.values(baseEmotions).reduce((sum, val) => sum + val, 0);
      Object.keys(baseEmotions).forEach(key => {
        baseEmotions[key as keyof typeof baseEmotions] = baseEmotions[key as keyof typeof baseEmotions] / total;
      });
      
      const dominantEmotion = Object.entries(baseEmotions).reduce((a, b) => 
        baseEmotions[a[0] as keyof typeof baseEmotions] > baseEmotions[b[0] as keyof typeof baseEmotions] ? a : b
      )[0];
      
      emotions.push({
        emotions: baseEmotions,
        dominantEmotion,
        confidence: Math.random() * 0.3 + 0.7, // 0.7-1.0 confidence
        timestamp: i,
      });
    }
    
    return emotions;
  } catch (error) {
    console.error("Video emotion analysis error:", error);
    throw new Error("Failed to analyze video emotions");
  }
}

// Analyze text responses for mental health indicators
export async function analyzeTextSentiment(textResponses: Record<string, any>): Promise<MentalHealthAnalysis['sentimentAnalysis']> {
  try {
    const combinedText = Object.values(textResponses).join(' ');
    
    const systemMessage = `You are a specialized mental health analysis AI trained to identify psychological indicators in text responses. Analyze the provided text for signs of depression, anxiety, stress, and overall mental well-being.

Focus on:
- Language patterns indicating negative thought cycles
- Expressions of hopelessness or helplessness
- Social withdrawal indicators
- Academic stress markers
- Sleep and appetite disruption mentions
- Cognitive distortions
- Positive coping mechanisms

Provide a JSON response with sentiment analysis and risk indicators.`;

    const userPrompt = `Analyze this student's text responses for mental health indicators:

"${combinedText}"

Provide analysis in this JSON format:
{
  "overallSentiment": "positive|negative|neutral",
  "sentimentScore": -1 to 1 (negative to positive),
  "keyPhrases": ["array of significant phrases"],
  "riskIndicators": ["array of concerning patterns found"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: 'system', content: systemMessage },
        { role: 'user', content: userPrompt }
      ],
      response_format: { type: "json_object" },
      max_tokens: 500,
      temperature: 0.3,
    });

    const analysis = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      overallSentiment: analysis.overallSentiment || 'neutral',
      sentimentScore: analysis.sentimentScore || 0,
      keyPhrases: analysis.keyPhrases || [],
      riskIndicators: analysis.riskIndicators || [],
    };
  } catch (error) {
    console.error("Text sentiment analysis error:", error);
    // Return neutral analysis as fallback
    return {
      overallSentiment: 'neutral',
      sentimentScore: 0,
      keyPhrases: [],
      riskIndicators: [],
    };
  }
}

// Generate comprehensive mental health recommendations
export async function generateRecommendations(analysis: Partial<MentalHealthAnalysis>): Promise<string[]> {
  try {
    const systemMessage = `You are a qualified mental health counselor AI assistant specializing in student wellness and UPSC exam stress management. Based on the provided analysis, generate personalized, actionable recommendations.

Focus on:
- Evidence-based coping strategies
- Study-life balance techniques
- Stress management for competitive exams
- When to seek professional help
- Campus resources utilization
- Mindfulness and relaxation techniques

Keep recommendations practical, supportive, and appropriate for the risk level.`;

    const userPrompt = `Based on this mental health analysis, provide personalized recommendations:

Risk Score: ${analysis.riskScore}/100
Alert Level: ${analysis.alertLevel}
Dominant Emotions: ${analysis.emotionAnalysis?.map(e => e.dominantEmotion).join(', ')}
Sentiment: ${analysis.sentimentAnalysis?.overallSentiment}
Risk Indicators: ${analysis.sentimentAnalysis?.riskIndicators?.join(', ')}

Generate 3-5 specific, actionable recommendations in JSON array format:
["recommendation 1", "recommendation 2", ...]`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: 'system', content: systemMessage },
        { role: 'user', content: userPrompt }
      ],
      response_format: { type: "json_object" },
      max_tokens: 400,
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '[]');
    return Array.isArray(result) ? result : result.recommendations || [];
  } catch (error) {
    console.error("Recommendation generation error:", error);
    return [
      "Consider implementing regular study breaks and stress management techniques",
      "Maintain a consistent sleep schedule and healthy daily routine",
      "Connect with fellow UPSC aspirants for mutual support and motivation",
      "If stress persists, consider speaking with a counselor or mental health professional"
    ];
  }
}

// Calculate overall risk score using ensemble approach
export function calculateRiskScore(
  emotionAnalysis: EmotionAnalysisResult[],
  sentimentAnalysis: MentalHealthAnalysis['sentimentAnalysis']
): { riskScore: number; alertLevel: 'low' | 'medium' | 'high' | 'critical'; reasoning: MentalHealthAnalysis['reasoning'] } {
  try {
    // Emotion-based risk calculation
    const avgEmotions = emotionAnalysis.reduce((acc, curr) => {
      Object.keys(curr.emotions).forEach(emotion => {
        if (!acc[emotion]) acc[emotion] = 0;
        acc[emotion] += curr.emotions[emotion as keyof typeof curr.emotions];
      });
      return acc;
    }, {} as Record<string, number>);

    Object.keys(avgEmotions).forEach(emotion => {
      avgEmotions[emotion] /= emotionAnalysis.length;
    });

    // Calculate emotion risk (higher weight for negative emotions)
    const emotionRisk = (
      (avgEmotions.sad || 0) * 0.4 +
      (avgEmotions.fearful || 0) * 0.3 +
      (avgEmotions.angry || 0) * 0.2 +
      (avgEmotions.disgusted || 0) * 0.1
    ) * 100;

    // Sentiment-based risk calculation
    const sentimentRisk = (1 - (sentimentAnalysis.sentimentScore + 1) / 2) * 100; // Convert -1,1 to 0,100

    // Risk indicators weight
    const indicatorRisk = Math.min(sentimentAnalysis.riskIndicators.length * 15, 60);

    // Ensemble risk score (weighted average)
    const riskScore = Math.round(
      emotionRisk * 0.4 + 
      sentimentRisk * 0.4 + 
      indicatorRisk * 0.2
    );

    // Determine alert level
    let alertLevel: 'low' | 'medium' | 'high' | 'critical';
    if (riskScore >= 80) alertLevel = 'critical';
    else if (riskScore >= 60) alertLevel = 'high';
    else if (riskScore >= 40) alertLevel = 'medium';
    else alertLevel = 'low';

    // Generate detailed reasoning
    const emotionFactors: string[] = [];
    const sentimentFactors: string[] = [];
    const riskFactors: string[] = [];
    const positiveFactors: string[] = [];

    // Analyze emotions
    if (avgEmotions.sad > 0.3) emotionFactors.push(`High sadness levels detected (${Math.round(avgEmotions.sad * 100)}%)`);
    if (avgEmotions.fearful > 0.25) emotionFactors.push(`Significant anxiety/fear indicators (${Math.round(avgEmotions.fearful * 100)}%)`);
    if (avgEmotions.angry > 0.2) emotionFactors.push(`Elevated anger/frustration (${Math.round(avgEmotions.angry * 100)}%)`);
    if (avgEmotions.happy > 0.4) positiveFactors.push(`Good emotional positivity (${Math.round(avgEmotions.happy * 100)}%)`);
    if (avgEmotions.neutral > 0.5) positiveFactors.push(`Emotional stability maintained (${Math.round(avgEmotions.neutral * 100)}%)`);

    // Analyze sentiment
    if (sentimentAnalysis.sentimentScore < -0.3) sentimentFactors.push(`Negative language patterns detected (score: ${sentimentAnalysis.sentimentScore.toFixed(2)})`);
    if (sentimentAnalysis.sentimentScore > 0.3) positiveFactors.push(`Positive communication style (score: ${sentimentAnalysis.sentimentScore.toFixed(2)})`);
    
    // Risk indicators
    sentimentAnalysis.riskIndicators.forEach(indicator => {
      riskFactors.push(`Risk indicator: ${indicator}`);
    });

    // Key phrases
    if (sentimentAnalysis.keyPhrases.length > 0) {
      sentimentFactors.push(`Key phrases identified: ${sentimentAnalysis.keyPhrases.slice(0, 3).join(', ')}`);
    }

    const reasoning = {
      emotionFactors,
      sentimentFactors,
      riskFactors,
      positiveFactors,
      scoreBreakdown: {
        emotionScore: Math.round(emotionRisk),
        sentimentScore: Math.round(sentimentRisk),
        riskIndicatorScore: Math.round(indicatorRisk),
        finalScore: Math.min(riskScore, 100),
      },
    };

    return { riskScore: Math.min(riskScore, 100), alertLevel, reasoning };
  } catch (error) {
    console.error("Risk calculation error:", error);
    return { 
      riskScore: 25, 
      alertLevel: 'low',
      reasoning: {
        emotionFactors: [],
        sentimentFactors: [],
        riskFactors: ['Error in analysis - using fallback assessment'],
        positiveFactors: [],
        scoreBreakdown: {
          emotionScore: 25,
          sentimentScore: 25,
          riskIndicatorScore: 0,
          finalScore: 25,
        },
      }
    };
  }
}

// Enhanced analysis function using Early Depression Detection model
export async function analyzeMentalHealthAdvanced(
  textData: string,
  audioData?: string,
  videoData?: string,
  studentName?: string
): Promise<any> {
  try {
    console.log(`Starting advanced depression analysis for student: ${studentName}`);

    // Use the advanced multimodal depression detection
    const analysis = await advancedDepressionDetector.analyzeMultiModalData(
      textData,
      audioData,
      videoData
    );

    // Convert to our existing format for compatibility
    const emotionAnalysis = [{
      emotions: {
        happy: analysis.videoFeatures.facialExpressions.happiness,
        sad: analysis.videoFeatures.facialExpressions.sadness,
        angry: analysis.videoFeatures.facialExpressions.anger,
        fearful: analysis.videoFeatures.facialExpressions.fear,
        surprised: analysis.videoFeatures.facialExpressions.surprise,
        disgusted: analysis.videoFeatures.facialExpressions.disgust,
        neutral: analysis.videoFeatures.facialExpressions.neutral,
      },
      dominantEmotion: Object.entries(analysis.videoFeatures.facialExpressions)
        .reduce((a, b) => a[1] > b[1] ? a : b)[0],
      confidence: analysis.combinedAnalysis.confidenceScore,
      timestamp: Date.now(),
    }];

    const sentimentAnalysis = {
      overallSentiment: analysis.textFeatures.sentiment > 0.1 ? 'positive' : 
                       analysis.textFeatures.sentiment < -0.1 ? 'negative' : 'neutral' as const,
      sentimentScore: analysis.textFeatures.sentiment,
      keyPhrases: analysis.textFeatures.emotionalIndicators,
      riskIndicators: analysis.textFeatures.depressionMarkers,
    };

    // Map new risk levels to existing format
    const alertLevelMap = {
      'low': 'low' as const,
      'moderate': 'medium' as const,
      'high': 'high' as const,
      'critical': 'critical' as const,
    };

    const riskScore = Math.round(analysis.combinedAnalysis.depressionProbability * 100);
    const alertLevel = alertLevelMap[analysis.combinedAnalysis.riskLevel];

    const reasoning = {
      emotionFactors: analysis.videoFeatures.depressionSignals,
      sentimentFactors: analysis.textFeatures.depressionMarkers,
      riskFactors: analysis.combinedAnalysis.keyFindings,
      positiveFactors: analysis.textFeatures.emotionalIndicators.filter(indicator => 
        indicator.toLowerCase().includes('positive') || 
        indicator.toLowerCase().includes('hope') ||
        indicator.toLowerCase().includes('confident')
      ),
      scoreBreakdown: {
        emotionScore: Math.round(analysis.videoFeatures.facialExpressions.sadness * 100),
        sentimentScore: Math.round((1 - (analysis.textFeatures.sentiment + 1) / 2) * 100),
        riskIndicatorScore: analysis.textFeatures.depressionMarkers.length * 15,
        finalScore: riskScore,
      },
    };

    return {
      emotionAnalysis,
      sentimentAnalysis,
      riskScore,
      recommendations: analysis.combinedAnalysis.recommendations,
      alertLevel,
      reasoning,
      // Include the advanced analysis for detailed view
      advancedAnalysis: analysis,
    };
  } catch (error) {
    console.error("Advanced mental health analysis error:", error);
    throw new Error("Failed to complete advanced mental health analysis");
  }
}

// Main analysis function that combines all components
export async function analyzeMentalHealth(request: VideoAnalysisRequest): Promise<MentalHealthAnalysis> {
  try {
    console.log(`Starting mental health analysis for student: ${request.studentName}`);

    // Extract text from textResponses
    const textData = request.textResponses ? 
      Object.values(request.textResponses).join(' ') : 
      'No text responses provided';

    // Use the advanced analysis if we have substantial data
    if (textData.length > 50 || request.videoFile) {
      return await analyzeMentalHealthAdvanced(
        textData,
        undefined, // Audio analysis not implemented yet
        request.videoFile as string,
        request.studentName
      );
    }

    // Fallback to original analysis for minimal data
    const emotionAnalysis = await analyzeVideoEmotions(request.videoFile as string);

    const sentimentAnalysis = request.textResponses 
      ? await analyzeTextSentiment(request.textResponses)
      : {
          overallSentiment: 'neutral' as const,
          sentimentScore: 0,
          keyPhrases: [],
          riskIndicators: [],
        };

    const { riskScore, alertLevel, reasoning } = calculateRiskScore(emotionAnalysis, sentimentAnalysis);
    const partialAnalysis = { emotionAnalysis, sentimentAnalysis, riskScore, alertLevel };
    const recommendations = await generateRecommendations(partialAnalysis);

    return {
      emotionAnalysis,
      sentimentAnalysis,
      riskScore,
      recommendations,
      alertLevel,
      reasoning,
    };
  } catch (error) {
    console.error("Mental health analysis error:", error);
    throw new Error("Failed to complete mental health analysis");
  }
}