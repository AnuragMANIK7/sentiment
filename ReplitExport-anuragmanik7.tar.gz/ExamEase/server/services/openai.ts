import OpenAI from "openai";

// Using gpt-4.1-nano as requested by the user - OpenAI's fastest and most cost-effective model
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "your-api-key-here"
});

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export async function generateMentalHealthResponse(messages: ChatMessage[]): Promise<string> {
  try {
    const systemMessage = {
      role: 'system' as const,
      content: `You are a compassionate and professional mental health coach specializing in supporting UPSC aspirants. Your role is to:

1. Provide emotional support and stress management techniques
2. Help create personalized study plans and schedules
3. Offer motivation and encouragement during difficult times
4. Suggest healthy coping strategies for exam stress
5. Provide practical advice for maintaining work-life balance during preparation

Guidelines:
- Be empathetic and understanding
- Offer practical, actionable advice
- Encourage seeking professional help when appropriate
- Focus on study-related mental health challenges
- Keep responses supportive but professional
- Avoid diagnosing mental health conditions

Respond in a warm, supportive tone that acknowledges the unique challenges of UPSC preparation.`
    };

    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [systemMessage, ...messages],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate mental health response. Please check your API configuration.");
  }
}

export async function generatePrompt(requirements: {
  category: string;
  targetAudience?: string;
  contentTopic?: string;
  requirements?: string;
  tone?: string;
  outputLength?: string;
}): Promise<string> {
  try {
    const systemMessage = `You are an expert prompt engineer specializing in creating advanced, structured prompts for various content creation and analysis tasks. Your job is to transform basic requirements into comprehensive, detailed prompts that will produce high-quality results.

Guidelines for prompt enhancement:
1. Include clear role definition for the AI
2. Specify the task with detailed requirements
3. Define the expected output format
4. Include success criteria and evaluation metrics
5. Add relevant context and constraints
6. Structure the prompt for maximum clarity and effectiveness

Categories you specialize in:
- YouTube SEO Analysis
- Content Virality Assessment
- Script Analysis & Reports
- Educational Content Creation
- Social Media Optimization

Create a detailed, professional prompt that will produce exceptional results.`;

    const userPrompt = `Create an advanced prompt for the following requirements:

Category: ${requirements.category}
Target Audience: ${requirements.targetAudience || 'General audience'}
Content Topic: ${requirements.contentTopic || 'Not specified'}
Specific Requirements: ${requirements.requirements || 'None provided'}
Tone: ${requirements.tone || 'Professional'}
Output Length: ${requirements.outputLength || 'Medium'}

Transform these basic requirements into a comprehensive, structured prompt that includes:
1. Clear role definition
2. Detailed task description
3. Specific requirements and constraints
4. Expected output format
5. Success criteria
6. Relevant context and examples where helpful

Make the prompt detailed enough to produce high-quality, actionable results.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        { role: 'system', content: systemMessage },
        { role: 'user', content: userPrompt }
      ],
      max_tokens: 1000,
      temperature: 0.3,
    });

    return response.choices[0].message.content || "Failed to generate prompt. Please try again.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate prompt. Please check your API configuration.");
  }
}

export async function generateThumbnailPrompt(requirements: {
  videoTitle: string;
  contentCategory?: string;
  style?: string;
  textOverlay?: string;
  colorScheme?: string;
}): Promise<string> {
  try {
    const systemMessage = `You are an expert AI image generation prompt engineer specializing in creating YouTube thumbnails for educational content. Create detailed, specific prompts for Stable Diffusion that will generate eye-catching, professional thumbnails.

Focus on:
- Educational and professional aesthetics
- Clear, readable layouts
- Engaging visual elements
- High contrast and visibility
- YouTube thumbnail best practices
- Educational content themes`;

    const userPrompt = `Create a detailed Stable Diffusion prompt for a YouTube thumbnail with these specifications:

Video Title: ${requirements.videoTitle}
Content Category: ${requirements.contentCategory || 'Educational'}
Style: ${requirements.style || 'Professional'}
Text Overlay: ${requirements.textOverlay || requirements.videoTitle}
Color Scheme: ${requirements.colorScheme || 'Blue and white'}

Generate a comprehensive prompt that includes:
1. Visual composition and layout
2. Color specifications
3. Text placement and styling
4. Background elements
5. Educational themes and symbols
6. Professional quality indicators

The prompt should produce a thumbnail that is engaging, professional, and optimized for YouTube's platform.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        { role: 'system', content: systemMessage },
        { role: 'user', content: userPrompt }
      ],
      max_tokens: 300,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "Failed to generate thumbnail prompt. Please try again.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate thumbnail prompt. Please check your API configuration.");
  }
}
