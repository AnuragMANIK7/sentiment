#!/usr/bin/env python3
"""
Advanced Health Analysis PDF Report Generator
Creates comprehensive PDF reports from mental health analysis results
"""

import json
import sys
import os
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
import tempfile

def generate_plots(analysis_data, output_dir):
    """Generate visualization plots for the analysis data"""
    os.makedirs(output_dir, exist_ok=True)
    
    # Risk Score Distribution Plot
    plt.figure(figsize=(8, 5))
    risk_score = analysis_data.get('depressionRiskScore', 0)
    severity = analysis_data.get('severityLevel', 'unknown')
    
    # Create a bar chart showing risk score vs normal range
    categories = ['Patient Score', 'Low Risk', 'Moderate Risk', 'High Risk']
    scores = [risk_score, 25, 50, 75]
    colors_chart = ['red' if risk_score > 50 else 'orange' if risk_score > 25 else 'green', 
                   'green', 'orange', 'red']
    
    plt.bar(categories, scores, color=colors_chart, alpha=0.7)
    plt.title('Depression Risk Assessment', fontsize=14, fontweight='bold')
    plt.ylabel('Risk Score (%)')
    plt.ylim(0, 100)
    
    # Add score labels on bars
    for i, score in enumerate(scores):
        plt.text(i, score + 2, f'{score:.1f}%', ha='center', fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'risk_assessment.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # Modality Scores Radar Chart
    modality_scores = analysis_data.get('modalityScores', {})
    if modality_scores:
        categories = list(modality_scores.keys())
        values = list(modality_scores.values())
        
        plt.figure(figsize=(8, 6))
        plt.bar(categories, values, color=['skyblue', 'lightcoral', 'lightgreen', 'gold'])
        plt.title('Multimodal Analysis Breakdown', fontsize=14, fontweight='bold')
        plt.ylabel('Score')
        plt.xticks(rotation=45)
        
        # Add value labels on bars
        for i, value in enumerate(values):
            plt.text(i, value + 1, f'{value}', ha='center', fontweight='bold')
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'modality_scores.png'), dpi=300, bbox_inches='tight')
        plt.close()

def create_pdf_report(analysis_data, student_name, output_path):
    """Create a comprehensive PDF report"""
    
    # Create temporary directory for plots
    with tempfile.TemporaryDirectory() as temp_dir:
        # Generate plots
        generate_plots(analysis_data, temp_dir)
        
        # Create PDF document
        doc = SimpleDocTemplate(output_path, pagesize=A4)
        story = []
        styles = getSampleStyleSheet()
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=20,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.darkblue
        )
        
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            textColor=colors.darkblue
        )
        
        # Title Page
        story.append(Paragraph("Advanced Mental Health Analysis Report", title_style))
        story.append(Spacer(1, 20))
        
        # Student Information
        story.append(Paragraph("Student Information", heading_style))
        student_info = [
            ['Student Name:', student_name],
            ['Report Date:', datetime.now().strftime('%B %d, %Y')],
            ['Analysis Type:', 'Multimodal Depression Assessment'],
            ['Methodology:', 'ECIR 2024 Research Framework']
        ]
        
        student_table = Table(student_info, colWidths=[2*inch, 4*inch])
        student_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 12),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(student_table)
        story.append(Spacer(1, 30))
        
        # Executive Summary
        story.append(Paragraph("Executive Summary", heading_style))
        
        risk_score = analysis_data.get('depressionRiskScore', 0)
        severity = analysis_data.get('severityLevel', 'unknown').replace('_', ' ').title()
        confidence = analysis_data.get('confidence', 0) * 100
        
        summary_text = f"""
        This comprehensive multimodal analysis assessed {student_name} using advanced AI techniques 
        incorporating facial expression analysis, speech pattern evaluation, and behavioral assessment. 
        The analysis revealed a depression risk score of {risk_score:.1f}% with {severity.lower()} severity 
        level and {confidence:.1f}% confidence. The assessment utilized cutting-edge research methodologies 
        from ECIR 2024 to provide reliable mental health insights.
        """
        
        story.append(Paragraph(summary_text, styles['Normal']))
        story.append(Spacer(1, 20))
        
        # Key Findings
        story.append(Paragraph("Key Findings", heading_style))
        
        findings_data = [
            ['Metric', 'Result', 'Interpretation'],
            ['Depression Risk Score', f'{risk_score:.1f}%', get_risk_interpretation(risk_score)],
            ['Severity Level', severity, get_severity_interpretation(severity)],
            ['Confidence Level', f'{confidence:.1f}%', 'High confidence in assessment'],
        ]
        
        # Add modality scores
        modality_scores = analysis_data.get('modalityScores', {})
        for modality, score in modality_scores.items():
            findings_data.append([f'{modality.title()} Analysis', f'{score}', get_modality_interpretation(score)])
        
        findings_table = Table(findings_data, colWidths=[2*inch, 1.5*inch, 2.5*inch])
        findings_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
        ]))
        
        story.append(findings_table)
        story.append(PageBreak())
        
        # Clinical Indicators
        story.append(Paragraph("Clinical Indicators", heading_style))
        
        clinical_indicators = analysis_data.get('clinicalIndicators', {})
        for category, indicators in clinical_indicators.items():
            if indicators and isinstance(indicators, list):
                story.append(Paragraph(f"{category.replace('_', ' ').title()}", styles['Heading3']))
                for indicator in indicators:
                    story.append(Paragraph(f"• {indicator}", styles['Normal']))
                story.append(Spacer(1, 10))
        
        # Risk and Protective Factors
        story.append(Paragraph("Risk Assessment", heading_style))
        
        risk_factors = analysis_data.get('riskFactors', [])
        if risk_factors:
            story.append(Paragraph("Risk Factors:", styles['Heading4']))
            for factor in risk_factors:
                story.append(Paragraph(f"• {factor}", styles['Normal']))
            story.append(Spacer(1, 10))
        
        protective_factors = analysis_data.get('protectiveFactors', [])
        if protective_factors:
            story.append(Paragraph("Protective Factors:", styles['Heading4']))
            for factor in protective_factors:
                story.append(Paragraph(f"• {factor}", styles['Normal']))
            story.append(Spacer(1, 10))
        
        # Recommendations
        story.append(Paragraph("Intervention Recommendations", heading_style))
        
        recommendations = analysis_data.get('interventionRecommendations', [])
        if recommendations:
            for i, recommendation in enumerate(recommendations, 1):
                story.append(Paragraph(f"{i}. {recommendation}", styles['Normal']))
            story.append(Spacer(1, 10))
        
        monitoring_needs = analysis_data.get('monitoringNeeds', [])
        if monitoring_needs:
            story.append(Paragraph("Monitoring Requirements:", styles['Heading4']))
            for need in monitoring_needs:
                story.append(Paragraph(f"• {need}", styles['Normal']))
        
        story.append(PageBreak())
        
        # Research Findings
        research_findings = analysis_data.get('researchFindings', {})
        if research_findings:
            story.append(Paragraph("Research-Based Insights", heading_style))
            
            non_verbal_cues = research_findings.get('nonVerbalCues', [])
            if non_verbal_cues:
                story.append(Paragraph("Non-Verbal Behavioral Cues:", styles['Heading4']))
                for cue in non_verbal_cues:
                    story.append(Paragraph(f"• {cue}", styles['Normal']))
                story.append(Spacer(1, 10))
            
            multimodal_confidence = research_findings.get('multimodalConfidence', 0)
            temporal_consistency = research_findings.get('temporalConsistency', 0)
            
            story.append(Paragraph(f"Multimodal Analysis Confidence: {multimodal_confidence:.1%}", styles['Normal']))
            story.append(Paragraph(f"Temporal Consistency Score: {temporal_consistency:.1%}", styles['Normal']))
        
        # Footer
        story.append(Spacer(1, 30))
        footer_text = """
        This report was generated using advanced AI-powered multimodal analysis techniques based on 
        peer-reviewed research methodologies. The assessment should be used as a supplementary tool 
        and does not replace professional clinical evaluation. For immediate mental health concerns, 
        please contact a qualified healthcare professional.
        """
        story.append(Paragraph(footer_text, styles['Normal']))
        
        # Build PDF
        doc.build(story)
        
        return True

def get_risk_interpretation(score):
    """Get interpretation for risk score"""
    if score < 25:
        return "Low risk - Within normal range"
    elif score < 50:
        return "Moderate risk - Monitor closely"
    elif score < 75:
        return "High risk - Intervention recommended"
    else:
        return "Very high risk - Immediate attention needed"

def get_severity_interpretation(severity):
    """Get interpretation for severity level"""
    severity_map = {
        'Minimal': 'Little to no indication of depression',
        'Mild': 'Mild symptoms present, monitoring advised',
        'Moderate': 'Moderate symptoms, intervention beneficial',
        'Severe': 'Severe symptoms, professional help recommended',
        'Very Severe': 'Critical symptoms, immediate intervention required'
    }
    return severity_map.get(severity, 'Assessment inconclusive')

def get_modality_interpretation(score):
    """Get interpretation for modality scores"""
    if score < 30:
        return "Low indicators"
    elif score < 60:
        return "Moderate indicators"
    else:
        return "High indicators"

def main():
    """Main function to generate PDF report from JSON data"""
    if len(sys.argv) != 4:
        print("Usage: python reportGenerator.py <json_data> <student_name> <output_path>")
        sys.exit(1)
    
    try:
        # Parse command line arguments
        json_data = sys.argv[1]
        student_name = sys.argv[2]
        output_path = sys.argv[3]
        
        # Parse JSON data
        analysis_data = json.loads(json_data)
        
        # Generate PDF report
        success = create_pdf_report(analysis_data, student_name, output_path)
        
        if success:
            print(f"PDF report generated successfully: {output_path}")
        else:
            print("Failed to generate PDF report")
            sys.exit(1)
            
    except Exception as e:
        print(f"Error generating PDF report: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()