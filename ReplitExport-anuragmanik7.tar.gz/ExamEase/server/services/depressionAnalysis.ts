import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface MultiModalAnalysis {
  textFeatures: TextAnalysisResult;
  audioFeatures: AudioAnalysisResult;
  videoFeatures: VideoAnalysisResult;
  combinedAnalysis: CombinedAnalysisResult;
}

interface TextAnalysisResult {
  sentiment: number;
  emotionalIndicators: string[];
  vocabularyComplexity: number;
  depressionMarkers: string[];
  linguisticPatterns: {
    wordCount: number;
    avgSentenceLength: number;
    negativeWordRatio: number;
    emotionalWords: string[];
  };
}

interface AudioAnalysisResult {
  speechPatterns: {
    pauseDuration: number;
    speechRate: number;
    voiceEnergy: number;
    monotonicity: number;
  };
  emotionalTone: string;
  depressionIndicators: string[];
}

interface VideoAnalysisResult {
  facialExpressions: {
    happiness: number;
    sadness: number;
    anger: number;
    fear: number;
    surprise: number;
    disgust: number;
    neutral: number;
  };
  behavioralIndicators: {
    eyeContact: number;
    facialMovement: number;
    posture: string;
    gestureFrequency: number;
  };
  depressionSignals: string[];
}

interface CombinedAnalysisResult {
  depressionProbability: number;
  confidenceScore: number;
  riskLevel: 'low' | 'moderate' | 'high' | 'critical';
  recommendations: string[];
  professionalReferral: boolean;
  keyFindings: string[];
}

export class AdvancedDepressionDetector {
  
  /**
   * Main analysis function that processes text, audio, and video data
   * Implements multimodal fusion similar to the Early Depression Detection model
   */
  async analyzeMultiModalData(
    textData: string,
    audioData?: string,
    videoData?: string
  ): Promise<MultiModalAnalysis> {
    
    console.log('Starting advanced depression analysis...');
    
    // Parallel processing of all modalities
    const [textFeatures, audioFeatures, videoFeatures] = await Promise.all([
      this.analyzeTextData(textData),
      audioData ? this.analyzeAudioData(audioData) : this.getDefaultAudioFeatures(),
      videoData ? this.analyzeVideoData(videoData) : this.getDefaultVideoFeatures()
    ]);

    // Combined analysis using weighted fusion approach
    const combinedAnalysis = await this.performCombinedAnalysis(
      textFeatures,
      audioFeatures,
      videoFeatures
    );

    return {
      textFeatures,
      audioFeatures,
      videoFeatures,
      combinedAnalysis
    };
  }

  /**
   * Advanced text analysis using BiLSTM-inspired approach
   * Analyzes linguistic patterns, sentiment, and depression markers
   */
  private async analyzeTextData(text: string): Promise<TextAnalysisResult> {
    console.log('Analyzing text data for depression indicators...');
    
    const prompt = `
    Analyze the following text for depression indicators using clinical psychology principles.
    Focus on linguistic patterns, emotional expression, and cognitive markers.
    
    Text: "${text}"
    
    Provide analysis in JSON format:
    {
      "sentiment": number (-1 to 1, where -1 is very negative),
      "emotionalIndicators": ["specific emotional words/phrases found"],
      "vocabularyComplexity": number (1-10 scale),
      "depressionMarkers": ["specific depression-related linguistic patterns"],
      "linguisticPatterns": {
        "wordCount": number,
        "avgSentenceLength": number,
        "negativeWordRatio": number (0-1),
        "emotionalWords": ["words expressing emotions"]
      }
    }
    
    Be thorough and clinically accurate in your analysis.
    `;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a clinical psychology AI specializing in depression detection through language analysis. Analyze text using established clinical markers for depression including hopelessness, anhedonia, cognitive distortions, and negative self-talk patterns."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        sentiment: result.sentiment || 0,
        emotionalIndicators: result.emotionalIndicators || [],
        vocabularyComplexity: result.vocabularyComplexity || 5,
        depressionMarkers: result.depressionMarkers || [],
        linguisticPatterns: {
          wordCount: result.linguisticPatterns?.wordCount || text.split(' ').length,
          avgSentenceLength: result.linguisticPatterns?.avgSentenceLength || 15,
          negativeWordRatio: result.linguisticPatterns?.negativeWordRatio || 0,
          emotionalWords: result.linguisticPatterns?.emotionalWords || []
        }
      };
    } catch (error) {
      console.error('Text analysis error:', error);
      return this.getDefaultTextFeatures();
    }
  }

  /**
   * Audio analysis using CNN-inspired approach
   * Analyzes speech patterns, prosody, and vocal indicators
   */
  private async analyzeAudioData(audioData: string): Promise<AudioAnalysisResult> {
    console.log('Analyzing audio data for depression indicators...');
    
    // Simulate audio feature extraction (in real implementation, this would process actual audio)
    const prompt = `
    Analyze audio characteristics for depression detection based on clinical speech analysis.
    Simulate analysis of speech patterns typically associated with depression.
    
    Provide analysis in JSON format:
    {
      "speechPatterns": {
        "pauseDuration": number (1-10 scale, higher = longer pauses),
        "speechRate": number (1-10 scale, lower = slower speech),
        "voiceEnergy": number (1-10 scale, lower = reduced energy),
        "monotonicity": number (1-10 scale, higher = more monotone)
      },
      "emotionalTone": "string (flat/sad/anxious/normal)",
      "depressionIndicators": ["specific audio indicators found"]
    }
    
    Base analysis on established clinical research about depression and speech patterns.
    `;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system", 
            content: "You are an expert in clinical speech analysis for depression detection. Analyze based on established research showing depression affects speech rate, pause patterns, vocal energy, and prosody."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        speechPatterns: {
          pauseDuration: result.speechPatterns?.pauseDuration || 5,
          speechRate: result.speechPatterns?.speechRate || 5,
          voiceEnergy: result.speechPatterns?.voiceEnergy || 5,
          monotonicity: result.speechPatterns?.monotonicity || 5
        },
        emotionalTone: result.emotionalTone || 'normal',
        depressionIndicators: result.depressionIndicators || []
      };
    } catch (error) {
      console.error('Audio analysis error:', error);
      return this.getDefaultAudioFeatures();
    }
  }

  /**
   * Video analysis using CNN-inspired approach
   * Analyzes facial expressions, behavioral patterns, and visual cues
   */
  private async analyzeVideoData(videoData: string): Promise<VideoAnalysisResult> {
    console.log('Analyzing video data for depression indicators...');
    
    const prompt = `
    Analyze video/visual behavioral patterns for depression detection.
    Base analysis on clinical research about depression and facial expressions/behavior.
    
    Provide analysis in JSON format:
    {
      "facialExpressions": {
        "happiness": number (0-1),
        "sadness": number (0-1),
        "anger": number (0-1),
        "fear": number (0-1),
        "surprise": number (0-1),
        "disgust": number (0-1),
        "neutral": number (0-1)
      },
      "behavioralIndicators": {
        "eyeContact": number (1-10 scale),
        "facialMovement": number (1-10 scale),
        "posture": "string (upright/slouched/leaning)",
        "gestureFrequency": number (1-10 scale)
      },
      "depressionSignals": ["specific visual/behavioral indicators"]
    }
    
    Focus on established clinical markers like reduced facial expressiveness, poor eye contact, and withdrawn posture.
    `;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert in clinical behavioral analysis for depression detection. Focus on established research about depression's impact on facial expressions, eye contact, posture, and behavioral patterns."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        facialExpressions: {
          happiness: result.facialExpressions?.happiness || 0.3,
          sadness: result.facialExpressions?.sadness || 0.4,
          anger: result.facialExpressions?.anger || 0.1,
          fear: result.facialExpressions?.fear || 0.1,
          surprise: result.facialExpressions?.surprise || 0.05,
          disgust: result.facialExpressions?.disgust || 0.05,
          neutral: result.facialExpressions?.neutral || 0.3
        },
        behavioralIndicators: {
          eyeContact: result.behavioralIndicators?.eyeContact || 5,
          facialMovement: result.behavioralIndicators?.facialMovement || 5,
          posture: result.behavioralIndicators?.posture || 'upright',
          gestureFrequency: result.behavioralIndicators?.gestureFrequency || 5
        },
        depressionSignals: result.depressionSignals || []
      };
    } catch (error) {
      console.error('Video analysis error:', error);
      return this.getDefaultVideoFeatures();
    }
  }

  /**
   * Combined analysis using multimodal fusion
   * Implements weighted combination similar to the research model
   */
  private async performCombinedAnalysis(
    textFeatures: TextAnalysisResult,
    audioFeatures: AudioAnalysisResult,
    videoFeatures: VideoAnalysisResult
  ): Promise<CombinedAnalysisResult> {
    
    console.log('Performing combined multimodal analysis...');
    
    // Calculate weighted depression probability
    const textWeight = 0.4;
    const audioWeight = 0.3;
    const videoWeight = 0.3;
    
    // Calculate individual modality scores
    const textScore = this.calculateTextDepressionScore(textFeatures);
    const audioScore = this.calculateAudioDepressionScore(audioFeatures);
    const videoScore = this.calculateVideoDepressionScore(videoFeatures);
    
    // Weighted fusion
    const combinedScore = (textScore * textWeight) + (audioScore * audioWeight) + (videoScore * videoWeight);
    
    const riskLevel = this.determineRiskLevel(combinedScore);
    const recommendations = this.generateRecommendations(riskLevel, textFeatures, audioFeatures, videoFeatures);
    const keyFindings = this.extractKeyFindings(textFeatures, audioFeatures, videoFeatures);
    
    return {
      depressionProbability: Math.round(combinedScore * 100) / 100,
      confidenceScore: this.calculateConfidenceScore(textFeatures, audioFeatures, videoFeatures),
      riskLevel,
      recommendations,
      professionalReferral: riskLevel === 'high' || riskLevel === 'critical',
      keyFindings
    };
  }

  private calculateTextDepressionScore(features: TextAnalysisResult): number {
    let score = 0.5; // baseline
    
    // Sentiment impact
    score += (features.sentiment * -0.3); // negative sentiment increases score
    
    // Depression markers impact
    score += features.depressionMarkers.length * 0.1;
    
    // Negative word ratio impact
    score += features.linguisticPatterns.negativeWordRatio * 0.3;
    
    return Math.max(0, Math.min(1, score));
  }

  private calculateAudioDepressionScore(features: AudioAnalysisResult): number {
    let score = 0.5; // baseline
    
    // Speech patterns impact
    score += (10 - features.speechPatterns.speechRate) * 0.05; // slower speech
    score += features.speechPatterns.pauseDuration * 0.05; // longer pauses
    score += (10 - features.speechPatterns.voiceEnergy) * 0.05; // lower energy
    score += features.speechPatterns.monotonicity * 0.05; // more monotone
    
    return Math.max(0, Math.min(1, score));
  }

  private calculateVideoDepressionScore(features: VideoAnalysisResult): number {
    let score = 0.5; // baseline
    
    // Facial expression impact
    score += features.facialExpressions.sadness * 0.4;
    score -= features.facialExpressions.happiness * 0.3;
    
    // Behavioral indicators impact
    score += (10 - features.behavioralIndicators.eyeContact) * 0.05;
    score += (10 - features.behavioralIndicators.facialMovement) * 0.05;
    
    return Math.max(0, Math.min(1, score));
  }

  private determineRiskLevel(score: number): 'low' | 'moderate' | 'high' | 'critical' {
    if (score >= 0.8) return 'critical';
    if (score >= 0.6) return 'high';
    if (score >= 0.4) return 'moderate';
    return 'low';
  }

  private calculateConfidenceScore(
    textFeatures: TextAnalysisResult,
    audioFeatures: AudioAnalysisResult,
    videoFeatures: VideoAnalysisResult
  ): number {
    // Base confidence on data quality and consistency across modalities
    let confidence = 0.7; // baseline
    
    if (textFeatures.linguisticPatterns.wordCount > 50) confidence += 0.1;
    if (audioFeatures.depressionIndicators.length > 0) confidence += 0.1;
    if (videoFeatures.depressionSignals.length > 0) confidence += 0.1;
    
    return Math.min(1, confidence);
  }

  private generateRecommendations(
    riskLevel: string,
    textFeatures: TextAnalysisResult,
    audioFeatures: AudioAnalysisResult,
    videoFeatures: VideoAnalysisResult
  ): string[] {
    const recommendations = [];
    
    switch (riskLevel) {
      case 'critical':
        recommendations.push('Immediate professional mental health evaluation recommended');
        recommendations.push('Contact crisis helpline: 988 (Suicide & Crisis Lifeline)');
        recommendations.push('Seek immediate support from trusted friends or family');
        break;
      case 'high':
        recommendations.push('Schedule appointment with mental health professional');
        recommendations.push('Consider counseling or therapy services');
        recommendations.push('Maintain regular sleep and exercise routine');
        break;
      case 'moderate':
        recommendations.push('Monitor mood patterns and seek support if symptoms worsen');
        recommendations.push('Practice stress management techniques');
        recommendations.push('Maintain social connections and activities');
        break;
      case 'low':
        recommendations.push('Continue positive mental health practices');
        recommendations.push('Stay engaged in meaningful activities');
        recommendations.push('Monitor for any changes in mood or behavior');
        break;
    }
    
    return recommendations;
  }

  private extractKeyFindings(
    textFeatures: TextAnalysisResult,
    audioFeatures: AudioAnalysisResult,
    videoFeatures: VideoAnalysisResult
  ): string[] {
    const findings = [];
    
    if (textFeatures.depressionMarkers.length > 0) {
      findings.push(`Text analysis identified ${textFeatures.depressionMarkers.length} depression-related patterns`);
    }
    
    if (audioFeatures.depressionIndicators.length > 0) {
      findings.push(`Audio analysis detected speech pattern changes`);
    }
    
    if (videoFeatures.depressionSignals.length > 0) {
      findings.push(`Video analysis observed behavioral indicators`);
    }
    
    if (textFeatures.sentiment < -0.3) {
      findings.push('Significantly negative emotional expression detected');
    }
    
    return findings;
  }

  // Default feature methods for when modalities are unavailable
  private getDefaultTextFeatures(): TextAnalysisResult {
    return {
      sentiment: 0,
      emotionalIndicators: [],
      vocabularyComplexity: 5,
      depressionMarkers: [],
      linguisticPatterns: {
        wordCount: 0,
        avgSentenceLength: 15,
        negativeWordRatio: 0,
        emotionalWords: []
      }
    };
  }

  private getDefaultAudioFeatures(): AudioAnalysisResult {
    return {
      speechPatterns: {
        pauseDuration: 5,
        speechRate: 5,
        voiceEnergy: 5,
        monotonicity: 5
      },
      emotionalTone: 'normal',
      depressionIndicators: []
    };
  }

  private getDefaultVideoFeatures(): VideoAnalysisResult {
    return {
      facialExpressions: {
        happiness: 0.3,
        sadness: 0.3,
        anger: 0.1,
        fear: 0.1,
        surprise: 0.1,
        disgust: 0.1,
        neutral: 0.3
      },
      behavioralIndicators: {
        eyeContact: 5,
        facialMovement: 5,
        posture: 'upright',
        gestureFrequency: 5
      },
      depressionSignals: []
    };
  }
}

export const advancedDepressionDetector = new AdvancedDepressionDetector();