import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface AnalysisData {
  sessionId: string;
  depressionRiskScore: number;
  severityLevel: string;
  confidence: number;
  modalityScores: any;
  clinicalIndicators: any;
  riskFactors: string[];
  protectiveFactors: string[];
  interventionRecommendations: string[];
  monitoringNeeds: string[];
  researchFindings: any;
  processingTimeMs: number;
}

// NLX-inspired JSON-to-Text conversion service
export class JsonToTextConverter {
  
  // Convert structured JSON analysis to natural language summary
  static async convertAnalysisToNaturalText(
    analysisData: AnalysisData, 
    studentName: string = 'Anonymous'
  ): Promise<string> {
    try {
      // Create structured prompt for GPT-4o to convert JSON to natural language
      const prompt = `Convert the following mental health analysis JSON data into a clear, professional summary in natural language. Focus on making it understandable for non-technical readers while maintaining clinical accuracy.

JSON Analysis Data:
${JSON.stringify(analysisData, null, 2)}

Student Name: ${studentName}

Please create a summary that includes:
1. A brief overall assessment
2. Key findings in simple terms
3. Risk level explanation
4. Main recommendations
5. Next steps for monitoring

Format as a professional but accessible clinical summary. Use clear, direct language that parents, teachers, or students could understand.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a clinical psychologist expert at translating complex mental health analysis data into clear, understandable summaries for non-technical audiences. Your summaries should be professional yet accessible, focusing on actionable insights."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 800,
        temperature: 0.3
      });

      return response.choices[0].message.content || "Unable to generate summary";
    } catch (error) {
      console.error("Error converting JSON to text:", error);
      return this.generateFallbackSummary(analysisData, studentName);
    }
  }

  // Generate structured template-based summary (fallback method)
  static generateFallbackSummary(analysisData: AnalysisData, studentName: string): string {
    const riskLevel = analysisData.severityLevel || 'unknown';
    const riskScore = Math.round(analysisData.depressionRiskScore || 0);
    const confidence = Math.round((analysisData.confidence || 0) * 100);

    const riskInterpretation = this.interpretRiskLevel(riskScore);
    const bestModality = this.getBestModality(analysisData.modalityScores);

    return `MENTAL HEALTH ANALYSIS SUMMARY FOR ${studentName}

OVERALL ASSESSMENT
${studentName} has been assessed for depression risk indicators using advanced multimodal analysis technology. The analysis examined video, audio, facial expressions, and behavioral patterns to provide a comprehensive evaluation.

RISK EVALUATION
Risk Level: ${riskLevel.toUpperCase()}
Risk Score: ${riskScore}% (out of 100%)
Analysis Confidence: ${confidence}%

WHAT THIS MEANS
${riskInterpretation}

KEY FINDINGS
The analysis was most effective using ${bestModality} data, processing the assessment in ${Math.round((analysisData.processingTimeMs || 0) / 1000)} seconds. The evaluation follows research-based methodology from the European Conference on Information Retrieval (ECIR 2024) standards for multimodal depression detection.

CLINICAL INDICATORS DETECTED
${this.formatClinicalIndicators(analysisData.clinicalIndicators)}

PROTECTIVE FACTORS IDENTIFIED
${analysisData.protectiveFactors?.slice(0, 3).map(factor => `• ${factor}`).join('\n') || '• General resilience indicators present'}

RECOMMENDED ACTIONS
${analysisData.interventionRecommendations?.slice(0, 3).map(rec => `• ${rec}`).join('\n') || '• Continue regular monitoring\n• Maintain supportive environment\n• Encourage open communication'}

MONITORING PLAN
${analysisData.monitoringNeeds?.slice(0, 3).map(need => `• ${need}`).join('\n') || '• Weekly check-ins recommended\n• Monitor for changes in behavior\n• Maintain regular assessment schedule'}

IMPORTANT NOTES
This analysis is for educational and research purposes. It should supplement, not replace, professional mental health evaluation. If you have concerns about mental health, please consult with a qualified healthcare professional.

Analysis completed on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}
Session ID: ${analysisData.sessionId}`;
  }

  private static interpretRiskLevel(riskScore: number): string {
    if (riskScore < 25) {
      return "The analysis indicates low risk for depression. The individual shows healthy emotional patterns and stable mental health indicators. This is a positive result suggesting good psychological well-being.";
    } else if (riskScore < 50) {
      return "The analysis shows mild concern with some early warning indicators detected. While not immediately alarming, this suggests the need for preventive measures and regular monitoring to maintain mental wellness.";
    } else if (riskScore < 75) {
      return "The analysis indicates moderate risk with several concerning patterns identified. Professional consultation is recommended to develop appropriate intervention strategies and support systems.";
    } else {
      return "The analysis shows high risk with multiple serious indicators present. Immediate professional mental health support is strongly recommended to ensure safety and appropriate care.";
    }
  }

  private static getBestModality(modalityScores: any): string {
    if (!modalityScores || typeof modalityScores !== 'object') {
      return 'multimodal analysis';
    }

    const entries = Object.entries(modalityScores);
    if (entries.length === 0) return 'multimodal analysis';

    const best = entries.sort(([,a], [,b]) => Number(b) - Number(a))[0];
    return `${best[0]} analysis`;
  }

  private static formatClinicalIndicators(indicators: any): string {
    if (!indicators || typeof indicators !== 'object') {
      return '• Standard assessment protocols applied';
    }

    const formatted = Object.entries(indicators)
      .map(([category, items]) => {
        const categoryName = category.replace(/([A-Z])/g, ' $1').trim();
        const itemList = Array.isArray(items) ? items.slice(0, 2) : [String(items)];
        return `${categoryName.charAt(0).toUpperCase() + categoryName.slice(1)}: ${itemList.join(', ')}`;
      })
      .slice(0, 3)
      .map(item => `• ${item}`)
      .join('\n');

    return formatted || '• Comprehensive multimodal assessment completed';
  }
}