import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY,
});

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'easy' | 'medium' | 'hard';
  subject: string;
  explanation?: string;
  timeEstimate?: number;
}

interface QuizGenerationParams {
  subject: string;
  difficulty: 'easy' | 'medium' | 'hard';
  questionCount: number;
  studentLevel?: string;
  adaptiveMode?: boolean;
  focusAreas?: string[];
}

interface AdaptiveQuizParams extends QuizGenerationParams {
  previousAnswers?: Array<{
    questionId: string;
    correct: boolean;
    timeSpent: number;
  }>;
  currentPerformance?: {
    accuracy: number;
    averageTime: number;
    weakAreas: string[];
  };
}

/**
 * Generates UPSC quiz questions using AI
 * Integrates concepts from UPSC-Star repository for authentic question patterns
 */
export async function generateUPSCQuiz(params: QuizGenerationParams): Promise<QuizQuestion[]> {
  const { subject, difficulty, questionCount } = params;
  
  try {
    console.log(`📚 Generating ${questionCount} ${difficulty} questions for ${subject}`);
    
    if (!process.env.OPENAI_API_KEY) {
      // Fallback questions for demo
      return generateFallbackQuestions(params);
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert UPSC question generator. Create high-quality multiple choice questions following these guidelines:

1. Generate exactly ${questionCount} questions on ${subject}
2. Difficulty level: ${difficulty}
3. Each question should have 4 options with exactly one correct answer
4. Questions should be factual, relevant to UPSC syllabus, and current (2020-2024)
5. Cover diverse topics within the subject
6. Include proper explanations for the correct answers

For ${subject}, focus on:
- Current affairs and recent developments
- Constitutional and legal aspects
- Historical context and significance
- Policy implications and governance
- Economic and social impact

Respond with JSON only in this exact format:
{
  "questions": [
    {
      "question": "Question text here?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0,
      "subject": "${subject}",
      "difficulty": "${difficulty}",
      "explanation": "Brief explanation of why this answer is correct",
      "timeEstimate": 60
    }
  ]
}`
        },
        {
          role: "user",
          content: `Generate ${questionCount} ${difficulty} level UPSC questions on ${subject}. Make them challenging but fair, covering recent developments and core concepts.`
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 4000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"questions": []}');
    
    // Add unique IDs and validate structure
    const questions: QuizQuestion[] = result.questions.map((q: any, index: number) => ({
      id: `q_${Date.now()}_${index}`,
      question: q.question || `Sample question ${index + 1}`,
      options: Array.isArray(q.options) && q.options.length === 4 
        ? q.options 
        : [`Option A`, `Option B`, `Option C`, `Option D`],
      correctAnswer: typeof q.correctAnswer === 'number' && q.correctAnswer >= 0 && q.correctAnswer < 4 
        ? q.correctAnswer 
        : 0,
      difficulty: difficulty,
      subject: subject,
      explanation: q.explanation || 'Explanation not provided',
      timeEstimate: q.timeEstimate || getDifficultyTimeEstimate(difficulty)
    }));

    console.log(`✅ Generated ${questions.length} questions successfully`);
    return questions;

  } catch (error) {
    console.error("Quiz generation error:", error);
    
    // Return fallback questions on error
    return generateFallbackQuestions(params);
  }
}

/**
 * Generates adaptive quiz questions based on student performance
 * Implements concepts from MLH-Quizzet for intelligent question selection
 */
export async function generateAdaptiveQuiz(params: AdaptiveQuizParams): Promise<QuizQuestion[]> {
  const { previousAnswers, currentPerformance } = params;
  
  // Adjust difficulty based on performance
  let adjustedDifficulty = params.difficulty;
  
  if (currentPerformance) {
    if (currentPerformance.accuracy > 0.8) {
      // Student performing well, increase difficulty
      adjustedDifficulty = params.difficulty === 'easy' ? 'medium' : 
                          params.difficulty === 'medium' ? 'hard' : 'hard';
    } else if (currentPerformance.accuracy < 0.5) {
      // Student struggling, decrease difficulty
      adjustedDifficulty = params.difficulty === 'hard' ? 'medium' : 
                          params.difficulty === 'medium' ? 'easy' : 'easy';
    }
  }
  
  // Focus on weak areas
  const focusAreas = currentPerformance?.weakAreas || params.focusAreas || [];
  const adaptedSubject = focusAreas.length > 0 
    ? `${params.subject} (focus on: ${focusAreas.join(', ')})` 
    : params.subject;
  
  console.log(`🎯 Generating adaptive quiz: ${adjustedDifficulty} level, focusing on ${adaptedSubject}`);
  
  return generateUPSCQuiz({
    ...params,
    subject: adaptedSubject,
    difficulty: adjustedDifficulty
  });
}

/**
 * Evaluates quiz answers and provides detailed feedback
 */
export async function evaluateQuizAnswers(
  questions: QuizQuestion[],
  answers: Record<string, number>,
  facialMetrics?: any[]
): Promise<{
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  detailedResults: Array<{
    questionId: string;
    correct: boolean;
    selectedAnswer: number;
    correctAnswer: number;
    explanation: string;
  }>;
  performanceAnalysis: {
    accuracy: number;
    averageTime?: number;
    strongAreas: string[];
    weakAreas: string[];
    attentionLevel?: number;
  };
  recommendations: string[];
}> {
  const detailedResults = questions.map(question => {
    const selectedAnswer = answers[question.id];
    const correct = selectedAnswer === question.correctAnswer;
    
    return {
      questionId: question.id,
      correct,
      selectedAnswer: selectedAnswer ?? -1,
      correctAnswer: question.correctAnswer,
      explanation: question.explanation || 'No explanation provided'
    };
  });
  
  const correctAnswers = detailedResults.filter(r => r.correct).length;
  const score = Math.round((correctAnswers / questions.length) * 100);
  
  // Analyze performance by subject areas
  const subjectPerformance = questions.reduce((acc, question, index) => {
    const subject = question.subject;
    if (!acc[subject]) acc[subject] = { correct: 0, total: 0 };
    acc[subject].total++;
    if (detailedResults[index].correct) acc[subject].correct++;
    return acc;
  }, {} as Record<string, { correct: number; total: number }>);
  
  const strongAreas = Object.entries(subjectPerformance)
    .filter(([_, perf]) => perf.correct / perf.total > 0.7)
    .map(([subject]) => subject);
  
  const weakAreas = Object.entries(subjectPerformance)
    .filter(([_, perf]) => perf.correct / perf.total < 0.5)
    .map(([subject]) => subject);
  
  // Calculate attention level from facial metrics
  const attentionLevel = facialMetrics && facialMetrics.length > 0
    ? facialMetrics.reduce((sum, metric) => sum + (metric.attentionScore || 0), 0) / facialMetrics.length
    : undefined;
  
  // Generate recommendations
  const recommendations = generatePerformanceRecommendations({
    score,
    accuracy: correctAnswers / questions.length,
    strongAreas,
    weakAreas,
    attentionLevel
  });
  
  return {
    score,
    totalQuestions: questions.length,
    correctAnswers,
    detailedResults,
    performanceAnalysis: {
      accuracy: correctAnswers / questions.length,
      strongAreas,
      weakAreas,
      attentionLevel
    },
    recommendations
  };
}

/**
 * Generates fallback questions when AI generation fails
 */
function generateFallbackQuestions(params: QuizGenerationParams): QuizQuestion[] {
  const { subject, difficulty, questionCount } = params;
  
  const sampleQuestions = {
    'Indian History': [
      {
        question: "Who was the first Governor-General of Bengal?",
        options: ["Warren Hastings", "Robert Clive", "Lord Cornwallis", "Lord Wellesley"],
        correctAnswer: 0,
        explanation: "Warren Hastings was the first Governor-General of Bengal (1773-1785)."
      },
      {
        question: "The Quit India Movement was launched in which year?",
        options: ["1940", "1942", "1944", "1946"],
        correctAnswer: 1,
        explanation: "The Quit India Movement was launched by Mahatma Gandhi on August 8, 1942."
      }
    ],
    'Geography': [
      {
        question: "Which river forms the northern boundary of the Deccan Plateau?",
        options: ["Godavari", "Krishna", "Narmada", "Tapti"],
        correctAnswer: 2,
        explanation: "The Narmada River forms the northern boundary of the Deccan Plateau."
      }
    ],
    'Current Affairs': [
      {
        question: "Which organization publishes the World Happiness Report?",
        options: ["World Bank", "United Nations", "WHO", "IMF"],
        correctAnswer: 1,
        explanation: "The World Happiness Report is published by the United Nations Sustainable Development Solutions Network."
      }
    ]
  };
  
  const availableQuestions = sampleQuestions[subject as keyof typeof sampleQuestions] || sampleQuestions['Current Affairs'];
  const selectedQuestions = availableQuestions.slice(0, Math.min(questionCount, availableQuestions.length));
  
  return selectedQuestions.map((q, index) => ({
    id: `fallback_${Date.now()}_${index}`,
    question: q.question,
    options: q.options,
    correctAnswer: q.correctAnswer,
    difficulty: difficulty,
    subject: subject,
    explanation: q.explanation,
    timeEstimate: getDifficultyTimeEstimate(difficulty)
  }));
}

function getDifficultyTimeEstimate(difficulty: 'easy' | 'medium' | 'hard'): number {
  switch (difficulty) {
    case 'easy': return 45; // 45 seconds
    case 'medium': return 75; // 1 minute 15 seconds
    case 'hard': return 120; // 2 minutes
    default: return 60;
  }
}

function generatePerformanceRecommendations(analysis: {
  score: number;
  accuracy: number;
  strongAreas: string[];
  weakAreas: string[];
  attentionLevel?: number;
}): string[] {
  const recommendations: string[] = [];
  
  if (analysis.score >= 80) {
    recommendations.push("Excellent performance! You're well-prepared for this topic.");
    recommendations.push("Consider attempting more challenging questions or new topics.");
  } else if (analysis.score >= 60) {
    recommendations.push("Good performance with room for improvement.");
    recommendations.push("Review the explanations for incorrect answers.");
  } else {
    recommendations.push("Focus on strengthening your fundamentals in this topic.");
    recommendations.push("Consider studying from reliable UPSC preparation materials.");
  }
  
  if (analysis.weakAreas.length > 0) {
    recommendations.push(`Prioritize studying: ${analysis.weakAreas.join(', ')}`);
  }
  
  if (analysis.strongAreas.length > 0) {
    recommendations.push(`Your strong areas: ${analysis.strongAreas.join(', ')} - maintain this level!`);
  }
  
  if (analysis.attentionLevel !== undefined) {
    if (analysis.attentionLevel < 50) {
      recommendations.push("Your attention level was low during the quiz. Consider taking breaks and improving focus.");
    } else if (analysis.attentionLevel > 80) {
      recommendations.push("Excellent focus throughout the quiz! This concentration will help in the actual exam.");
    }
  }
  
  return recommendations;
}

/**
 * Gets next question in adaptive mode based on previous performance
 */
export async function getNextAdaptiveQuestion(
  sessionId: string,
  previousAnswers: any[],
  currentDifficulty: string,
  subject: string
): Promise<QuizQuestion | null> {
  // Calculate current performance
  const totalAnswered = previousAnswers.length;
  const correctCount = previousAnswers.filter(a => a.correct).length;
  const accuracy = totalAnswered > 0 ? correctCount / totalAnswered : 0;
  
  // Determine if difficulty should change
  let nextDifficulty = currentDifficulty as 'easy' | 'medium' | 'hard';
  
  if (totalAnswered >= 3) { // Need at least 3 answers to adjust
    if (accuracy > 0.8 && nextDifficulty !== 'hard') {
      nextDifficulty = nextDifficulty === 'easy' ? 'medium' : 'hard';
    } else if (accuracy < 0.4 && nextDifficulty !== 'easy') {
      nextDifficulty = nextDifficulty === 'hard' ? 'medium' : 'easy';
    }
  }
  
  const questions = await generateUPSCQuiz({
    subject,
    difficulty: nextDifficulty,
    questionCount: 1,
    adaptiveMode: true
  });
  
  return questions[0] || null;
}