import { Client } from "@gradio/client";

export interface ThumbnailOptions {
  prompt: string;
  negativePrompt?: string;
  width?: number;
  height?: number;
  guidanceScale?: number;
  numInferenceSteps?: number;
  seed?: number;
}

// Array of different Gradio endpoints for load balancing and fallback
const GRADIO_ENDPOINTS = [
  "black-forest-labs/FLUX.1-schnell", // Fastest model, low resource usage
  "XLabs-AI/flux-RealismLora", // Alternative FLUX model
  "stabilityai/stable-diffusion-3-medium", // Backup endpoint
];

let currentEndpointIndex = 0;

export async function generateThumbnailImage(options: ThumbnailOptions): Promise<string> {
  const maxRetries = GRADIO_ENDPOINTS.length;
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const endpoint = GRADIO_ENDPOINTS[currentEndpointIndex];
      console.log(`Attempting thumbnail generation with endpoint: ${endpoint} (attempt ${attempt + 1}/${maxRetries})`);
      
      const client = await Client.connect(endpoint);
      let result;
      
      // Different endpoints have different interfaces
      if (endpoint.includes("FLUX")) {
        // FLUX models are faster and use less GPU quota
        result = await client.predict("/infer", {
          prompt: options.prompt,
          seed: options.seed || Math.floor(Math.random() * 1000000),
          randomize_seed: true,
          width: options.width || 1280,
          height: options.height || 720,
          num_inference_steps: 4, // FLUX is very fast
        });
      } else if (endpoint.includes("stable-diffusion")) {
        // Standard Stable Diffusion interface
        result = await client.predict("/infer", {
          prompt: options.prompt,
          negative_prompt: options.negativePrompt || "low quality, blurry, distorted, watermark, text artifacts",
          width: options.width || 1280,
          height: options.height || 720,
          guidance_scale: options.guidanceScale || 5,
          num_inference_steps: 20, // Reduced for faster generation
          seed: options.seed || Math.floor(Math.random() * 1000000),
          randomize_seed: true,
        });
      } else {
        // Generic fallback
        result = await client.predict("/infer", {
          prompt: options.prompt,
          width: options.width || 1280,
          height: options.height || 720,
        });
      }

      // Extract the image URL from the result
      if (result && Array.isArray(result.data) && result.data[0]) {
        const imageUrl = (result.data[0] as any).url || result.data[0];
        if (imageUrl) {
          console.log(`Successfully generated thumbnail with ${endpoint}`);
          return imageUrl;
        }
      }
      
      throw new Error("No image URL returned from the AI service");
      
    } catch (error) {
      console.error(`Thumbnail generation error with endpoint ${GRADIO_ENDPOINTS[currentEndpointIndex]}:`, error);
      lastError = error instanceof Error ? error : new Error(String(error));
      
      // Move to next endpoint for next attempt
      currentEndpointIndex = (currentEndpointIndex + 1) % GRADIO_ENDPOINTS.length;
      
      // If this was a quota error, wait a bit before trying next endpoint
      if (error && typeof error === 'object' && 'message' in error && 
          typeof error.message === 'string' && error.message.includes('quota')) {
        console.log(`GPU quota exceeded on endpoint, trying next one...`);
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  }

  // If all endpoints failed, create a custom educational thumbnail
  console.warn("All thumbnail generation endpoints failed, using enhanced fallback");
  return generateEnhancedFallback(options);
}

function generateEnhancedFallback(options: ThumbnailOptions): string {
  // Create a more sophisticated fallback that matches the request
  const cleanTitle = encodeURIComponent(options.prompt.slice(0, 50) + (options.prompt.length > 50 ? '...' : ''));
  
  // Use a service that creates better educational thumbnails
  const fallbackUrl = `https://via.placeholder.com/1280x720/1e40af/ffffff?text=${cleanTitle}&fontsize=28`;
  
  console.log(`Generated fallback thumbnail: ${fallbackUrl}`);
  return fallbackUrl;
}

export async function removeBackground(imageUrl: string): Promise<string> {
  try {
    // This would typically use a background removal service
    // For now, return the original image
    return imageUrl;
  } catch (error) {
    console.error("Background removal error:", error);
    return imageUrl;
  }
}
