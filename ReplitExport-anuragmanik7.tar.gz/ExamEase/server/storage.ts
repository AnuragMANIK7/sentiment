import { 
  type ChatSession, 
  type InsertChatSession, 
  type Prompt, 
  type InsertPrompt, 
  type Thumbnail, 
  type InsertThumbnail,
  type MentalHealthSession,
  type InsertMentalHealthSession,
  type EmotionDetection,
  type InsertEmotionDetection,
  type MentalHealthReport,
  type PromptUsageMetric,
  type InsertPromptUsageMetric,
  type PromptPerformanceAnalytic,
  type InsertPromptPerformanceAnalytic,
  type PromptFeedback,
  type InsertPromptFeedback,
  type SimpleUser,
  type InsertSimpleUser,
  type ChatSessionWithUser,
  type InsertChatSessionWithUser,
  type PromptWithUser,
  type InsertPromptWithUser,
  type ThumbnailWithUser,
  type InsertThumbnailWithUser,
  type MentalHealthWithUser,
  type InsertMentalHealthWithUser
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Chat sessions
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  getChatSession(id: string): Promise<ChatSession | undefined>;
  
  // Prompts
  createPrompt(prompt: InsertPrompt & { generatedPrompt: string }): Promise<Prompt>;
  getPrompts(limit?: number): Promise<Prompt[]>;
  getPrompt(id: string): Promise<Prompt | undefined>;
  
  // Thumbnails
  createThumbnail(thumbnail: InsertThumbnail): Promise<Thumbnail>;
  getThumbnails(limit?: number): Promise<Thumbnail[]>;
  getThumbnail(id: string): Promise<Thumbnail | undefined>;
  
  // Mental Health
  createMentalHealthSession(session: InsertMentalHealthSession & { 
    emotionAnalysis?: any; 
    sentimentAnalysis?: any; 
    riskScore?: number; 
    recommendations?: any; 
    alertLevel?: string; 
    flaggedForReview?: boolean; 
  }): Promise<MentalHealthSession>;
  getMentalHealthSessions(limit?: number): Promise<MentalHealthSession[]>;
  getMentalHealthSession(id: string): Promise<MentalHealthSession | undefined>;
  getMentalHealthSessionsByStudent(studentName: string, limit?: number): Promise<MentalHealthSession[]>;
  
  createEmotionDetection(detection: InsertEmotionDetection): Promise<EmotionDetection>;
  getEmotionDetectionsBySession(sessionId: string): Promise<EmotionDetection[]>;
  
  // Advanced Health Analysis (ECIR 2024 Research)
  createAdvancedHealthSession(session: InsertAdvancedHealthSession): Promise<AdvancedHealthSession>;
  getAdvancedHealthSessions(limit?: number): Promise<AdvancedHealthSession[]>;
  getAdvancedHealthSession(id: string): Promise<AdvancedHealthSession | undefined>;
  getAdvancedHealthSessionsByStudent(studentName: string, limit?: number): Promise<AdvancedHealthSession[]>;
  
  createAdvancedHealthReport(report: InsertAdvancedHealthReport): Promise<AdvancedHealthReport>;
  getAdvancedHealthReports(studentName?: string, limit?: number): Promise<AdvancedHealthReport[]>;
  getAdvancedHealthReport(id: string): Promise<AdvancedHealthReport | undefined>;
  
  // Prompt Analytics
  createPromptUsageMetric(metric: InsertPromptUsageMetric): Promise<PromptUsageMetric>;
  getPromptUsageMetrics(promptId?: string, limit?: number): Promise<PromptUsageMetric[]>;
  createPromptFeedback(feedback: InsertPromptFeedback): Promise<PromptFeedback>;
  getPromptFeedback(promptId: string): Promise<PromptFeedback[]>;
  getPromptAnalytics(promptId?: string): Promise<{
    totalUsage: number;
    averageRating: number;
    averageGenerationTime: number;
    successRate: number;
    categoryBreakdown: Record<string, number>;
    recentTrends: Array<{
      date: string;
      usage: number;
      rating: number;
    }>;
  }>;

  // Simple User Management
  createOrUpdateUser(username: string, fullName?: string): Promise<SimpleUser>;
  getUserByUsername(username: string): Promise<SimpleUser | undefined>;
  
  // User-specific content with username
  createChatSessionWithUser(data: InsertChatSessionWithUser): Promise<ChatSessionWithUser>;
  createPromptWithUser(data: InsertPromptWithUser): Promise<PromptWithUser>;
  createThumbnailWithUser(data: InsertThumbnailWithUser): Promise<ThumbnailWithUser>;
  createMentalHealthWithUser(data: InsertMentalHealthWithUser): Promise<MentalHealthWithUser>;
  
  // Retrieve user history
  getChatSessionsByUser(username: string, limit?: number): Promise<ChatSessionWithUser[]>;
  getPromptsByUser(username: string, limit?: number): Promise<PromptWithUser[]>;
  getThumbnailsByUser(username: string, limit?: number): Promise<ThumbnailWithUser[]>;
  getMentalHealthByUser(username: string, limit?: number): Promise<MentalHealthWithUser[]>;
}

export class MemStorage implements IStorage {
  private chatSessions: Map<string, ChatSession>;
  private prompts: Map<string, Prompt>;
  private thumbnails: Map<string, Thumbnail>;
  private mentalHealthSessions: Map<string, MentalHealthSession>;
  private emotionDetections: Map<string, EmotionDetection>;
  private promptUsageMetrics: Map<string, PromptUsageMetric>;
  private promptFeedback: Map<string, PromptFeedback>;
  private users: Map<string, User>;
  private userSessions: Map<string, UserSession>;
  private savedContent: Map<string, SavedContent>;

  constructor() {
    this.chatSessions = new Map();
    this.prompts = new Map();
    this.thumbnails = new Map();
    this.mentalHealthSessions = new Map();
    this.emotionDetections = new Map();
    this.promptUsageMetrics = new Map();
    this.promptFeedback = new Map();
    this.users = new Map();
    this.userSessions = new Map();
    this.savedContent = new Map();
  }

  async createChatSession(insertSession: InsertChatSession): Promise<ChatSession> {
    const id = randomUUID();
    const session: ChatSession = {
      ...insertSession,
      id,
      createdAt: new Date(),
    };
    this.chatSessions.set(id, session);
    return session;
  }

  async getChatSession(id: string): Promise<ChatSession | undefined> {
    return this.chatSessions.get(id);
  }

  async createPrompt(insertPrompt: InsertPrompt & { generatedPrompt: string }): Promise<Prompt> {
    const id = randomUUID();
    const prompt: Prompt = {
      ...insertPrompt,
      id,
      createdAt: new Date(),
      targetAudience: insertPrompt.targetAudience || null,
      contentTopic: insertPrompt.contentTopic || null,
      requirements: insertPrompt.requirements || null,
      tone: insertPrompt.tone || null,
      outputLength: insertPrompt.outputLength || null,
    };
    this.prompts.set(id, prompt);
    return prompt;
  }

  async getPrompts(limit = 10): Promise<Prompt[]> {
    return Array.from(this.prompts.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async getPrompt(id: string): Promise<Prompt | undefined> {
    return this.prompts.get(id);
  }

  async createThumbnail(insertThumbnail: InsertThumbnail): Promise<Thumbnail> {
    const id = randomUUID();
    const thumbnail: Thumbnail = {
      ...insertThumbnail,
      id,
      createdAt: new Date(),
      contentCategory: insertThumbnail.contentCategory || null,
      style: insertThumbnail.style || null,
      textOverlay: insertThumbnail.textOverlay || null,
      colorScheme: insertThumbnail.colorScheme || null,
      elements: insertThumbnail.elements || null,
      imageUrl: insertThumbnail.imageUrl || null,
    };
    this.thumbnails.set(id, thumbnail);
    return thumbnail;
  }

  async getThumbnails(limit = 10): Promise<Thumbnail[]> {
    return Array.from(this.thumbnails.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async getThumbnail(id: string): Promise<Thumbnail | undefined> {
    return this.thumbnails.get(id);
  }

  // Mental Health Methods
  async createMentalHealthSession(insertSession: InsertMentalHealthSession & { 
    emotionAnalysis?: any; 
    sentimentAnalysis?: any; 
    riskScore?: number; 
    recommendations?: any; 
    alertLevel?: string; 
    flaggedForReview?: boolean; 
  }): Promise<MentalHealthSession> {
    const id = randomUUID();
    const session: MentalHealthSession = {
      ...insertSession,
      id,
      createdAt: new Date(),
      videoUrl: insertSession.videoUrl || null,
      audioTranscript: insertSession.audioTranscript || null,
      textResponses: insertSession.textResponses || null,
      emotionAnalysis: insertSession.emotionAnalysis || null,
      sentimentAnalysis: insertSession.sentimentAnalysis || null,
      riskScore: insertSession.riskScore?.toString() || null,
      recommendations: insertSession.recommendations || null,
      alertLevel: insertSession.alertLevel || null,
      flaggedForReview: insertSession.flaggedForReview || false,
    };
    this.mentalHealthSessions.set(id, session);
    return session;
  }

  async getMentalHealthSessions(limit = 10): Promise<MentalHealthSession[]> {
    return Array.from(this.mentalHealthSessions.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async getMentalHealthSession(id: string): Promise<MentalHealthSession | undefined> {
    return this.mentalHealthSessions.get(id);
  }

  async getMentalHealthSessionsByStudent(studentName: string, limit = 10): Promise<MentalHealthSession[]> {
    return Array.from(this.mentalHealthSessions.values())
      .filter(session => session.studentName === studentName)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async createEmotionDetection(insertDetection: InsertEmotionDetection): Promise<EmotionDetection> {
    const id = randomUUID();
    const detection: EmotionDetection = {
      ...insertDetection,
      id,
      createdAt: new Date(),
      sessionId: insertDetection.sessionId || null,
      timestamp: insertDetection.timestamp?.toString() || null,
      emotions: insertDetection.emotions || null,
      dominantEmotion: insertDetection.dominantEmotion || null,
      confidence: insertDetection.confidence?.toString() || null,
    };
    this.emotionDetections.set(id, detection);
    return detection;
  }

  async getEmotionDetectionsBySession(sessionId: string): Promise<EmotionDetection[]> {
    return Array.from(this.emotionDetections.values())
      .filter(detection => detection.sessionId === sessionId)
      .sort((a, b) => parseFloat(a.timestamp || '0') - parseFloat(b.timestamp || '0'));
  }

  // Prompt Analytics Methods
  async createPromptUsageMetric(insertMetric: InsertPromptUsageMetric): Promise<PromptUsageMetric> {
    const id = randomUUID();
    const metric: PromptUsageMetric = {
      ...insertMetric,
      id,
      createdAt: new Date(),
      promptId: insertMetric.promptId || null,
      sessionId: insertMetric.sessionId || null,
      ipAddress: insertMetric.ipAddress || null,
      userAgent: insertMetric.userAgent || null,
      generationTime: insertMetric.generationTime || null,
      promptLength: insertMetric.promptLength || null,
      outputLength: insertMetric.outputLength || null,
      category: insertMetric.category || null,
      successRate: insertMetric.successRate || null,
      userRating: insertMetric.userRating || null,
      usageContext: insertMetric.usageContext || null,
    };
    this.promptUsageMetrics.set(id, metric);
    return metric;
  }

  async getPromptUsageMetrics(promptId?: string, limit = 50): Promise<PromptUsageMetric[]> {
    let metrics = Array.from(this.promptUsageMetrics.values());
    if (promptId) {
      metrics = metrics.filter(metric => metric.promptId === promptId);
    }
    return metrics
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async createPromptFeedback(insertFeedback: InsertPromptFeedback): Promise<PromptFeedback> {
    const id = randomUUID();
    const feedback: PromptFeedback = {
      ...insertFeedback,
      id,
      createdAt: new Date(),
      promptId: insertFeedback.promptId || null,
      sessionId: insertFeedback.sessionId || null,
      feedback: insertFeedback.feedback || null,
      useCase: insertFeedback.useCase || null,
      effectiveness: insertFeedback.effectiveness || null,
      improvementSuggestions: insertFeedback.improvementSuggestions || null,
    };
    this.promptFeedback.set(id, feedback);
    return feedback;
  }

  async getPromptFeedback(promptId: string): Promise<PromptFeedback[]> {
    return Array.from(this.promptFeedback.values())
      .filter(feedback => feedback.promptId === promptId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async getPromptAnalytics(promptId?: string): Promise<{
    totalUsage: number;
    averageRating: number;
    averageGenerationTime: number;
    successRate: number;
    categoryBreakdown: Record<string, number>;
    recentTrends: Array<{
      date: string;
      usage: number;
      rating: number;
    }>;
  }> {
    let metrics = Array.from(this.promptUsageMetrics.values());
    if (promptId) {
      metrics = metrics.filter(metric => metric.promptId === promptId);
    }

    const totalUsage = metrics.length;
    const ratingsWithValues = metrics.filter(m => m.userRating !== null).map(m => m.userRating!);
    const averageRating = ratingsWithValues.length > 0 
      ? ratingsWithValues.reduce((sum, rating) => sum + rating, 0) / ratingsWithValues.length 
      : 0;

    const generationTimes = metrics.filter(m => m.generationTime !== null).map(m => parseFloat(m.generationTime!));
    const averageGenerationTime = generationTimes.length > 0
      ? generationTimes.reduce((sum, time) => sum + time, 0) / generationTimes.length
      : 0;

    const successfulMetrics = metrics.filter(m => m.successRate === 'success');
    const successRate = totalUsage > 0 ? (successfulMetrics.length / totalUsage) * 100 : 0;

    const categoryBreakdown = metrics.reduce((acc, metric) => {
      const category = metric.category || 'uncategorized';
      acc[category] = (acc[category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Generate recent trends (last 7 days)
    const recentTrends = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateString = date.toISOString().split('T')[0];
      
      const dayMetrics = metrics.filter(metric => 
        metric.createdAt?.toISOString().split('T')[0] === dateString
      );
      
      const dayRatings = dayMetrics.filter(m => m.userRating !== null).map(m => m.userRating!);
      const avgRating = dayRatings.length > 0 
        ? dayRatings.reduce((sum, rating) => sum + rating, 0) / dayRatings.length 
        : 0;

      recentTrends.push({
        date: dateString,
        usage: dayMetrics.length,
        rating: avgRating,
      });
    }

    return {
      totalUsage,
      averageRating,
      averageGenerationTime,
      successRate,
      categoryBreakdown,
      recentTrends,
    };
  }
}

// Use database storage instead of memory storage
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import { 
  chatSessions, 
  prompts, 
  thumbnails, 
  mentalHealthSessions as mentalHealthSessionsTable, 
  emotionDetections as emotionDetectionsTable,
  promptUsageMetrics as promptUsageMetricsTable,
  promptFeedback as promptFeedbackTable,
  promptPerformanceAnalytics as promptPerformanceAnalyticsTable,
  simpleUsers,
  chatSessionsWithUser,
  promptsWithUser,
  thumbnailsWithUser,
  mentalHealthWithUser
} from "@shared/schema";

export class DatabaseStorage implements IStorage {
  async createChatSession(insertSession: InsertChatSession): Promise<ChatSession> {
    const [session] = await db
      .insert(chatSessions)
      .values(insertSession)
      .returning();
    return session;
  }

  async getChatSession(id: string): Promise<ChatSession | undefined> {
    const [session] = await db
      .select()
      .from(chatSessions)
      .where(eq(chatSessions.id, id));
    return session || undefined;
  }

  async createPrompt(insertPrompt: InsertPrompt & { generatedPrompt: string }): Promise<Prompt> {
    const [prompt] = await db
      .insert(prompts)
      .values(insertPrompt)
      .returning();
    return prompt;
  }

  async getPrompts(limit = 10): Promise<Prompt[]> {
    return await db
      .select()
      .from(prompts)
      .orderBy(desc(prompts.createdAt))
      .limit(limit);
  }

  async getPrompt(id: string): Promise<Prompt | undefined> {
    const [prompt] = await db
      .select()
      .from(prompts)
      .where(eq(prompts.id, id));
    return prompt || undefined;
  }

  async createThumbnail(insertThumbnail: InsertThumbnail): Promise<Thumbnail> {
    const [thumbnail] = await db
      .insert(thumbnails)
      .values(insertThumbnail)
      .returning();
    return thumbnail;
  }

  async getThumbnails(limit = 10): Promise<Thumbnail[]> {
    return await db
      .select()
      .from(thumbnails)
      .orderBy(desc(thumbnails.createdAt))
      .limit(limit);
  }

  async getThumbnail(id: string): Promise<Thumbnail | undefined> {
    const [thumbnail] = await db
      .select()
      .from(thumbnails)
      .where(eq(thumbnails.id, id));
    return thumbnail || undefined;
  }

  // Mental Health Database Methods
  async createMentalHealthSession(insertSession: InsertMentalHealthSession & { 
    emotionAnalysis?: any; 
    sentimentAnalysis?: any; 
    riskScore?: number; 
    recommendations?: any; 
    alertLevel?: string; 
    flaggedForReview?: boolean; 
  }): Promise<MentalHealthSession> {
    const [session] = await db
      .insert(mentalHealthSessionsTable)
      .values({
        ...insertSession,
        riskScore: insertSession.riskScore?.toString(),
      })
      .returning();
    return session;
  }

  async getMentalHealthSessions(limit = 10): Promise<MentalHealthSession[]> {
    return await db
      .select()
      .from(mentalHealthSessionsTable)
      .orderBy(desc(mentalHealthSessionsTable.createdAt))
      .limit(limit);
  }

  async getMentalHealthSession(id: string): Promise<MentalHealthSession | undefined> {
    const [session] = await db
      .select()
      .from(mentalHealthSessionsTable)
      .where(eq(mentalHealthSessionsTable.id, id));
    return session || undefined;
  }

  async getMentalHealthSessionsByStudent(studentName: string, limit = 10): Promise<MentalHealthSession[]> {
    return await db
      .select()
      .from(mentalHealthSessionsTable)
      .where(eq(mentalHealthSessionsTable.studentName, studentName))
      .orderBy(desc(mentalHealthSessionsTable.createdAt))
      .limit(limit);
  }

  async createEmotionDetection(insertDetection: InsertEmotionDetection): Promise<EmotionDetection> {
    const [detection] = await db
      .insert(emotionDetectionsTable)
      .values({
        ...insertDetection,
        timestamp: insertDetection.timestamp?.toString(),
        confidence: insertDetection.confidence?.toString(),
      })
      .returning();
    return detection;
  }

  async getEmotionDetectionsBySession(sessionId: string): Promise<EmotionDetection[]> {
    return await db
      .select()
      .from(emotionDetectionsTable)
      .where(eq(emotionDetectionsTable.sessionId, sessionId))
      .orderBy(emotionDetectionsTable.timestamp);
  }

  // Prompt Analytics Database Methods
  async createPromptUsageMetric(insertMetric: InsertPromptUsageMetric): Promise<PromptUsageMetric> {
    const [metric] = await db
      .insert(promptUsageMetricsTable)
      .values(insertMetric)
      .returning();
    return metric;
  }

  async getPromptUsageMetrics(promptId?: string, limit = 50): Promise<PromptUsageMetric[]> {
    let query = db.select().from(promptUsageMetricsTable);
    
    if (promptId) {
      query = query.where(eq(promptUsageMetricsTable.promptId, promptId)) as any;
    }
    
    return await query
      .orderBy(desc(promptUsageMetricsTable.createdAt))
      .limit(limit);
  }

  async createPromptFeedback(insertFeedback: InsertPromptFeedback): Promise<PromptFeedback> {
    const [feedback] = await db
      .insert(promptFeedbackTable)
      .values(insertFeedback)
      .returning();
    return feedback;
  }

  async getPromptFeedback(promptId: string): Promise<PromptFeedback[]> {
    return await db
      .select()
      .from(promptFeedbackTable)
      .where(eq(promptFeedbackTable.promptId, promptId))
      .orderBy(desc(promptFeedbackTable.createdAt));
  }

  async getPromptAnalytics(promptId?: string): Promise<{
    totalUsage: number;
    averageRating: number;
    averageGenerationTime: number;
    successRate: number;
    categoryBreakdown: Record<string, number>;
    recentTrends: Array<{
      date: string;
      usage: number;
      rating: number;
    }>;
  }> {
    // Get usage metrics
    let metricsQuery = db.select().from(promptUsageMetricsTable);
    if (promptId) {
      metricsQuery = metricsQuery.where(eq(promptUsageMetricsTable.promptId, promptId)) as any;
    }
    const metrics = await metricsQuery;

    // Calculate analytics
    const totalUsage = metrics.length;
    
    const ratingsWithValues = metrics.filter(m => m.userRating !== null).map(m => m.userRating!);
    const averageRating = ratingsWithValues.length > 0 
      ? ratingsWithValues.reduce((sum, rating) => sum + rating, 0) / ratingsWithValues.length 
      : 0;

    const generationTimes = metrics.filter(m => m.generationTime !== null).map(m => parseFloat(m.generationTime!));
    const averageGenerationTime = generationTimes.length > 0
      ? generationTimes.reduce((sum, time) => sum + time, 0) / generationTimes.length
      : 0;

    const successfulMetrics = metrics.filter(m => m.successRate === 'success');
    const successRate = totalUsage > 0 ? (successfulMetrics.length / totalUsage) * 100 : 0;

    const categoryBreakdown = metrics.reduce((acc, metric) => {
      const category = metric.category || 'uncategorized';
      acc[category] = (acc[category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Generate recent trends (last 7 days)
    const recentTrends = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateString = date.toISOString().split('T')[0];
      
      const dayMetrics = metrics.filter(metric => 
        metric.createdAt?.toISOString().split('T')[0] === dateString
      );
      
      const dayRatings = dayMetrics.filter(m => m.userRating !== null).map(m => m.userRating!);
      const avgRating = dayRatings.length > 0 
        ? dayRatings.reduce((sum, rating) => sum + rating, 0) / dayRatings.length 
        : 0;

      recentTrends.push({
        date: dateString,
        usage: dayMetrics.length,
        rating: avgRating,
      });
    }

    return {
      totalUsage,
      averageRating,
      averageGenerationTime,
      successRate,
      categoryBreakdown,
      recentTrends,
    };
  }

  // Simple User Management Database Methods
  async createOrUpdateUser(username: string, fullName?: string): Promise<SimpleUser> {
    // Check if user exists
    const existingUser = await this.getUserByUsername(username);
    
    if (existingUser) {
      // Update last seen
      const [user] = await db
        .update(simpleUsers)
        .set({ lastSeen: new Date(), fullName: fullName || existingUser.fullName })
        .where(eq(simpleUsers.username, username))
        .returning();
      return user;
    } else {
      // Create new user
      const [user] = await db
        .insert(simpleUsers)
        .values({ username, fullName: fullName || null })
        .returning();
      return user;
    }
  }

  async getUserByUsername(username: string): Promise<SimpleUser | undefined> {
    const [user] = await db
      .select()
      .from(simpleUsers)
      .where(eq(simpleUsers.username, username));
    return user || undefined;
  }

  // User-specific content creation methods
  async createChatSessionWithUser(data: InsertChatSessionWithUser): Promise<ChatSessionWithUser> {
    // Ensure user exists
    await this.createOrUpdateUser(data.username);
    
    const [session] = await db
      .insert(chatSessionsWithUser)
      .values(data)
      .returning();
    return session;
  }

  async createPromptWithUser(data: InsertPromptWithUser): Promise<PromptWithUser> {
    // Ensure user exists
    await this.createOrUpdateUser(data.username);
    
    const [prompt] = await db
      .insert(promptsWithUser)
      .values(data)
      .returning();
    return prompt;
  }

  async createThumbnailWithUser(data: InsertThumbnailWithUser): Promise<ThumbnailWithUser> {
    // Ensure user exists
    await this.createOrUpdateUser(data.username);
    
    const [thumbnail] = await db
      .insert(thumbnailsWithUser)
      .values(data)
      .returning();
    return thumbnail;
  }

  async createMentalHealthWithUser(data: InsertMentalHealthWithUser): Promise<MentalHealthWithUser> {
    // Ensure user exists
    await this.createOrUpdateUser(data.username);
    
    const [mentalHealth] = await db
      .insert(mentalHealthWithUser)
      .values(data)
      .returning();
    return mentalHealth;
  }

  // User-specific content retrieval methods
  async getChatSessionsByUser(username: string, limit = 10): Promise<ChatSessionWithUser[]> {
    return await db
      .select()
      .from(chatSessionsWithUser)
      .where(eq(chatSessionsWithUser.username, username))
      .orderBy(desc(chatSessionsWithUser.createdAt))
      .limit(limit);
  }

  async getPromptsByUser(username: string, limit = 10): Promise<PromptWithUser[]> {
    return await db
      .select()
      .from(promptsWithUser)
      .where(eq(promptsWithUser.username, username))
      .orderBy(desc(promptsWithUser.createdAt))
      .limit(limit);
  }

  async getThumbnailsByUser(username: string, limit = 10): Promise<ThumbnailWithUser[]> {
    return await db
      .select()
      .from(thumbnailsWithUser)
      .where(eq(thumbnailsWithUser.username, username))
      .orderBy(desc(thumbnailsWithUser.createdAt))
      .limit(limit);
  }

  async getMentalHealthByUser(username: string, limit = 10): Promise<MentalHealthWithUser[]> {
    return await db
      .select()
      .from(mentalHealthWithUser)
      .where(eq(mentalHealthWithUser.username, username))
      .orderBy(desc(mentalHealthWithUser.createdAt))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
