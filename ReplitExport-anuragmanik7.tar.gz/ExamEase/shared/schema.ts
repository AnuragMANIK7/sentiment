import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, integer, decimal, boolean, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const chatSessions = pgTable("chat_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messages: jsonb("messages").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const prompts = pgTable("prompts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  category: text("category").notNull(),
  targetAudience: text("target_audience"),
  contentTopic: text("content_topic"),
  requirements: text("requirements"),
  tone: text("tone"),
  outputLength: text("output_length"),
  generatedPrompt: text("generated_prompt").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const thumbnails = pgTable("thumbnails", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoTitle: text("video_title").notNull(),
  contentCategory: text("content_category"),
  style: text("style"),
  textOverlay: text("text_overlay"),
  colorScheme: text("color_scheme"),
  elements: jsonb("elements"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

// Mental Health Analysis Tables
export const mentalHealthSessions = pgTable("mental_health_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentName: text("student_name").notNull(),
  sessionType: text("session_type").notNull(), // 'video_interview', 'text_quiz', 'combined'
  videoUrl: text("video_url"),
  audioTranscript: text("audio_transcript"),
  textResponses: jsonb("text_responses"), // Quiz answers and reflections
  emotionAnalysis: jsonb("emotion_analysis"), // Facial emotion detection results
  sentimentAnalysis: jsonb("sentiment_analysis"), // Text sentiment analysis
  riskScore: decimal("risk_score", { precision: 5, scale: 2 }), // Overall risk score 0-100
  recommendations: jsonb("recommendations"), // AI-generated recommendations
  alertLevel: text("alert_level"), // 'low', 'medium', 'high', 'critical'
  flaggedForReview: boolean("flagged_for_review").default(false),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const emotionDetections = pgTable("emotion_detections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").references(() => mentalHealthSessions.id),
  timestamp: decimal("timestamp", { precision: 10, scale: 3 }), // Video timestamp in seconds
  emotions: jsonb("emotions"), // {'happy': 0.1, 'sad': 0.7, 'angry': 0.1, 'neutral': 0.1}
  dominantEmotion: text("dominant_emotion"),
  confidence: decimal("confidence", { precision: 5, scale: 4 }), // 0-1 confidence score
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const mentalHealthReports = pgTable("mental_health_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentName: text("student_name").notNull(),
  reportPeriod: text("report_period"), // 'weekly', 'monthly', 'quarterly'
  averageRiskScore: decimal("average_risk_score", { precision: 5, scale: 2 }),
  trendAnalysis: jsonb("trend_analysis"), // Improvement/decline trends
  sessionCount: integer("session_count"),
  recommendedActions: jsonb("recommended_actions"),
  generatedAt: timestamp("generated_at").default(sql`now()`),
});

// Advanced Health Analysis Tables (ECIR 2024 Research Based)
export const advancedHealthSessions = pgTable("advanced_health_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentName: text("student_name").notNull(),
  sessionType: text("session_type").default('comprehensive'), // 'comprehensive', 'brief', 'followup'
  videoUrl: text("video_url"),
  videoBase64: text("video_base64"), // Store video data temporarily for analysis
  
  // Multimodal Features (ECIR 2024 methodology)
  audioEmbeddings: jsonb("audio_embeddings"), // Speech pattern embeddings
  facialEmbeddings: jsonb("facial_embeddings"), // Facial expression embeddings
  landmarks: jsonb("landmarks"), // Facial, body, hand landmarks
  gazeData: jsonb("gaze_data"), // Eye contact, gaze direction, blink patterns
  temporalFeatures: jsonb("temporal_features"), // Sequence alignment data
  
  // Analysis Results
  depressionRiskScore: decimal("depression_risk_score", { precision: 5, scale: 2 }), // 0-100
  severityLevel: text("severity_level"), // minimal/mild/moderate/severe/very_severe
  confidence: decimal("confidence", { precision: 5, scale: 4 }), // 0-1 confidence score
  modalityScores: jsonb("modality_scores"), // Individual scores for audio, facial, behavioral, temporal
  
  // Clinical Indicators
  clinicalIndicators: jsonb("clinical_indicators"), // Speech, facial, behavioral, temporal patterns
  riskFactors: jsonb("risk_factors"), // Identified risk factors
  protectiveFactors: jsonb("protective_factors"), // Identified protective factors
  interventionRecommendations: jsonb("intervention_recommendations"), // AI recommendations
  monitoringNeeds: jsonb("monitoring_needs"), // Follow-up requirements
  
  // Research Findings
  researchFindings: jsonb("research_findings"), // Non-verbal cues, confidence metrics
  
  // Metadata
  researchMethodology: text("research_methodology").default('Reading Between the Frames (ECIR 2024)'),
  flaggedForProfessionalReview: boolean("flagged_for_professional_review").default(false),
  processingTimeMs: integer("processing_time_ms"), // Analysis processing time
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`),
});

export const advancedHealthReports = pgTable("advanced_health_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentName: text("student_name").notNull(),
  reportType: text("report_type").default('comprehensive'), // 'comprehensive', 'trend', 'summary'
  dateRange: jsonb("date_range"), // Start and end dates for report
  
  // Aggregated Data
  totalSessions: integer("total_sessions"),
  averageRiskScore: decimal("average_risk_score", { precision: 5, scale: 2 }),
  riskTrend: text("risk_trend"), // 'improving', 'stable', 'declining', 'concerning'
  modalityTrends: jsonb("modality_trends"), // Trends for each modality
  
  // Summary Analysis
  keyFindings: jsonb("key_findings"), // Major patterns and concerns
  progressIndicators: jsonb("progress_indicators"), // Positive changes
  alertIndicators: jsonb("alert_indicators"), // Concerning patterns
  recommendedActions: jsonb("recommended_actions"), // Professional recommendations
  
  // Report Metadata
  generatedBy: text("generated_by").default('AI System'),
  reportPeriod: text("report_period"), // 'weekly', 'monthly', 'quarterly', 'annual'
  exportFormat: text("export_format").default('comprehensive'), // 'summary', 'detailed', 'comprehensive'
  
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const insertChatSessionSchema = createInsertSchema(chatSessions).pick({
  messages: true,
});

export const insertPromptSchema = createInsertSchema(prompts).pick({
  category: true,
  targetAudience: true,
  contentTopic: true,
  requirements: true,
  tone: true,
  outputLength: true,
});

export const insertThumbnailSchema = createInsertSchema(thumbnails).pick({
  videoTitle: true,
  contentCategory: true,
  style: true,
  textOverlay: true,
  colorScheme: true,
  elements: true,
  imageUrl: true,
});

// Mental Health Insert Schemas
export const insertMentalHealthSessionSchema = createInsertSchema(mentalHealthSessions).pick({
  studentName: true,
  sessionType: true,
  videoUrl: true,
  audioTranscript: true,
  textResponses: true,
});

export const insertEmotionDetectionSchema = createInsertSchema(emotionDetections).pick({
  sessionId: true,
  timestamp: true,
  emotions: true,
  dominantEmotion: true,
  confidence: true,
});

export const insertAdvancedHealthSessionSchema = createInsertSchema(advancedHealthSessions).pick({
  studentName: true,
  sessionType: true,
  videoUrl: true,
  videoBase64: true,
  audioEmbeddings: true,
  facialEmbeddings: true,
  landmarks: true,
  gazeData: true,
  temporalFeatures: true,
  depressionRiskScore: true,
  severityLevel: true,
  confidence: true,
  modalityScores: true,
  clinicalIndicators: true,
  riskFactors: true,
  protectiveFactors: true,
  interventionRecommendations: true,
  monitoringNeeds: true,
  researchFindings: true,
  flaggedForProfessionalReview: true,
  processingTimeMs: true,
});

export const insertAdvancedHealthReportSchema = createInsertSchema(advancedHealthReports).pick({
  studentName: true,
  reportType: true,
  dateRange: true,
  totalSessions: true,
  averageRiskScore: true,
  riskTrend: true,
  modalityTrends: true,
  keyFindings: true,
  progressIndicators: true,
  alertIndicators: true,
  recommendedActions: true,
  reportPeriod: true,
  exportFormat: true,
});

export type InsertChatSession = z.infer<typeof insertChatSessionSchema>;
export type InsertPrompt = z.infer<typeof insertPromptSchema>;
export type InsertThumbnail = z.infer<typeof insertThumbnailSchema>;
export type InsertMentalHealthSession = z.infer<typeof insertMentalHealthSessionSchema>;
export type InsertEmotionDetection = z.infer<typeof insertEmotionDetectionSchema>;
export type InsertAdvancedHealthSession = z.infer<typeof insertAdvancedHealthSessionSchema>;
export type InsertAdvancedHealthReport = z.infer<typeof insertAdvancedHealthReportSchema>;

// Prompt Performance Analytics Tables
export const promptUsageMetrics = pgTable("prompt_usage_metrics", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  promptId: text("prompt_id").references(() => prompts.id),
  sessionId: text("session_id"), // Anonymous session tracking
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  generationTime: text("generation_time"), // Time taken to generate in ms
  promptLength: integer("prompt_length"),
  outputLength: integer("output_length"),
  category: text("category"), // "youtube_analysis", "seo_optimization", etc.
  successRate: text("success_rate"), // "success", "partial", "failed"
  userRating: integer("user_rating"), // 1-5 star rating from user
  usageContext: jsonb("usage_context"), // Additional context data
  createdAt: timestamp("created_at").defaultNow(),
});

export const promptPerformanceAnalytics = pgTable("prompt_performance_analytics", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  promptId: text("prompt_id").references(() => prompts.id),
  totalUsage: integer("total_usage").default(0),
  averageRating: text("average_rating").default("0"),
  averageGenerationTime: text("average_generation_time").default("0"),
  successRate: text("success_rate").default("0"),
  categoryPerformance: jsonb("category_performance"),
  trendsData: jsonb("trends_data"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const promptFeedback = pgTable("prompt_feedback", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  promptId: text("prompt_id").references(() => prompts.id),
  sessionId: text("session_id"),
  rating: integer("rating").notNull(), // 1-5 stars
  feedback: text("feedback"), // Optional text feedback
  useCase: text("use_case"), // How they used the prompt
  effectiveness: text("effectiveness"), // "very_effective", "effective", "somewhat_effective", "not_effective"
  improvementSuggestions: text("improvement_suggestions"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas for analytics
export const insertPromptUsageMetricSchema = createInsertSchema(promptUsageMetrics).pick({
  promptId: true,
  sessionId: true,
  ipAddress: true,
  userAgent: true,
  generationTime: true,
  promptLength: true,
  outputLength: true,
  category: true,
  successRate: true,
  userRating: true,
  usageContext: true,
});

export const insertPromptFeedbackSchema = createInsertSchema(promptFeedback).pick({
  promptId: true,
  sessionId: true,
  rating: true,
  feedback: true,
  useCase: true,
  effectiveness: true,
  improvementSuggestions: true,
});

export type ChatSession = typeof chatSessions.$inferSelect;
export type Prompt = typeof prompts.$inferSelect;
export type Thumbnail = typeof thumbnails.$inferSelect;
export type MentalHealthSession = typeof mentalHealthSessions.$inferSelect;
export type EmotionDetection = typeof emotionDetections.$inferSelect;
export type MentalHealthReport = typeof mentalHealthReports.$inferSelect;
export type AdvancedHealthSession = typeof advancedHealthSessions.$inferSelect;
export type AdvancedHealthReport = typeof advancedHealthReports.$inferSelect;

export type PromptUsageMetric = typeof promptUsageMetrics.$inferSelect;
export type InsertPromptUsageMetric = typeof promptUsageMetrics.$inferInsert;
export type PromptPerformanceAnalytic = typeof promptPerformanceAnalytics.$inferSelect;
export type InsertPromptPerformanceAnalytic = typeof promptPerformanceAnalytics.$inferInsert;
export type PromptFeedback = typeof promptFeedback.$inferSelect;
export type InsertPromptFeedback = typeof promptFeedback.$inferInsert;

// Simple User Management - just username tracking
export const simpleUsers = pgTable("simple_users", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").unique().notNull(),
  fullName: varchar("full_name"),
  createdAt: timestamp("created_at").defaultNow(),
  lastSeen: timestamp("last_seen").defaultNow(),
});

// Update existing tables to include username references
export const chatSessionsWithUser = pgTable("chat_sessions_with_user", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").notNull(),
  messages: jsonb("messages").notNull(),
  title: text("title"), // Auto-generated from first message
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const promptsWithUser = pgTable("prompts_with_user", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").notNull(),
  category: text("category").notNull(),
  targetAudience: text("target_audience"),
  contentTopic: text("content_topic"),
  requirements: text("requirements"),
  tone: text("tone"),
  outputLength: text("output_length"),
  generatedPrompt: text("generated_prompt").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const thumbnailsWithUser = pgTable("thumbnails_with_user", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  style: text("style"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const mentalHealthWithUser = pgTable("mental_health_with_user", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").notNull(),
  sessionType: text("session_type").notNull(), // "chat", "video_interview", "assessment"
  data: jsonb("data").notNull(), // Session data, analysis results, etc.
  riskScore: text("risk_score"),
  alertLevel: text("alert_level"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Simple insert schemas
export const insertSimpleUserSchema = createInsertSchema(simpleUsers).pick({
  username: true,
  fullName: true,
});

export const insertChatSessionWithUserSchema = createInsertSchema(chatSessionsWithUser).pick({
  username: true,
  messages: true,
  title: true,
});

export const insertPromptWithUserSchema = createInsertSchema(promptsWithUser).pick({
  username: true,
  category: true,
  targetAudience: true,
  contentTopic: true,
  requirements: true,
  tone: true,
  outputLength: true,
  generatedPrompt: true,
});

export const insertThumbnailWithUserSchema = createInsertSchema(thumbnailsWithUser).pick({
  username: true,
  title: true,
  description: true,
  style: true,
  imageUrl: true,
});

export const insertMentalHealthWithUserSchema = createInsertSchema(mentalHealthWithUser).pick({
  username: true,
  sessionType: true,
  data: true,
  riskScore: true,
  alertLevel: true,
});

export type SimpleUser = typeof simpleUsers.$inferSelect;
export type InsertSimpleUser = typeof simpleUsers.$inferInsert;
export type ChatSessionWithUser = typeof chatSessionsWithUser.$inferSelect;
export type PromptWithUser = typeof promptsWithUser.$inferSelect;
export type ThumbnailWithUser = typeof thumbnailsWithUser.$inferSelect;
export type MentalHealthWithUser = typeof mentalHealthWithUser.$inferSelect;

// Facial Analysis Quiz Tables
export const facialQuizSessions = pgTable("facial_quiz_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentName: varchar("student_name").notNull(),
  username: varchar("username"),
  subject: varchar("subject").notNull(), // GS-I, GS-II, GS-III, GS-IV
  difficulty: varchar("difficulty").notNull(), // easy, medium, hard
  totalQuestions: integer("total_questions").notNull(),
  currentQuestion: integer("current_question").default(1),
  score: integer("score").default(0),
  timeLimit: integer("time_limit").notNull(), // in minutes
  adaptiveMode: boolean("adaptive_mode").default(true),
  startTime: timestamp("start_time").defaultNow(),
  endTime: timestamp("end_time"),
  status: varchar("status").default("in_progress"), // in_progress, completed, abandoned
  adaptiveAdjustments: jsonb("adaptive_adjustments").default({}), // difficulty changes, alerts, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const facialQuizQuestions = pgTable("facial_quiz_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().references(() => facialQuizSessions.id),
  questionId: varchar("question_id").notNull(), // from question database or AI-generated
  question: text("question").notNull(),
  options: jsonb("options").notNull(), // array of options
  correctAnswer: integer("correct_answer").notNull(),
  explanation: text("explanation").notNull(),
  difficulty: varchar("difficulty").notNull(),
  subject: varchar("subject").notNull(),
  topic: varchar("topic"),
  year: integer("year"),
  marks: integer("marks").default(2),
  userAnswer: integer("user_answer"),
  isCorrect: boolean("is_correct"),
  timeSpent: integer("time_spent"), // in seconds
  attentionScore: real("attention_score"), // 0-1 scale
  drowsinessLevel: real("drowsiness_level"), // 0-1 scale
  answeredAt: timestamp("answered_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const facialAttentionMetrics = pgTable("facial_attention_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().references(() => facialQuizSessions.id),
  questionId: varchar("question_id").references(() => facialQuizQuestions.id),
  timestamp: timestamp("timestamp").defaultNow(),
  attentionScore: real("attention_score").notNull(), // 0-1 scale
  drowsinessLevel: real("drowsiness_level").notNull(), // 0-1 scale
  emotion: varchar("emotion").notNull(),
  confidence: real("confidence").notNull(),
  blinkRate: real("blink_rate"),
  headPoseYaw: real("head_pose_yaw"),
  headPosePitch: real("head_pose_pitch"),
  headPoseRoll: real("head_pose_roll"),
  eyeOpenness: real("eye_openness"),
  faceDetected: boolean("face_detected").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const facialAttentionAlerts = pgTable("facial_attention_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().references(() => facialQuizSessions.id),
  type: varchar("type").notNull(), // low_attention, drowsiness, distraction, good_focus
  message: text("message").notNull(),
  severity: varchar("severity").notNull(), // low, medium, high
  timestamp: timestamp("timestamp").defaultNow(),
  acknowledged: boolean("acknowledged").default(false),
});

export const facialQuizAnalytics = pgTable("facial_quiz_analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().references(() => facialQuizSessions.id),
  username: varchar("username"),
  subject: varchar("subject").notNull(),
  finalScore: integer("final_score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  accuracy: real("accuracy").notNull(), // percentage
  averageAttention: real("average_attention").notNull(),
  averageDrowsiness: real("average_drowsiness").notNull(),
  attentionAlerts: integer("attention_alerts").default(0),
  difficultyAdjustments: integer("difficulty_adjustments").default(0),
  completionTime: integer("completion_time"), // in minutes
  recommendedBreaks: integer("recommended_breaks").default(0),
  studyRecommendations: jsonb("study_recommendations"),
  performanceInsights: jsonb("performance_insights"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas for facial analysis quiz
export const insertFacialQuizSessionSchema = createInsertSchema(facialQuizSessions).pick({
  studentName: true,
  username: true,
  subject: true,
  difficulty: true,
  totalQuestions: true,
  timeLimit: true,
  adaptiveMode: true,
});

export const insertFacialAttentionMetricSchema = createInsertSchema(facialAttentionMetrics).omit({
  id: true,
  timestamp: true,
  createdAt: true,
});

// Types for facial analysis quiz
export type FacialQuizSession = typeof facialQuizSessions.$inferSelect;
export type InsertFacialQuizSession = z.infer<typeof insertFacialQuizSessionSchema>;

export type FacialQuizQuestion = typeof facialQuizQuestions.$inferSelect;
export type FacialAttentionMetric = typeof facialAttentionMetrics.$inferSelect;
export type InsertFacialAttentionMetric = z.infer<typeof insertFacialAttentionMetricSchema>;

export type FacialAttentionAlert = typeof facialAttentionAlerts.$inferSelect;
export type FacialQuizAnalytic = typeof facialQuizAnalytics.$inferSelect;
