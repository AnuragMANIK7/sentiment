# UPSC AI Tools

## Overview

This is a comprehensive full-stack web application designed specifically for UPSC (Union Public Service Commission) aspirants. It provides four main AI-powered tools: a Mental Health Coach for stress management and study planning, an advanced Mental Health Analysis module with video interviews and facial expression detection, a Prompt Generator for content creation, and a Thumbnail Creator for educational videos. The application uses a modern tech stack with React frontend, Express backend, and PostgreSQL database, all designed to support the unique challenges faced by competitive exam candidates.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client, server, and shared components:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js with TypeScript running on Node.js
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **AI Integration**: OpenAI API for chat responses and prompt generation, Gradio client for image generation

## Key Components

### Frontend Architecture
- **Component Library**: Built on shadcn/ui with Radix UI primitives for accessibility
- **Styling System**: Tailwind CSS with custom design tokens and dark mode support
- **Form Handling**: React Hook Form with Zod validation
- **API Communication**: Custom query client wrapper around TanStack Query
- **Layout**: Responsive design with mobile-first approach

### Backend Architecture
- **API Structure**: RESTful endpoints organized by feature (chat, prompts, thumbnails)
- **Middleware**: Express middleware for JSON parsing, logging, and error handling
- **Services**: Separated business logic for OpenAI integration and thumbnail generation
- **Storage**: Abstracted storage interface with in-memory implementation (easily swappable with database)

### Database Schema
- **Chat Sessions**: Stores conversation history with JSON messages
- **Prompts**: Stores generated prompts with categorization and metadata
- **Thumbnails**: Stores thumbnail generation requests and resulting image URLs
- **Schema Management**: Drizzle Kit for migrations and type generation

## Data Flow

1. **Client Requests**: Frontend makes API calls through the query client
2. **API Processing**: Express routes handle requests and delegate to service layers
3. **AI Integration**: Services communicate with OpenAI API and Gradio endpoints
4. **Data Persistence**: Results are stored in PostgreSQL via Drizzle ORM
5. **Response**: Processed data is returned to the client and cached via TanStack Query

## External Dependencies

### AI Services
- **OpenAI API**: Powers all three AI features using GPT-4.1-nano model for optimal cost efficiency
- **Gradio Client**: Handles thumbnail image generation via Stable Diffusion models  
- **Fallback Systems**: Placeholder services for when external APIs are unavailable

### Development Tools
- **Vite**: Fast development server and build tool with HMR
- **TypeScript**: Type safety across the entire application
- **ESBuild**: Fast bundling for production builds
- **Replit Integration**: Special development mode for Replit environment

### UI and Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling with custom design system
- **Lucide Icons**: Consistent icon library
- **Custom Themes**: Light and dark mode support with CSS variables

## Deployment Strategy

### Development Environment
- **Hot Module Replacement**: Vite provides instant feedback during development
- **TypeScript Checking**: Continuous type checking without blocking builds
- **Development Middleware**: Custom logging and error overlay for debugging

### Production Build
- **Frontend**: Vite builds optimized static assets
- **Backend**: ESBuild bundles server code for Node.js deployment
- **Asset Serving**: Express serves static files in production
- **Environment Variables**: Separate configuration for database and API keys

### Database Management
- **Migrations**: Drizzle Kit handles schema changes
- **Connection**: Uses connection pooling via Neon serverless driver
- **Type Safety**: Generated types ensure database queries are type-safe

The application is designed to be easily deployable on platforms like Replit, Vercel, or any Node.js hosting service, with minimal configuration required for different environments.

## Recent Changes

### July 27, 2025 - Aspirants Repository Integration
- **Integrated aayushpagare21-compcoder/aspirants Repository**: Enhanced learning style assessment with AI-powered UPSC study recommendations
  - Created comprehensive aspirants methodology service with RAG-inspired approach  
  - Added 40+ personalized UPSC learning resources categorized by learning styles (visual, auditory, kinesthetic, social)
  - Implemented AI-powered study plan generation with TTT methodology (Text-books, Test-series, Techniques)
  - Added adaptive learning features with performance tracking and optimization suggestions
  - Enhanced My Insights tab with personalized resource recommendations based on learning assessment results
  - Integrated comprehensive resource database with ratings, difficulty levels, and learning style compatibility
  - Added API endpoint for real-time personalized resource generation
  - Enhanced study plans with phase-wise preparation, milestone tracking, and adaptive content recommendations
  - Implemented multi-modal learning approach with emphasis on dominant learning style
- **Advanced Resource Categorization**: Resources now include AI Study Planner, Smart Revision Assistant, Interactive Quiz Platform
- **Performance Analytics Integration**: AI-powered tracking of learning efficiency and adaptive recommendations
- **Enhanced UI Components**: Beautiful resource cards with ratings, difficulty badges, and external link integration

### July 26, 2025 - Facial Analysis Quiz Implementation
- **Implemented Advanced Prompt Analytics System**: Comprehensive performance tracking and optimization
  - Real-time usage metrics collection with generation time, success rates, and user ratings
  - Interactive analytics dashboard with charts for trends, categories, and performance metrics
  - User feedback system with ratings, effectiveness tracking, and improvement suggestions
  - Database schema extended with promptUsageMetrics, promptPerformanceAnalytics, and promptFeedback tables
  - API endpoints for analytics data retrieval and feedback submission
  - Advanced visualization using Recharts for performance insights
- **Added Mental Health Analysis Module**: Comprehensive multimodal mental health monitoring system
  - Video interview recording with facial expression analysis
  - Text-based psychological assessment questionnaires
  - Real-time emotion detection and sentiment analysis
  - Risk scoring and alert level classification (low/medium/high/critical)
  - Student-specific tracking and professional flagging system
  - Analytics dashboard with trend analysis and distribution metrics
- **Simplified Authentication System**: Implemented username-only authentication for demo purposes
  - Created simple username input component with localStorage persistence
  - Database schema simplified with simpleUsers table and username-based content storage
  - Chat sessions, prompts, thumbnails, and mental health data now saved with username
  - Backwards compatibility maintained for content without usernames
  - User history retrieval endpoints by username implemented
  - All forms now include optional username input for content saving
- **Database Enhancement**: Extended PostgreSQL schema for comprehensive analytics and user management
  - Mental health sessions table with emotion analysis storage
  - Individual emotion detection tracking with timestamps
  - Prompt usage metrics with performance tracking
  - User feedback collection and analytics aggregation
  - Username-based content tables for simplified user management
- **Navigation Updates**: Added Prompt Analytics to main navigation menu
- **Fixed Prompt Generator**: Resolved schema validation errors preventing prompt generation
- **Updated AI Model**: Switched to GPT-4.1-nano for all features (fastest, most cost-effective OpenAI model)
- **Enhanced Thumbnail System**: Implemented robust fallback system with multiple AI endpoints
  - Added FLUX.1-schnell and XLabs-AI models for better reliability
  - Implemented intelligent endpoint rotation to handle GPU quota limits
  - Enhanced fallback system for when AI services are unavailable
- **Completed Core Features**: All five main functionalities are working:
  - Mental Health Coach with real-time chat interface and username-based history
  - Advanced Mental Health Analysis with video interviews, facial expression detection, and comprehensive monitoring
  - Advanced Prompt Generator for YouTube content optimization with user history
  - Prompt Analytics with performance tracking and user feedback
  - AI Thumbnail Creator with customizable options and improved reliability
- **Database Integration**: Successfully integrated PostgreSQL for all data storage including analytics
- **Demo-Ready**: App works as a fully functional demo with optional username-based content saving
- **Learning Style Assessment**: Integrated comprehensive learning style quiz
  - 8-question learning style quiz identifying visual, auditory, kinesthetic, or social learning preferences
  - UPSC-specific study techniques and recommendations based on assessment results
  - Personal insights dashboard showing learning profile and study recommendations
  - All assessment results saved with username for tracking progress over time
- **Facial Analysis Quiz Module**: Advanced AI-powered quiz system with real-time attention monitoring
  - Real-time facial expression analysis using OpenAI Vision API for attention and drowsiness detection
  - Adaptive UPSC question generation based on student performance and focus levels
  - Camera-based monitoring with live metrics display (attention score, drowsiness level, emotion detection)
  - Interactive quiz interface with personalized difficulty adjustment
  - Integration of three GitHub repositories concepts:
    * Facial-Emotion-Recognition-using-OpenCV-and-Deepface for emotion detection algorithms
    * MLH-Quizzet for NLP-based adaptive quiz generation techniques
    * UPSC-Star for authentic UPSC question database patterns (2013-present)
  - Comprehensive performance analytics combining quiz scores with attention metrics
  - Alert system for drowsiness and attention drops with personalized recommendations
  - Database schema with facial_quiz_sessions, facial_quiz_questions, facial_attention_metrics, and facial_attention_alerts tables
- **Advanced PDF Report Generation**: Comprehensive reporting system for mental health analysis
  - Python-based PDF generation using pandas, matplotlib, and reportlab libraries
  - Professional reports with visualizations, risk assessments, and clinical indicators
  - Automated chart generation including risk distribution and modality score breakdowns
  - Detailed clinical documentation with intervention recommendations and monitoring needs
  - Downloadable PDF reports with proper formatting and research-based insights
  - Integration with Advanced Health Analysis for seamless report generation