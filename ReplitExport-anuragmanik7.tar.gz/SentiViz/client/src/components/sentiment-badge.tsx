import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface SentimentBadgeProps {
  sentiment: "positive" | "negative" | "neutral";
  score?: number;
  showIcon?: boolean;
}

export function SentimentBadge({ sentiment, score, showIcon = true }: SentimentBadgeProps) {
  const config = {
    positive: {
      label: "Positive",
      className: "bg-green-100 text-green-800 dark:bg-green-950/30 dark:text-green-400",
      icon: TrendingUp,
    },
    negative: {
      label: "Negative",
      className: "bg-red-100 text-red-800 dark:bg-red-950/30 dark:text-red-400",
      icon: TrendingDown,
    },
    neutral: {
      label: "Neutral",
      className: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300",
      icon: Minus,
    },
  };

  const { label, className, icon: Icon } = config[sentiment];

  return (
    <Badge className={className} data-testid={`badge-sentiment-${sentiment}`}>
      {showIcon && <Icon className="h-3 w-3 mr-1" />}
      {label}
      {score !== undefined && ` (${score})`}
    </Badge>
  );
}
