import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

interface SentimentChartProps {
  positive: number;
  negative: number;
  neutral: number;
  title?: string;
}

const COLORS = {
  positive: '#22c55e',
  negative: '#ef4444',
  neutral: '#9ca3af',
};

export function SentimentChart({ positive, negative, neutral, title = "Sentiment Distribution" }: SentimentChartProps) {
  const data = [
    { name: 'Positive', value: positive, color: COLORS.positive },
    { name: 'Negative', value: negative, color: COLORS.negative },
    { name: 'Neutral', value: neutral, color: COLORS.neutral },
  ];

  return (
    <Card data-testid="chart-sentiment-distribution">
      <CardHeader>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
