import { useMemo } from "react";

interface WordData {
  text: string;
  value: number;
}

interface WordCloudProps {
  words: WordData[];
  width?: number;
  height?: number;
}

export function WordCloud({ words, width = 600, height = 400 }: WordCloudProps) {
  const renderWords = useMemo(() => {
    if (!words || words.length === 0) return [];

    const maxValue = Math.max(...words.map(w => w.value));
    const minValue = Math.min(...words.map(w => w.value));
    const range = maxValue - minValue;
    
    return words.map((word, index) => {
      // Handle case where all values are the same (avoid divide by zero)
      const normalizedSize = range === 0 ? 0.5 : (word.value - minValue) / range;
      const fontSize = 12 + normalizedSize * 32;
      const opacity = 0.4 + normalizedSize * 0.6;
      
      const colors = [
        'text-blue-400',
        'text-cyan-400', 
        'text-teal-400',
        'text-green-400',
        'text-purple-400',
        'text-pink-400',
        'text-indigo-400'
      ];
      const colorClass = colors[index % colors.length];

      return {
        ...word,
        fontSize,
        opacity,
        colorClass,
        rotation: (Math.random() - 0.5) * 15,
      };
    });
  }, [words]);

  return (
    <div 
      className="relative flex flex-wrap items-center justify-center gap-2 p-4 overflow-hidden"
      style={{ width, height }}
      data-testid="wordcloud-container"
    >
      {renderWords.map((word, index) => (
        <span
          key={`${word.text}-${index}`}
          className={`inline-block transition-all hover:scale-110 cursor-default ${word.colorClass}`}
          style={{
            fontSize: `${word.fontSize}px`,
            opacity: word.opacity,
            transform: `rotate(${word.rotation}deg)`,
            fontWeight: Math.floor(300 + word.value / Math.max(...words.map(w => w.value)) * 400),
            lineHeight: 1.2,
          }}
          data-testid={`word-${word.text}`}
          title={`${word.text}: ${word.value} mentions`}
        >
          {word.text}
        </span>
      ))}
    </div>
  );
}
