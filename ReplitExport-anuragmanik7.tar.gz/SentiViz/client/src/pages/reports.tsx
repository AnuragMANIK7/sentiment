import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Presentation, Download, Loader2, FileText, TrendingUp, BarChart3, Eye } from "lucide-react";
import type { Presentation as PresentationType } from "@shared/schema";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function ReportsPage() {
  const [presentationTitle, setPresentationTitle] = useState("Quarterly Sentiment Analysis Report");
  const [selectedPresentation, setSelectedPresentation] = useState<PresentationType | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: presentations, isLoading } = useQuery<PresentationType[]>({
    queryKey: ['/api/presentations'],
  });

  const generateMutation = useMutation({
    mutationFn: async (title: string) => {
      return apiRequest('POST', '/api/presentations', { title });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/presentations'] });
      toast({
        title: "Presentation generated",
        description: "Your stakeholder report is ready to download.",
      });
      setPresentationTitle("Quarterly Sentiment Analysis Report");
    },
    onError: (error: Error) => {
      toast({
        title: "Generation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (presentationTitle.trim()) {
      generateMutation.mutate(presentationTitle);
    }
  };

  const handlePreview = (presentation: PresentationType) => {
    setSelectedPresentation(presentation);
    setPreviewOpen(true);
  };

  const slides = selectedPresentation 
    ? (Array.isArray(JSON.parse(selectedPresentation.slides)) 
        ? JSON.parse(selectedPresentation.slides).map((slide: any) => ({
            ...slide,
            content: slide.content || slide.bullets || [] // Handle both content and bullets
          }))
        : [])
    : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-reports-title">Presentation Generator</h1>
        <p className="text-muted-foreground mt-1">Create professional stakeholder reports in seconds</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Generate New Presentation</CardTitle>
              <CardDescription>
                Create a 5-slide presentation with key sentiment insights and competitive analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Presentation Title</Label>
                <Input
                  id="title"
                  placeholder="Enter presentation title..."
                  value={presentationTitle}
                  onChange={(e) => setPresentationTitle(e.target.value)}
                  data-testid="input-presentation-title"
                />
              </div>

              <div className="p-4 rounded-lg bg-muted space-y-3">
                <p className="font-medium text-sm">Your presentation will include:</p>
                <div className="grid gap-2">
                  <div className="flex items-center gap-2 text-sm">
                    <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center text-primary font-bold">1</div>
                    <span>Executive Summary - Overall sentiment score and key metrics</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center text-primary font-bold">2</div>
                    <span>Sentiment Distribution - Positive, negative, and neutral breakdown</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center text-primary font-bold">3</div>
                    <span>Competitive Analysis - Samsung Galaxy vs iPhone 17 comparison</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center text-primary font-bold">4</div>
                    <span>Key Insights - Best reviews and areas of concern</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center text-primary font-bold">5</div>
                    <span>Action Items - Recommended next steps and priorities</span>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={!presentationTitle.trim() || generateMutation.isPending}
                className="w-full"
                size="lg"
                data-testid="button-generate-presentation"
              >
                {generateMutation.isPending ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Presentation className="h-5 w-5 mr-2" />
                    Generate Presentation
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Presentations</CardTitle>
              <CardDescription>Previously generated stakeholder reports</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : presentations && presentations.length > 0 ? (
                <div className="space-y-4">
                  {presentations.map((presentation, idx) => (
                    <div
                      key={presentation.id}
                      className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                      data-testid={`presentation-item-${idx}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="p-3 rounded-lg bg-primary/10">
                          <FileText className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{presentation.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(presentation.createdAt), 'MMM d, yyyy • h:mm a')}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handlePreview(presentation)}
                          data-testid={`button-preview-${idx}`}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Preview
                        </Button>
                        <Button size="sm" data-testid={`button-download-${idx}`}>
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="flex justify-center mb-4">
                    <div className="p-4 rounded-full bg-muted">
                      <Presentation className="h-10 w-10 text-muted-foreground" />
                    </div>
                  </div>
                  <p className="text-lg font-medium">No presentations yet</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Generate your first presentation to get started
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Export Options</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start" data-testid="button-export-pdf">
                <FileText className="h-4 w-4 mr-2" />
                Export as PDF
              </Button>
              <Button variant="outline" className="w-full justify-start" data-testid="button-export-pptx">
                <Presentation className="h-4 w-4 mr-2" />
                Export as PowerPoint
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Overall Sentiment</span>
                </div>
                <Badge className="bg-green-100 text-green-800 dark:bg-green-950/30 dark:text-green-400">75/100</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-primary" />
                  <span className="text-sm">Total Reviews</span>
                </div>
                <Badge variant="secondary">3,600</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Presentation className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Reports Generated</span>
                </div>
                <Badge variant="secondary">{presentations?.length || 0}</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedPresentation?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {slides.map((slide: any, idx: number) => (
              <Card key={idx} data-testid={`slide-preview-${idx}`}>
                <CardHeader className="bg-primary/5">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded bg-primary flex items-center justify-center text-primary-foreground font-bold">
                      {idx + 1}
                    </div>
                    <CardTitle className="text-lg">{slide.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="space-y-2">
                    {(slide.content || []).map((item: string, i: number) => (
                      <p key={i} className="text-sm">• {item}</p>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
