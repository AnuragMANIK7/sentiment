import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Youtube, Newspaper, Search, Filter, RefreshCw, Loader2, CalendarIcon } from "lucide-react";
import { SentimentBadge } from "@/components/sentiment-badge";
import { SentimentChart } from "@/components/sentiment-chart";
import type { SocialFeed } from "@shared/schema";
import { format, formatDistanceToNow, subMonths } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { DateRange } from "react-day-picker";

const platformIcons = {
  youtube: Youtube,
  news: Newspaper,
};

const platformColors = {
  youtube: "bg-red-100 text-red-800 dark:bg-red-950/30 dark:text-red-400",
  news: "bg-purple-100 text-purple-800 dark:bg-purple-950/30 dark:text-purple-400",
};

export default function SocialMonitor() {
  const [activePlatform, setActivePlatform] = useState<string>("all");
  const [sentimentFilter, setSentimentFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subMonths(new Date(), 3),
    to: new Date(),
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: feeds, isLoading } = useQuery<SocialFeed[]>({
    queryKey: ['/api/social-feeds', activePlatform, sentimentFilter, dateRange],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (activePlatform !== 'all') params.append('platform', activePlatform);
      if (sentimentFilter !== 'all') params.append('sentiment', sentimentFilter);
      if (dateRange?.from) params.append('from', dateRange.from.toISOString());
      if (dateRange?.to) params.append('to', dateRange.to.toISOString());
      
      const response = await fetch(`/api/social-feeds?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch social feeds');
      return response.json();
    },
  });

  const { data: stats } = useQuery({
    queryKey: ['/api/social-stats'],
  });

  const monitorMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/social-monitor', {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/social-feeds'] });
      queryClient.invalidateQueries({ queryKey: ['/api/social-stats'] });
      toast({
        title: "Feed refreshed",
        description: "Successfully fetched and analyzed latest social media posts.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Refresh failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const filteredFeeds = feeds?.filter(feed => 
    searchQuery === "" || feed.content.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-social-title">Social Monitor</h1>
          <p className="text-muted-foreground mt-1">Monitor YouTube comments and tech news about Samsung Galaxy and iPhone 17 (up to 6 months of data)</p>
        </div>
        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" data-testid="button-date-range">
                <CalendarIcon className="h-4 w-4 mr-2" />
                {dateRange?.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "MMM d")} - {format(dateRange.to, "MMM d, yyyy")}
                    </>
                  ) : (
                    format(dateRange.from, "MMM d, yyyy")
                  )
                ) : (
                  "Select date range"
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange?.from}
                selected={dateRange}
                onSelect={setDateRange}
                numberOfMonths={2}
                disabled={(date) =>
                  date > new Date() || date < subMonths(new Date(), 6)
                }
                data-testid="calendar-date-range"
              />
            </PopoverContent>
          </Popover>
          <Button
            onClick={() => monitorMutation.mutate()}
            disabled={monitorMutation.isPending}
            data-testid="button-refresh-feed"
          >
            {monitorMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Monitoring...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh Feed
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <CardTitle>Social Feed</CardTitle>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search posts..."
                      className="pl-9 w-64"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      data-testid="input-search-posts"
                    />
                  </div>
                  <Select value={sentimentFilter} onValueChange={setSentimentFilter}>
                    <SelectTrigger className="w-32" data-testid="select-sentiment-filter">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="positive">Positive</SelectItem>
                      <SelectItem value="negative">Negative</SelectItem>
                      <SelectItem value="neutral">Neutral</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs value={activePlatform} onValueChange={setActivePlatform}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="all" data-testid="tab-all">All</TabsTrigger>
                  <TabsTrigger value="youtube" data-testid="tab-youtube">
                    <Youtube className="h-4 w-4 mr-2" />
                    YouTube
                  </TabsTrigger>
                  <TabsTrigger value="news" data-testid="tab-news">
                    <Newspaper className="h-4 w-4 mr-2" />
                    News
                  </TabsTrigger>
                </TabsList>

                <div className="mt-6">
                  {isLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
                      ))}
                    </div>
                  ) : filteredFeeds.length > 0 ? (
                    <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                      {filteredFeeds.map((feed, idx) => {
                        const Icon = platformIcons[feed.platform as keyof typeof platformIcons];
                        const platformColor = platformColors[feed.platform as keyof typeof platformColors];
                        
                        // Skip feeds from unsupported platforms (twitter, instagram)
                        if (!Icon || !platformColor) {
                          return null;
                        }
                        
                        return (
                          <div
                            key={feed.id}
                            className="p-4 rounded-lg border hover-elevate"
                            data-testid={`feed-item-${idx}`}
                          >
                            <div className="flex items-start gap-3">
                              <div className={`p-2 rounded-lg ${platformColor}`}>
                                <Icon className="h-4 w-4" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-2">
                                  <p className="font-medium text-sm">{feed.author}</p>
                                  <span className="text-xs text-muted-foreground">
                                    {formatDistanceToNow(new Date(feed.timestamp), { addSuffix: true })}
                                  </span>
                                  {feed.product && (
                                    <Badge variant="outline" className="text-xs">
                                      {feed.product}
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-sm mb-3">{feed.content}</p>
                                <div className="flex items-center gap-3">
                                  <SentimentBadge 
                                    sentiment={feed.sentiment as "positive" | "negative" | "neutral"} 
                                    score={Math.round(feed.sentimentScore)}
                                  />
                                  {feed.engagement && (
                                    <span className="text-xs text-muted-foreground">
                                      {feed.engagement.toLocaleString()} engagements
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="flex justify-center mb-4">
                        <div className="p-4 rounded-full bg-muted">
                          <Search className="h-10 w-10 text-muted-foreground" />
                        </div>
                      </div>
                      <p className="text-lg font-medium">No posts found</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Try adjusting your filters
                      </p>
                    </div>
                  )}
                </div>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <SentimentChart
            positive={stats?.positive || 1250}
            negative={stats?.negative || 340}
            neutral={stats?.neutral || 410}
            title="Platform Sentiment"
          />

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Platform Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { platform: 'youtube', name: 'YouTube', count: stats?.platformCounts?.youtube || 0, icon: Youtube, color: platformColors.youtube },
                { platform: 'news', name: 'News', count: stats?.platformCounts?.news || 0, icon: Newspaper, color: platformColors.news },
              ].map(({ platform, name, count, icon: Icon, color }) => (
                <div key={platform} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${color}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <span className="font-medium">{name}</span>
                  </div>
                  <Badge variant="secondary">{count}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Trending Topics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(stats?.trendingTopics || [
                { tag: '#iPhone17Pro', mentions: 1234 },
                { tag: '#GalaxyS25', mentions: 892 },
                { tag: '#TechReview', mentions: 567 },
              ]).map((topic: { tag: string; mentions: number }) => (
                <div key={topic.tag} className="flex items-center justify-between">
                  <span className="text-sm font-medium text-primary">{topic.tag}</span>
                  <span className="text-xs text-muted-foreground">{topic.mentions} mentions</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
