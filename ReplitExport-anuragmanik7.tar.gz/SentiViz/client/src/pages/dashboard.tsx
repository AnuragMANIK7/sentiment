import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { Smartphone, Youtube, Newspaper, Globe2 } from "lucide-react";
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import type { Review, SocialFeed } from "@shared/schema";
import { WordCloud } from "@/components/WordCloud";
import { useState } from "react";

const COLORS = {
  positive: '#10b981',
  negative: '#ef4444',
  neutral: '#6b7280',
  spotify: '#1db954',
  youtube: '#ff0000',
  news: '#4285f4',
};

interface StatsData {
  positiveCount: number;
  negativeCount: number;
  neutralCount: number;
  totalCount: number;
  positivePercent: number;
  negativePercent: number;
  neutralPercent: number;
  overallScore: number;
}

interface TrendDataPoint {
  date: string;
  positive: number;
  negative: number;
  neutral: number;
}

interface WordData {
  text: string;
  value: number;
}

interface CountryData {
  name: string;
  count: number;
}

export default function Dashboard() {
  const [selectedPlatform, setSelectedPlatform] = useState<string>("all");

  const { data: stats } = useQuery<StatsData>({
    queryKey: ['/api/stats'],
  });

  const { data: trendData } = useQuery<TrendDataPoint[]>({
    queryKey: ['/api/trends'],
  });

  const { data: socialStats } = useQuery({
    queryKey: ['/api/social-stats'],
  });

  const { data: socialFeeds } = useQuery<SocialFeed[]>({
    queryKey: ['/api/social-feeds'],
  });

  const { data: reviews } = useQuery<Review[]>({
    queryKey: ['/api/reviews'],
  });

  const { data: wordCloudData } = useQuery<WordData[]>({
    queryKey: ['/api/analytics/wordcloud'],
  });

  const { data: geoData } = useQuery<CountryData[]>({
    queryKey: ['/api/analytics/geographic'],
  });

  // Filter data based on selected platform
  const filteredSocialFeeds = selectedPlatform === 'all' 
    ? socialFeeds 
    : selectedPlatform === 'reviews'
    ? []
    : socialFeeds?.filter(f => f.platform === selectedPlatform);

  const filteredReviews = selectedPlatform === 'all' || selectedPlatform === 'reviews'
    ? reviews
    : [];

  // Calculate sentiment distribution based on selected platform
  const sentimentDistribution = (() => {
    if (selectedPlatform === 'all') {
      return [
        { name: 'Positive', value: stats?.positiveCount || 0 },
        { name: 'Negative', value: stats?.negativeCount || 0 },
        { name: 'Neutral', value: stats?.neutralCount || 0 },
      ].filter(item => item.value > 0);
    } else if (selectedPlatform === 'reviews') {
      return [
        { name: 'Positive', value: (reviews ?? []).filter(r => r.sentiment === 'positive').length },
        { name: 'Negative', value: (reviews ?? []).filter(r => r.sentiment === 'negative').length },
        { name: 'Neutral', value: (reviews ?? []).filter(r => r.sentiment === 'neutral').length },
      ].filter(item => item.value > 0);
    } else {
      return [
        { name: 'Positive', value: (filteredSocialFeeds ?? []).filter(f => f.sentiment === 'positive').length },
        { name: 'Negative', value: (filteredSocialFeeds ?? []).filter(f => f.sentiment === 'negative').length },
        { name: 'Neutral', value: (filteredSocialFeeds ?? []).filter(f => f.sentiment === 'neutral').length },
      ].filter(item => item.value > 0);
    }
  })();

  const platformSentiment = selectedPlatform === 'all' ? [
    {
      platform: 'YouTube',
      positive: (socialFeeds ?? []).filter(f => f.platform === 'youtube' && f.sentiment === 'positive').length,
      negative: (socialFeeds ?? []).filter(f => f.platform === 'youtube' && f.sentiment === 'negative').length,
      total: Math.max((socialFeeds ?? []).filter(f => f.platform === 'youtube').length, 1),
    },
    {
      platform: 'News',
      positive: (socialFeeds ?? []).filter(f => f.platform === 'news' && f.sentiment === 'positive').length,
      negative: (socialFeeds ?? []).filter(f => f.platform === 'news' && f.sentiment === 'negative').length,
      total: Math.max((socialFeeds ?? []).filter(f => f.platform === 'news').length, 1),
    },
    {
      platform: 'Reviews',
      positive: stats?.positiveCount || 0,
      negative: stats?.negativeCount || 0,
      total: Math.max((stats?.positiveCount || 0) + (stats?.negativeCount || 0) + (stats?.neutralCount || 0), 1),
    },
  ] : [
    {
      platform: selectedPlatform === 'youtube' ? 'YouTube' : selectedPlatform === 'news' ? 'News' : 'Reviews',
      positive: selectedPlatform === 'reviews' 
        ? (reviews ?? []).filter(r => r.sentiment === 'positive').length
        : (filteredSocialFeeds ?? []).filter(f => f.sentiment === 'positive').length,
      negative: selectedPlatform === 'reviews'
        ? (reviews ?? []).filter(r => r.sentiment === 'negative').length
        : (filteredSocialFeeds ?? []).filter(f => f.sentiment === 'negative').length,
      total: Math.max(
        selectedPlatform === 'reviews'
          ? (reviews ?? []).length
          : (filteredSocialFeeds ?? []).length,
        1
      ),
    },
  ];

  const sourceDistribution = [
    { name: 'YouTube', value: (socialFeeds ?? []).filter(f => f.platform === 'youtube').length, color: COLORS.youtube },
    { name: 'News', value: (socialFeeds ?? []).filter(f => f.platform === 'news').length, color: COLORS.news },
    { name: 'Reviews', value: (reviews ?? []).length, color: COLORS.spotify },
  ];

  const recentFeeds = selectedPlatform === 'reviews'
    ? []
    : (filteredSocialFeeds ?? []).slice(0, 5);

  return (
    <div className="space-y-6 pb-8">
      {/* Header with Platform Tabs */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-dashboard-title">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Real-time sentiment monitoring and analytics</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            Live
          </Badge>
        </div>
      </div>

      {/* Platform Tabs */}
      <Card>
        <CardContent className="pt-6">
          <Tabs defaultValue="all" value={selectedPlatform} onValueChange={setSelectedPlatform}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all" data-testid="tab-all">All Sources</TabsTrigger>
              <TabsTrigger value="youtube" data-testid="tab-youtube">
                <Youtube className="h-4 w-4 mr-2" />
                YouTube
              </TabsTrigger>
              <TabsTrigger value="news" data-testid="tab-news">
                <Newspaper className="h-4 w-4 mr-2" />
                News
              </TabsTrigger>
              <TabsTrigger value="reviews" data-testid="tab-reviews">
                <Smartphone className="h-4 w-4 mr-2" />
                Reviews
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardContent>
      </Card>

      {/* Summary Stats Row */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Mentions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{(stats?.totalCount || 0) + (socialFeeds?.length || 0)}</div>
            <p className="text-xs text-muted-foreground mt-1">Across all sources</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sentiment Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.overallScore || 0}/100</div>
            <p className="text-xs text-muted-foreground mt-1">Overall rating</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Sources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{sourceDistribution.filter(s => s.value > 0).length}</div>
            <p className="text-xs text-muted-foreground mt-1">YouTube, News, Reviews</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Coverage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Global</div>
            <p className="text-xs text-muted-foreground mt-1">Worldwide monitoring</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Grid Layout */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left Column - Mentions */}
        <Card data-testid="card-mentions">
          <CardHeader className="space-y-0 pb-4">
            <CardTitle className="text-base font-medium">Mentions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={sentimentDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {sentimentDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[entry.name.toLowerCase() as keyof typeof COLORS]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2 text-sm">
              {platformSentiment.map((platform, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <span className="text-muted-foreground">{platform.platform}</span>
                  <span className="font-medium">{platform.total}</span>
                </div>
              ))}
            </div>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={trendData?.slice(-7) || []}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted/20" />
                <XAxis dataKey="date" className="text-xs" hide />
                <YAxis hide />
                <Tooltip />
                <Line type="monotone" dataKey="positive" stroke={COLORS.positive} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="negative" stroke={COLORS.negative} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="neutral" stroke={COLORS.neutral} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Middle Column - Sentiment */}
        <Card data-testid="card-sentiment">
          <CardHeader className="space-y-0 pb-4">
            <CardTitle className="text-base font-medium">Sentiment</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {platformSentiment.map((platform, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">{platform.platform}</span>
                  <span className="text-muted-foreground">
                    {Math.round((platform.positive / platform.total) * 100)}%
                  </span>
                </div>
                <div className="flex gap-1 h-8">
                  <div
                    className="bg-green-500 rounded-sm transition-all"
                    style={{ width: `${(platform.positive / platform.total) * 100}%` }}
                    data-testid={`bar-positive-${platform.platform}`}
                  />
                  <div
                    className="bg-red-500 rounded-sm transition-all"
                    style={{ width: `${(platform.negative / platform.total) * 100}%` }}
                    data-testid={`bar-negative-${platform.platform}`}
                  />
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    Positive
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="h-2 w-2 rounded-full bg-red-500" />
                    Negative
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Right Column - Reach */}
        <Card data-testid="card-reach">
          <CardHeader className="space-y-0 pb-4">
            <CardTitle className="text-base font-medium">Reach</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={sentimentDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {sentimentDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[entry.name.toLowerCase() as keyof typeof COLORS]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center text-sm">
              <div>
                <div className="text-2xl font-bold text-green-500">{stats?.positivePercent || 0}%</div>
                <div className="text-xs text-muted-foreground">Positive</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-red-500">{stats?.negativePercent || 0}%</div>
                <div className="text-xs text-muted-foreground">Negative</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-500">{stats?.neutralPercent || 0}%</div>
                <div className="text-xs text-muted-foreground">Neutral</div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={trendData?.slice(-7) || []}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted/20" />
                <XAxis dataKey="date" className="text-xs" hide />
                <YAxis hide />
                <Tooltip />
                <Line type="monotone" dataKey="positive" stroke={COLORS.positive} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="negative" stroke={COLORS.negative} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Second Row - Mentions List & Map */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Mentions/Influencers List */}
        <Card data-testid="card-mentions-list">
          <CardHeader>
            <CardTitle className="text-base font-medium">Recent Mentions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentFeeds.length > 0 ? (
              recentFeeds.map((feed, idx) => (
                <div key={feed.id} className="flex items-start gap-3 pb-3 border-b last:border-0" data-testid={`mention-${idx}`}>
                  <div className="flex-shrink-0">
                    {feed.platform === 'youtube' ? (
                      <Youtube className="h-5 w-5 text-red-500" />
                    ) : (
                      <Newspaper className="h-5 w-5 text-blue-500" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium truncate">{feed.author || 'Anonymous'}</span>
                      <Badge variant={feed.sentiment === 'positive' ? 'default' : feed.sentiment === 'negative' ? 'destructive' : 'secondary'} className="text-xs">
                        {feed.sentiment}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">{feed.content}</p>
                    {feed.url && (
                      <a href={feed.url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline mt-1 inline-block">
                        View source →
                      </a>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Newspaper className="h-12 w-12 mx-auto mb-2 opacity-20" />
                <p className="text-sm">No recent mentions</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Countries/Geographic Distribution */}
        <Card data-testid="card-geographic">
          <CardHeader>
            <CardTitle className="text-base font-medium">Geographic Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            {geoData && geoData.length > 0 ? (
              <div className="space-y-3">
                {geoData.map((country, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">{country.name}</span>
                      <span className="text-muted-foreground">{country.count} mentions</span>
                    </div>
                    <div className="relative h-6 bg-muted rounded-sm overflow-hidden">
                      <div
                        className="absolute inset-y-0 left-0 bg-primary rounded-sm transition-all"
                        style={{
                          width: `${Math.min((country.count / Math.max(...(geoData?.map(c => c.count) ?? [1]), 1)) * 100, 100)}%`,
                        }}
                        data-testid={`geo-bar-${country.name}`}
                      />
                      <div className="absolute inset-0 flex items-center px-2">
                        <span className="text-xs font-medium text-white drop-shadow">
                          {Math.round((country.count / (geoData?.reduce((sum, c) => sum + c.count, 0) || 1)) * 100)}%
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                <div className="text-center">
                  <Globe2 className="h-24 w-24 mx-auto mb-4 opacity-20" />
                  <p className="text-sm">No geographic data yet</p>
                  <p className="text-xs mt-1">Upload reviews or monitor social media to see country distribution</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Third Row - Topic Cloud & Sources */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Topic Cloud (Word Map) */}
        <Card data-testid="card-topic-cloud">
          <CardHeader>
            <CardTitle className="text-base font-medium">Topic Cloud</CardTitle>
          </CardHeader>
          <CardContent>
            {wordCloudData && wordCloudData.length > 0 ? (
              <WordCloud words={wordCloudData} height={320} />
            ) : (
              <div className="flex items-center justify-center h-80 text-muted-foreground">
                <div className="text-center">
                  <p className="text-sm">No data available for word cloud</p>
                  <p className="text-xs mt-1">Upload reviews or monitor social media to see trending topics</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Sources Distribution */}
        <Card data-testid="card-sources">
          <CardHeader>
            <CardTitle className="text-base font-medium">Sources</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {sourceDistribution.map((source, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">{source.name}</span>
                  <span className="text-muted-foreground">{source.value} items</span>
                </div>
                <div className="relative h-8 bg-muted rounded-sm overflow-hidden">
                  <div
                    className="absolute inset-y-0 left-0 rounded-sm transition-all"
                    style={{
                      width: `${Math.min((source.value / Math.max(...sourceDistribution.map(s => s.value), 1)) * 100, 100)}%`,
                      backgroundColor: source.color,
                    }}
                    data-testid={`source-bar-${source.name}`}
                  />
                  <div className="absolute inset-0 flex items-center px-3">
                    <span className="text-xs font-medium text-white drop-shadow">
                      {Math.round((source.value / Math.max(sourceDistribution.reduce((sum, s) => sum + s.value, 0), 1)) * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            ))}

            <div className="pt-4 border-t">
              <ResponsiveContainer width="100%" height={150}>
                <BarChart data={sourceDistribution}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted/20" />
                  <XAxis dataKey="name" className="text-xs" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {sourceDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
