import { useState, useCallback, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileSpreadsheet, X, CheckCircle2, Loader2 } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Analysis } from "@shared/schema";
import { SentimentBadge } from "@/components/sentiment-badge";
import { format } from "date-fns";

export default function UploadPage() {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: analyses, isLoading } = useQuery<Analysis[]>({
    queryKey: ['/api/analyses'],
    refetchInterval: analyzingId ? 1000 : false, // Poll every second when analyzing
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      return apiRequest('POST', '/api/upload', formData);
    },
    onSuccess: (data: Analysis) => {
      setAnalyzingId(data.id);
      queryClient.invalidateQueries({ queryKey: ['/api/analyses'] });
      toast({
        title: "Analysis started",
        description: "Your file is being analyzed. This may take a few minutes.",
      });
      setSelectedFile(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
      setAnalyzingId(null);
    },
  });

  // Check for analysis completion
  useEffect(() => {
    if (analyzingId && analyses) {
      const analysis = analyses.find(a => a.id === analyzingId);
      if (analysis && (analysis.status === "completed" || analysis.status === "failed")) {
        // Wait a moment, then invalidate and clear state
        const timeoutId = setTimeout(() => {
          queryClient.invalidateQueries({ queryKey: ['/api/analyses'] });
          setAnalyzingId(null);
          
          if (analysis.status === "completed") {
            toast({
              title: "Analysis complete",
              description: `Successfully analyzed ${analysis.totalReviews} reviews.`,
            });
          } else {
            toast({
              title: "Analysis failed",
              description: "There was an error processing your file.",
              variant: "destructive",
            });
          }
        }, 100);
        
        return () => clearTimeout(timeoutId);
      }
    }
  }, [analyses, analyzingId, toast, queryClient]);

  // Auto-clear stuck analyzing state after 5 minutes
  useEffect(() => {
    if (analyzingId) {
      const timeoutId = setTimeout(() => {
        console.warn("Analysis timeout - clearing stuck state");
        setAnalyzingId(null);
        queryClient.invalidateQueries({ queryKey: ['/api/analyses'] });
        toast({
          title: "Analysis check",
          description: "Checking analysis status. Please refresh if needed.",
        });
      }, 5 * 60 * 1000); // 5 minutes
      
      return () => clearTimeout(timeoutId);
    }
  }, [analyzingId, queryClient, toast]);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls') || file.name.endsWith('.csv')) {
        setSelectedFile(file);
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload an Excel (.xlsx, .xls) or CSV file.",
          variant: "destructive",
        });
      }
    }
  }, [toast]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  }, []);

  const handleUpload = () => {
    if (selectedFile) {
      uploadMutation.mutate(selectedFile);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-upload-title">Upload Data</h1>
        <p className="text-muted-foreground mt-1">Upload Excel files containing customer reviews for sentiment analysis</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upload Excel File</CardTitle>
          <CardDescription>
            Drag and drop your Excel file or click to browse. Supported formats: .xlsx, .xls, .csv
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className={`relative border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
              dragActive
                ? 'border-primary bg-primary/5'
                : 'border-muted-foreground/25 hover:border-muted-foreground/50'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            data-testid="dropzone-upload"
          >
            <input
              type="file"
              id="file-upload"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              accept=".xlsx,.xls,.csv"
              onChange={handleFileInput}
              data-testid="input-file"
            />
            
            {!selectedFile ? (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div className="p-4 rounded-full bg-primary/10">
                    <Upload className="h-10 w-10 text-primary" />
                  </div>
                </div>
                <div>
                  <p className="text-lg font-medium">Drop your file here</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    or click to browse from your computer
                  </p>
                </div>
                <p className="text-xs text-muted-foreground">
                  Maximum file size: 10MB
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div className="p-4 rounded-full bg-green-100 dark:bg-green-950/30">
                    <FileSpreadsheet className="h-10 w-10 text-green-600 dark:text-green-400" />
                  </div>
                </div>
                <div>
                  <p className="text-lg font-medium" data-testid="text-selected-filename">{selectedFile.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
                <div className="flex gap-2 justify-center">
                  <Button
                    onClick={handleUpload}
                    disabled={uploadMutation.isPending}
                    data-testid="button-upload"
                  >
                    {uploadMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="h-4 w-4 mr-2" />
                        Analyze File
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedFile(null)}
                    disabled={uploadMutation.isPending}
                    data-testid="button-cancel"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Upload History</CardTitle>
          <CardDescription>Previous sentiment analysis results</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />
              ))}
            </div>
          ) : analyses && analyses.length > 0 ? (
            <div className="space-y-4">
              {analyses.map((analysis) => (
                <div
                  key={analysis.id}
                  className="p-4 rounded-lg border hover-elevate space-y-3"
                  data-testid={`analysis-item-${analysis.id}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg bg-primary/10">
                        {analysis.status === "processing" ? (
                          <Loader2 className="h-6 w-6 text-primary animate-spin" />
                        ) : (
                          <FileSpreadsheet className="h-6 w-6 text-primary" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{analysis.fileName}</p>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(analysis.uploadedAt), 'MMM d, yyyy • h:mm a')}
                        </p>
                      </div>
                    </div>
                    {analysis.status === "completed" && (
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Overall Score</p>
                          <p className="text-2xl font-bold">{Math.round(analysis.overallSentiment)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Reviews</p>
                          <p className="font-medium">{analysis.totalReviews}</p>
                        </div>
                        <div className="flex gap-2">
                          <span className="text-xs px-2 py-1 rounded bg-green-100 text-green-800 dark:bg-green-950/30 dark:text-green-400">
                            {analysis.positiveCount} +
                          </span>
                          <span className="text-xs px-2 py-1 rounded bg-red-100 text-red-800 dark:bg-red-950/30 dark:text-red-400">
                            {analysis.negativeCount} -
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                  {analysis.status === "processing" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Analyzing {analysis.totalReviews} reviews...</span>
                        <span className="font-medium">{analysis.progress || 0}%</span>
                      </div>
                      <Progress value={analysis.progress || 0} className="h-2" data-testid={`progress-${analysis.id}`} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="flex justify-center mb-4">
                <div className="p-4 rounded-full bg-muted">
                  <FileSpreadsheet className="h-10 w-10 text-muted-foreground" />
                </div>
              </div>
              <p className="text-lg font-medium">No uploads yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Upload your first file to get started with sentiment analysis
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
