import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { AlertCircle, CheckCircle2, Clock, Filter, Search, User } from "lucide-react";
import { SentimentBadge } from "@/components/sentiment-badge";
import type { Review, Ticket } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";

const priorityConfig = {
  high: { label: "High", className: "bg-red-100 text-red-800 dark:bg-red-950/30 dark:text-red-400", icon: AlertCircle },
  medium: { label: "Medium", className: "bg-yellow-100 text-yellow-800 dark:bg-yellow-950/30 dark:text-yellow-400", icon: Clock },
  low: { label: "Low", className: "bg-blue-100 text-blue-800 dark:bg-blue-950/30 dark:text-blue-400", icon: CheckCircle2 },
};

const statusConfig = {
  open: { label: "Open", className: "bg-blue-100 text-blue-800 dark:bg-blue-950/30 dark:text-blue-400" },
  in_progress: { label: "In Progress", className: "bg-yellow-100 text-yellow-800 dark:bg-yellow-950/30 dark:text-yellow-400" },
  resolved: { label: "Resolved", className: "bg-green-100 text-green-800 dark:bg-green-950/30 dark:text-green-400" },
  closed: { label: "Closed", className: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300" },
};

export default function ReviewsPage() {
  const [sentimentFilter, setSentimentFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedReview, setSelectedReview] = useState<Review | null>(null);
  const [ticketFormOpen, setTicketFormOpen] = useState(false);
  const [ticketPriority, setTicketPriority] = useState<string>("high");
  const [ticketNotes, setTicketNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reviews, isLoading: reviewsLoading } = useQuery<Review[]>({
    queryKey: sentimentFilter === "all" 
      ? ['/api/reviews'] 
      : ['/api/reviews', `?sentiment=${sentimentFilter}`],
  });

  const { data: tickets, isLoading: ticketsLoading } = useQuery<(Ticket & { review: Review })[]>({
    queryKey: statusFilter === "all" 
      ? ['/api/tickets'] 
      : ['/api/tickets', `?status=${statusFilter}`],
  });

  const createTicketMutation = useMutation({
    mutationFn: async (data: { reviewId: string; priority: string; notes: string }) => {
      return apiRequest('POST', '/api/tickets', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      toast({
        title: "Ticket created",
        description: "Escalation ticket has been created successfully.",
      });
      setTicketFormOpen(false);
      setSelectedReview(null);
      setTicketNotes("");
    },
  });

  const updateTicketMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      return apiRequest('PATCH', `/api/tickets/${id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      toast({
        title: "Ticket updated",
        description: "Ticket status has been updated.",
      });
    },
  });

  const filteredReviews = reviews?.filter(review =>
    searchQuery === "" || review.content.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handleCreateTicket = (review: Review) => {
    setSelectedReview(review);
    setTicketFormOpen(true);
  };

  const submitTicket = () => {
    if (selectedReview) {
      createTicketMutation.mutate({
        reviewId: selectedReview.id,
        priority: ticketPriority,
        notes: ticketNotes,
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-reviews-title">Reviews & Tickets</h1>
        <p className="text-muted-foreground mt-1">Manage reviews and escalation tickets</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <CardTitle>All Reviews</CardTitle>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search reviews..."
                    className="pl-9 w-48"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    data-testid="input-search-reviews"
                  />
                </div>
                <Select value={sentimentFilter} onValueChange={setSentimentFilter}>
                  <SelectTrigger className="w-32" data-testid="select-sentiment">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="positive">Positive</SelectItem>
                    <SelectItem value="negative">Negative</SelectItem>
                    <SelectItem value="neutral">Neutral</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {reviewsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
                ))}
              </div>
            ) : filteredReviews.length > 0 ? (
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                {filteredReviews.map((review, idx) => (
                  <div key={review.id} className="p-4 rounded-lg border hover-elevate" data-testid={`review-item-${idx}`}>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-center gap-2">
                        <SentimentBadge
                          sentiment={review.sentiment as "positive" | "negative" | "neutral"}
                          score={Math.round(review.sentimentScore)}
                        />
                        <Badge variant="outline" className="text-xs">{review.source}</Badge>
                      </div>
                      {review.sentiment === 'negative' && (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleCreateTicket(review)}
                          data-testid={`button-create-ticket-${idx}`}
                        >
                          Create Ticket
                        </Button>
                      )}
                    </div>
                    <p className="text-sm mb-2">{review.content}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      {review.author && (
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {review.author}
                        </span>
                      )}
                      <span>•</span>
                      <span>{formatDistanceToNow(new Date(review.timestamp), { addSuffix: true })}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No reviews found</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <CardTitle>Escalation Tickets</CardTitle>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32" data-testid="select-status">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {ticketsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />
                ))}
              </div>
            ) : tickets && tickets.length > 0 ? (
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                {tickets.map((ticket, idx) => {
                  const PriorityIcon = priorityConfig[ticket.priority as keyof typeof priorityConfig]?.icon || AlertCircle;
                  const priorityClass = priorityConfig[ticket.priority as keyof typeof priorityConfig]?.className || "";
                  const statusClass = statusConfig[ticket.status as keyof typeof statusConfig]?.className || "";

                  return (
                    <div key={ticket.id} className="p-4 rounded-lg border hover-elevate" data-testid={`ticket-item-${idx}`}>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge className={priorityClass}>
                            <PriorityIcon className="h-3 w-3 mr-1" />
                            {priorityConfig[ticket.priority as keyof typeof priorityConfig]?.label}
                          </Badge>
                          <Badge className={statusClass}>
                            {statusConfig[ticket.status as keyof typeof statusConfig]?.label}
                          </Badge>
                          <span className="text-xs text-muted-foreground">#{ticket.id.slice(0, 8)}</span>
                        </div>
                      </div>
                      <p className="text-sm mb-3 line-clamp-2">{ticket.review?.content}</p>
                      {ticket.notes && (
                        <p className="text-xs text-muted-foreground mb-3 italic">Note: {ticket.notes}</p>
                      )}
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground">
                          Created {formatDistanceToNow(new Date(ticket.createdAt), { addSuffix: true })}
                        </span>
                        <Select
                          value={ticket.status}
                          onValueChange={(value) => updateTicketMutation.mutate({ id: ticket.id, status: value })}
                        >
                          <SelectTrigger className="w-32 h-8" data-testid={`select-ticket-status-${idx}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="open">Open</SelectItem>
                            <SelectItem value="in_progress">In Progress</SelectItem>
                            <SelectItem value="resolved">Resolved</SelectItem>
                            <SelectItem value="closed">Closed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="flex justify-center mb-4">
                  <div className="p-4 rounded-full bg-muted">
                    <AlertCircle className="h-10 w-10 text-muted-foreground" />
                  </div>
                </div>
                <p className="text-lg font-medium">No tickets yet</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Create tickets from negative reviews
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={ticketFormOpen} onOpenChange={setTicketFormOpen}>
        <DialogContent data-testid="dialog-create-ticket">
          <DialogHeader>
            <DialogTitle>Create Escalation Ticket</DialogTitle>
            <DialogDescription>
              Create a ticket to track and resolve this negative review
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Review Content</Label>
              <p className="text-sm p-3 rounded-lg bg-muted">{selectedReview?.content}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="priority">Priority</Label>
              <Select value={ticketPriority} onValueChange={setTicketPriority}>
                <SelectTrigger id="priority" data-testid="select-ticket-priority">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                placeholder="Add any notes or action items..."
                value={ticketNotes}
                onChange={(e) => setTicketNotes(e.target.value)}
                data-testid="input-ticket-notes"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTicketFormOpen(false)} data-testid="button-cancel-ticket">
              Cancel
            </Button>
            <Button onClick={submitTicket} disabled={createTicketMutation.isPending} data-testid="button-submit-ticket">
              {createTicketMutation.isPending ? "Creating..." : "Create Ticket"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
