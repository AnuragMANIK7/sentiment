import { pgTable, text, varchar, timestamp, integer, real, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Analysis results from uploaded Excel files
export const analyses = pgTable("analyses", {
  id: varchar("id").primaryKey(),
  fileName: text("file_name").notNull(),
  uploadedAt: timestamp("uploaded_at").notNull(),
  totalReviews: integer("total_reviews").notNull(),
  overallSentiment: real("overall_sentiment").notNull(), // 0-100 score
  positiveCount: integer("positive_count").notNull(),
  negativeCount: integer("negative_count").notNull(),
  neutralCount: integer("neutral_count").notNull(),
  status: text("status").notNull(), // processing, completed, failed
  progress: integer("progress").notNull().default(0), // 0-100 percentage
});

export const insertAnalysisSchema = createInsertSchema(analyses).omit({
  id: true,
});

export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;
export type Analysis = typeof analyses.$inferSelect;

// Individual reviews with sentiment scores
export const reviews = pgTable("reviews", {
  id: varchar("id").primaryKey(),
  analysisId: varchar("analysis_id").notNull(),
  content: text("content").notNull(),
  sentiment: text("sentiment").notNull(), // positive, negative, neutral
  sentimentScore: real("sentiment_score").notNull(), // 0-100
  source: text("source").notNull(), // excel, twitter, youtube, instagram, news
  platform: text("platform"), // specific platform name
  author: text("author"),
  timestamp: timestamp("timestamp").notNull(),
  product: text("product"), // iphone, other
  country: text("country"), // extracted country from content
  region: text("region"), // geographic region (North America, Europe, Asia, etc.)
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
});

export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;

// Escalation tickets for negative reviews
export const tickets = pgTable("tickets", {
  id: varchar("id").primaryKey(),
  reviewId: varchar("review_id").notNull(),
  priority: text("priority").notNull(), // high, medium, low
  status: text("status").notNull(), // open, in_progress, resolved, closed
  assignedTo: text("assigned_to"),
  createdAt: timestamp("created_at").notNull(),
  updatedAt: timestamp("updated_at").notNull(),
  notes: text("notes"),
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
});

export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;

// Social media feed items (for monitoring dashboard)
export const socialFeeds = pgTable("social_feeds", {
  id: varchar("id").primaryKey(),
  platform: text("platform").notNull(), // youtube, news
  content: text("content").notNull(),
  sentiment: text("sentiment").notNull(),
  sentimentScore: real("sentiment_score").notNull(),
  author: text("author").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  url: text("url"), // link to original post
  product: text("product"), // iphone, other
  engagement: integer("engagement"), // likes, shares, etc.
  country: text("country"), // extracted country from content
  region: text("region"), // geographic region (North America, Europe, Asia, etc.)
});

export const insertSocialFeedSchema = createInsertSchema(socialFeeds).omit({
  id: true,
});

export type InsertSocialFeed = z.infer<typeof insertSocialFeedSchema>;
export type SocialFeed = typeof socialFeeds.$inferSelect;

// Generated presentations
export const presentations = pgTable("presentations", {
  id: varchar("id").primaryKey(),
  title: text("title").notNull(),
  analysisId: varchar("analysis_id"),
  createdAt: timestamp("created_at").notNull(),
  slides: text("slides").notNull(), // JSON array of slide data
});

export const insertPresentationSchema = createInsertSchema(presentations).omit({
  id: true,
});

export type InsertPresentation = z.infer<typeof insertPresentationSchema>;
export type Presentation = typeof presentations.$inferSelect;
