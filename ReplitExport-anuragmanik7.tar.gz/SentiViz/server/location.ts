// Location extraction utilities

interface LocationData {
  country: string | null;
  region: string | null;
}

// Common country mentions in reviews and social media
const COUNTRY_PATTERNS: { [key: string]: { keywords: string[], region: string } } = {
  'United States': {
    keywords: ['usa', 'united states', 'america', 'american', 'california', 'new york', 'texas', 'florida'],
    region: 'North America'
  },
  'Canada': {
    keywords: ['canada', 'canadian', 'toronto', 'vancouver', 'montreal'],
    region: 'North America'
  },
  'United Kingdom': {
    keywords: ['uk', 'united kingdom', 'britain', 'british', 'england', 'london', 'scotland', 'wales'],
    region: 'Europe'
  },
  'Germany': {
    keywords: ['germany', 'german', 'berlin', 'munich', 'frankfurt'],
    region: 'Europe'
  },
  'France': {
    keywords: ['france', 'french', 'paris', 'lyon'],
    region: 'Europe'
  },
  'Italy': {
    keywords: ['italy', 'italian', 'rome', 'milan'],
    region: 'Europe'
  },
  'Spain': {
    keywords: ['spain', 'spanish', 'madrid', 'barcelona'],
    region: 'Europe'
  },
  'Netherlands': {
    keywords: ['netherlands', 'dutch', 'amsterdam', 'holland'],
    region: 'Europe'
  },
  'India': {
    keywords: ['india', 'indian', 'delhi', 'mumbai', 'bangalore', 'chennai'],
    region: 'Asia'
  },
  'China': {
    keywords: ['china', 'chinese', 'beijing', 'shanghai', 'guangzhou'],
    region: 'Asia'
  },
  'Japan': {
    keywords: ['japan', 'japanese', 'tokyo', 'osaka', 'kyoto'],
    region: 'Asia'
  },
  'South Korea': {
    keywords: ['korea', 'korean', 'seoul', 'busan'],
    region: 'Asia'
  },
  'Singapore': {
    keywords: ['singapore', 'singaporean'],
    region: 'Asia'
  },
  'Australia': {
    keywords: ['australia', 'australian', 'sydney', 'melbourne', 'brisbane'],
    region: 'Oceania'
  },
  'Brazil': {
    keywords: ['brazil', 'brazilian', 'sao paulo', 'rio de janeiro'],
    region: 'South America'
  },
  'Mexico': {
    keywords: ['mexico', 'mexican', 'mexico city'],
    region: 'North America'
  },
  'UAE': {
    keywords: ['uae', 'dubai', 'abu dhabi', 'emirates'],
    region: 'Middle East'
  },
  'Saudi Arabia': {
    keywords: ['saudi', 'riyadh', 'jeddah'],
    region: 'Middle East'
  },
};

/**
 * Extract country and region information from text content
 * @param text - The review or social media content to analyze
 * @returns LocationData with country and region (null if not found)
 */
export function extractLocation(text: string): LocationData {
  if (!text || typeof text !== 'string') {
    return { country: null, region: null };
  }

  const lowerText = text.toLowerCase();

  // Special handling for US - check for standalone US, U.S., or with common patterns
  const usPatterns = [
    /\bus\b/i,           // "US market", "in US", "the US"
    /\bu\.s\./i,         // "U.S.", "U.S. market"
    /\bu\.s\b/i,         // "U.S", "the U.S"
  ];
  
  for (const pattern of usPatterns) {
    if (pattern.test(text)) {
      return {
        country: 'United States',
        region: 'North America'
      };
    }
  }

  // Try to find a country match
  for (const [country, data] of Object.entries(COUNTRY_PATTERNS)) {
    for (const keyword of data.keywords) {
      // Check for whole word matches (with word boundaries)
      const regex = new RegExp(`\\b${keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
      if (regex.test(lowerText)) {
        return {
          country,
          region: data.region
        };
      }
    }
  }

  // No location found
  return { country: null, region: null };
}

/**
 * Get a list of all supported countries for analytics
 */
export function getSupportedCountries(): string[] {
  return Object.keys(COUNTRY_PATTERNS);
}

/**
 * Get region for a specific country
 */
export function getRegionForCountry(country: string): string | null {
  return COUNTRY_PATTERNS[country]?.region || null;
}
