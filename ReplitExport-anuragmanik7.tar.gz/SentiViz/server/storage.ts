import { randomUUID } from "crypto";
import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { eq, desc, and, sql } from "drizzle-orm";
import type {
  Analysis,
  InsertAnalysis,
  Review,
  InsertReview,
  Ticket,
  InsertTicket,
  SocialFeed,
  InsertSocialFeed,
  Presentation,
  InsertPresentation,
} from "@shared/schema";
import {
  analyses,
  reviews,
  tickets,
  socialFeeds,
  presentations,
} from "@shared/schema";

export interface IStorage {
  // Analyses
  createAnalysis(analysis: InsertAnalysis): Promise<Analysis>;
  getAnalysis(id: string): Promise<Analysis | undefined>;
  getAllAnalyses(): Promise<Analysis[]>;
  updateAnalysis(id: string, updates: Partial<Analysis>): Promise<Analysis | undefined>;

  // Reviews
  createReview(review: InsertReview): Promise<Review>;
  getReview(id: string): Promise<Review | undefined>;
  getReviewsByAnalysis(analysisId: string): Promise<Review[]>;
  getAllReviews(): Promise<Review[]>;
  getReviewsBySentiment(sentiment: string): Promise<Review[]>;
  getTopReviews(limit: number, sentiment: "positive" | "negative"): Promise<Review[]>;

  // Tickets
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  getTicket(id: string): Promise<Ticket | undefined>;
  getAllTickets(): Promise<Ticket[]>;
  getTicketsByStatus(status: string): Promise<Ticket[]>;
  updateTicket(id: string, updates: Partial<Ticket>): Promise<Ticket | undefined>;

  // Social Feeds
  createSocialFeed(feed: InsertSocialFeed): Promise<SocialFeed>;
  getSocialFeed(id: string): Promise<SocialFeed | undefined>;
  getAllSocialFeeds(): Promise<SocialFeed[]>;
  getSocialFeedsByPlatform(platform: string): Promise<SocialFeed[]>;
  getSocialFeedsBySentiment(sentiment: string): Promise<SocialFeed[]>;

  // Presentations
  createPresentation(presentation: InsertPresentation): Promise<Presentation>;
  getPresentation(id: string): Promise<Presentation | undefined>;
  getAllPresentations(): Promise<Presentation[]>;
}

export class MemStorage implements IStorage {
  private analyses: Map<string, Analysis>;
  private reviews: Map<string, Review>;
  private tickets: Map<string, Ticket>;
  private socialFeeds: Map<string, SocialFeed>;
  private presentations: Map<string, Presentation>;

  constructor() {
    this.analyses = new Map();
    this.reviews = new Map();
    this.tickets = new Map();
    this.socialFeeds = new Map();
    this.presentations = new Map();
    this.seedMockData();
  }

  // Seed with mock data for social feeds and initial stats
  private seedMockData() {
    const mockFeeds: InsertSocialFeed[] = [
      {
        platform: "twitter",
        content: "Just got the new iPhone 17! The camera quality is absolutely incredible. Best upgrade yet! #iPhone17",
        sentiment: "positive",
        sentimentScore: 92,
        author: "@techreview_mike",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
        product: "iphone",
        engagement: 1234,
      },
      {
        platform: "twitter",
        content: "Disappointed with the battery life on Samsung Galaxy. Expected better performance for the price.",
        sentiment: "negative",
        sentimentScore: 32,
        author: "@gadgetfan_sara",
        timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
        product: "samsung",
        engagement: 456,
      },
      {
        platform: "youtube",
        content: "The display on the iPhone 17 is stunning, but the price is really steep. Not sure if worth the upgrade.",
        sentiment: "neutral",
        sentimentScore: 55,
        author: "TechReviews Daily",
        timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
        product: "iphone",
        engagement: 892,
      },
      {
        platform: "instagram",
        content: "Samsung Galaxy camera system is amazing for night photography! Highly recommend for photo enthusiasts.",
        sentiment: "positive",
        sentimentScore: 88,
        author: "photography_pro",
        timestamp: new Date(Date.now() - 30 * 60 * 1000),
        product: "samsung",
        engagement: 2341,
      },
      {
        platform: "news",
        content: "iPhone 17 sets new benchmark for smartphone performance according to latest industry tests.",
        sentiment: "positive",
        sentimentScore: 85,
        author: "Tech News Network",
        timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
        product: "iphone",
        engagement: 5678,
      },
    ];

    mockFeeds.forEach((feed) => {
      const id = randomUUID();
      this.socialFeeds.set(id, { ...feed, id });
    });
  }

  // Analyses
  async createAnalysis(insertAnalysis: InsertAnalysis): Promise<Analysis> {
    const id = randomUUID();
    const analysis: Analysis = { ...insertAnalysis, id };
    this.analyses.set(id, analysis);
    return analysis;
  }

  async getAnalysis(id: string): Promise<Analysis | undefined> {
    return this.analyses.get(id);
  }

  async getAllAnalyses(): Promise<Analysis[]> {
    return Array.from(this.analyses.values()).sort(
      (a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );
  }

  async updateAnalysis(id: string, updates: Partial<Analysis>): Promise<Analysis | undefined> {
    const existing = this.analyses.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...updates };
    this.analyses.set(id, updated);
    return updated;
  }

  // Reviews
  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = randomUUID();
    const review: Review = { ...insertReview, id };
    this.reviews.set(id, review);
    return review;
  }

  async getReview(id: string): Promise<Review | undefined> {
    return this.reviews.get(id);
  }

  async getReviewsByAnalysis(analysisId: string): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      (review) => review.analysisId === analysisId
    );
  }

  async getAllReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values());
  }

  async getReviewsBySentiment(sentiment: string): Promise<Review[]> {
    if (sentiment === "all") {
      return this.getAllReviews();
    }
    return Array.from(this.reviews.values()).filter(
      (review) => review.sentiment === sentiment
    );
  }

  async getTopReviews(limit: number, sentiment: "positive" | "negative"): Promise<Review[]> {
    const filtered = Array.from(this.reviews.values()).filter(
      (review) => review.sentiment === sentiment
    );
    
    const sorted = filtered.sort((a, b) => {
      if (sentiment === "positive") {
        return b.sentimentScore - a.sentimentScore;
      } else {
        return a.sentimentScore - b.sentimentScore;
      }
    });
    
    return sorted.slice(0, limit);
  }

  // Tickets
  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const id = randomUUID();
    const ticket: Ticket = { ...insertTicket, id };
    this.tickets.set(id, ticket);
    return ticket;
  }

  async getTicket(id: string): Promise<Ticket | undefined> {
    return this.tickets.get(id);
  }

  async getAllTickets(): Promise<Ticket[]> {
    return Array.from(this.tickets.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getTicketsByStatus(status: string): Promise<Ticket[]> {
    if (status === "all") {
      return this.getAllTickets();
    }
    return Array.from(this.tickets.values()).filter(
      (ticket) => ticket.status === status
    );
  }

  async updateTicket(id: string, updates: Partial<Ticket>): Promise<Ticket | undefined> {
    const ticket = this.tickets.get(id);
    if (!ticket) return undefined;
    
    const updatedTicket = { ...ticket, ...updates, updatedAt: new Date() };
    this.tickets.set(id, updatedTicket);
    return updatedTicket;
  }

  // Social Feeds
  async createSocialFeed(insertFeed: InsertSocialFeed): Promise<SocialFeed> {
    const id = randomUUID();
    const feed: SocialFeed = { ...insertFeed, id };
    this.socialFeeds.set(id, feed);
    return feed;
  }

  async getSocialFeed(id: string): Promise<SocialFeed | undefined> {
    return this.socialFeeds.get(id);
  }

  async getAllSocialFeeds(): Promise<SocialFeed[]> {
    return Array.from(this.socialFeeds.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  async getSocialFeedsByPlatform(platform: string): Promise<SocialFeed[]> {
    if (platform === "all") {
      return this.getAllSocialFeeds();
    }
    return Array.from(this.socialFeeds.values())
      .filter((feed) => feed.platform === platform)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async getSocialFeedsBySentiment(sentiment: string): Promise<SocialFeed[]> {
    return Array.from(this.socialFeeds.values()).filter(
      (feed) => feed.sentiment === sentiment
    );
  }

  // Presentations
  async createPresentation(insertPresentation: InsertPresentation): Promise<Presentation> {
    const id = randomUUID();
    const presentation: Presentation = { ...insertPresentation, id };
    this.presentations.set(id, presentation);
    return presentation;
  }

  async getPresentation(id: string): Promise<Presentation | undefined> {
    return this.presentations.get(id);
  }

  async getAllPresentations(): Promise<Presentation[]> {
    return Array.from(this.presentations.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
}

// Database storage implementation using PostgreSQL
export class DbStorage implements IStorage {
  private db;

  constructor() {
    const sql = neon(process.env.DATABASE_URL!);
    this.db = drizzle(sql);
  }

  // Analyses
  async createAnalysis(insertAnalysis: InsertAnalysis): Promise<Analysis> {
    const id = randomUUID();
    const [analysis] = await this.db
      .insert(analyses)
      .values({ ...insertAnalysis, id })
      .returning();
    return analysis;
  }

  async getAnalysis(id: string): Promise<Analysis | undefined> {
    const [analysis] = await this.db
      .select()
      .from(analyses)
      .where(eq(analyses.id, id));
    return analysis;
  }

  async getAllAnalyses(): Promise<Analysis[]> {
    return await this.db
      .select()
      .from(analyses)
      .orderBy(desc(analyses.uploadedAt));
  }

  async updateAnalysis(id: string, updates: Partial<Analysis>): Promise<Analysis | undefined> {
    const [updated] = await this.db
      .update(analyses)
      .set(updates)
      .where(eq(analyses.id, id))
      .returning();
    return updated;
  }

  // Reviews
  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = randomUUID();
    const [review] = await this.db
      .insert(reviews)
      .values({ ...insertReview, id })
      .returning();
    return review;
  }

  async getReview(id: string): Promise<Review | undefined> {
    const [review] = await this.db
      .select()
      .from(reviews)
      .where(eq(reviews.id, id));
    return review;
  }

  async getReviewsByAnalysis(analysisId: string): Promise<Review[]> {
    return await this.db
      .select()
      .from(reviews)
      .where(eq(reviews.analysisId, analysisId));
  }

  async getAllReviews(): Promise<Review[]> {
    return await this.db.select().from(reviews);
  }

  async getReviewsBySentiment(sentiment: string): Promise<Review[]> {
    if (sentiment === "all") {
      return this.getAllReviews();
    }
    return await this.db
      .select()
      .from(reviews)
      .where(eq(reviews.sentiment, sentiment));
  }

  async getTopReviews(limit: number, sentiment: "positive" | "negative"): Promise<Review[]> {
    if (sentiment === "positive") {
      return await this.db
        .select()
        .from(reviews)
        .where(eq(reviews.sentiment, "positive"))
        .orderBy(desc(reviews.sentimentScore))
        .limit(limit);
    } else {
      return await this.db
        .select()
        .from(reviews)
        .where(eq(reviews.sentiment, "negative"))
        .orderBy(reviews.sentimentScore)
        .limit(limit);
    }
  }

  // Tickets
  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const id = randomUUID();
    const now = new Date();
    const [ticket] = await this.db
      .insert(tickets)
      .values({ ...insertTicket, id, createdAt: now, updatedAt: now })
      .returning();
    return ticket;
  }

  async getTicket(id: string): Promise<Ticket | undefined> {
    const [ticket] = await this.db
      .select()
      .from(tickets)
      .where(eq(tickets.id, id));
    return ticket;
  }

  async getAllTickets(): Promise<Ticket[]> {
    return await this.db
      .select()
      .from(tickets)
      .orderBy(desc(tickets.createdAt));
  }

  async getTicketsByStatus(status: string): Promise<Ticket[]> {
    if (status === "all") {
      return this.getAllTickets();
    }
    return await this.db
      .select()
      .from(tickets)
      .where(eq(tickets.status, status));
  }

  async updateTicket(id: string, updates: Partial<Ticket>): Promise<Ticket | undefined> {
    const [ticket] = await this.db
      .update(tickets)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(tickets.id, id))
      .returning();
    return ticket;
  }

  // Social Feeds
  async createSocialFeed(insertFeed: InsertSocialFeed): Promise<SocialFeed> {
    const id = randomUUID();
    const [feed] = await this.db
      .insert(socialFeeds)
      .values({ ...insertFeed, id })
      .returning();
    return feed;
  }

  async getSocialFeed(id: string): Promise<SocialFeed | undefined> {
    const [feed] = await this.db
      .select()
      .from(socialFeeds)
      .where(eq(socialFeeds.id, id));
    return feed;
  }

  async getAllSocialFeeds(): Promise<SocialFeed[]> {
    return await this.db
      .select()
      .from(socialFeeds)
      .orderBy(desc(socialFeeds.timestamp));
  }

  async getSocialFeedsByPlatform(platform: string): Promise<SocialFeed[]> {
    if (platform === "all") {
      return this.getAllSocialFeeds();
    }
    return await this.db
      .select()
      .from(socialFeeds)
      .where(eq(socialFeeds.platform, platform))
      .orderBy(desc(socialFeeds.timestamp));
  }

  async getSocialFeedsBySentiment(sentiment: string): Promise<SocialFeed[]> {
    return await this.db
      .select()
      .from(socialFeeds)
      .where(eq(socialFeeds.sentiment, sentiment));
  }

  // Presentations
  async createPresentation(insertPresentation: InsertPresentation): Promise<Presentation> {
    const id = randomUUID();
    const [presentation] = await this.db
      .insert(presentations)
      .values({ ...insertPresentation, id })
      .returning();
    return presentation;
  }

  async getPresentation(id: string): Promise<Presentation | undefined> {
    const [presentation] = await this.db
      .select()
      .from(presentations)
      .where(eq(presentations.id, id));
    return presentation;
  }

  async getAllPresentations(): Promise<Presentation[]> {
    return await this.db
      .select()
      .from(presentations)
      .orderBy(desc(presentations.createdAt));
  }
}

export const storage = new DbStorage();
