// This file uses Hugging Face multilingual sentiment analysis model
// Model: tabularisai/multilingual-sentiment-analysis (23 languages supported)
// Free API hosted by Tabularis: https://api.tabularis.ai/
import OpenAI from "openai";
import pLimit from "p-limit";
import pRetry from "p-retry";

// Keep OpenAI for presentation generation only
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

// Helper function to check if error is rate limit or quota violation
function isRateLimitError(error: any): boolean {
  const errorMsg = error?.message || String(error);
  return (
    errorMsg.includes("429") ||
    errorMsg.includes("RATELIMIT_EXCEEDED") ||
    errorMsg.toLowerCase().includes("quota") ||
    errorMsg.toLowerCase().includes("rate limit")
  );
}

export interface SentimentResult {
  sentiment: "positive" | "negative" | "neutral";
  score: number; // 0-100
  confidence: number; // 0-1
}

// Map Hugging Face 5-class sentiment to our 3-class system
function mapHuggingFaceSentiment(label: string, score: number): SentimentResult {
  const labelMapping: Record<string, { sentiment: "positive" | "negative" | "neutral", scoreRange: [number, number] }> = {
    "LABEL_0": { sentiment: "negative", scoreRange: [0, 20] },          // Very Negative
    "LABEL_1": { sentiment: "negative", scoreRange: [20, 40] },         // Negative
    "LABEL_2": { sentiment: "neutral", scoreRange: [40, 60] },          // Neutral
    "LABEL_3": { sentiment: "positive", scoreRange: [60, 80] },         // Positive
    "LABEL_4": { sentiment: "positive", scoreRange: [80, 100] },        // Very Positive
    "Very Negative": { sentiment: "negative", scoreRange: [0, 20] },    // API returns full label names
    "Negative": { sentiment: "negative", scoreRange: [20, 40] },
    "Neutral": { sentiment: "neutral", scoreRange: [40, 60] },
    "Positive": { sentiment: "positive", scoreRange: [60, 80] },
    "Very Positive": { sentiment: "positive", scoreRange: [80, 100] },
  };

  const mapping = labelMapping[label] || labelMapping["Neutral"] || labelMapping["LABEL_2"]; // Default to neutral
  const [minScore, maxScore] = mapping.scoreRange;
  
  // Map confidence score to our 0-100 range within the sentiment's range
  const mappedScore = minScore + (maxScore - minScore) * score;

  return {
    sentiment: mapping.sentiment,
    score: Math.round(mappedScore),
    confidence: score,
  };
}

// Analyze a single piece of text for sentiment using Hugging Face model
export async function analyzeSentiment(text: string): Promise<SentimentResult> {
  try {
    console.log(`[Sentiment Analysis] Analyzing text: "${text.substring(0, 50)}..."`);
    
    // Use Hugging Face Inference API (2025 endpoint)
    const HF_API_URL = "https://router.huggingface.co/hf-inference/models/tabularisai/multilingual-sentiment-analysis";
    
    // Create AbortController for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

    const response = await fetch(HF_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
      },
      body: JSON.stringify({
        inputs: text,
        options: { wait_for_model: true }
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[Sentiment Analysis] API error ${response.status}: ${errorText}`);
      throw new Error(`Hugging Face API error: ${response.status}`);
    }

    const result = await response.json();
    console.log(`[Sentiment Analysis] API response:`, JSON.stringify(result).substring(0, 200));
    
    // Result format: [[{ "label": "Very Positive", "score": 0.95 }, ...]]
    // Extract the array of predictions (nested in outer array)
    const predictions = Array.isArray(result[0]) ? result[0] : result;
    
    if (predictions && predictions.length > 0) {
      // Sort by score and take the highest confidence prediction
      const sorted = [...predictions].sort((a, b) => b.score - a.score);
      const { label, score } = sorted[0];
      const mapped = mapHuggingFaceSentiment(label, score);
      console.log(`[Sentiment Analysis] Result: ${label} -> ${mapped.sentiment} (score: ${mapped.score}, confidence: ${score.toFixed(2)})`);
      return mapped;
    }

    // Fallback to neutral
    console.warn("[Sentiment Analysis] No results from API, using neutral fallback");
    return {
      sentiment: "neutral",
      score: 50,
      confidence: 0.5,
    };
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      console.error("[Sentiment Analysis] Request timeout after 30 seconds");
    } else {
      console.error("[Sentiment Analysis] Error:", error);
    }
    // Fallback to neutral sentiment on error
    return {
      sentiment: "neutral",
      score: 50,
      confidence: 0,
    };
  }
}

// Process multiple texts concurrently with rate limiting and automatic retries
export async function batchAnalyzeSentiment(texts: string[]): Promise<SentimentResult[]> {
  const limit = pLimit(2); // Process up to 2 requests concurrently
  
  const processingPromises = texts.map((text) =>
    limit(() =>
      pRetry(
        async () => {
          try {
            return await analyzeSentiment(text);
          } catch (error: any) {
            // Check if it's a rate limit error
            if (isRateLimitError(error)) {
              throw error; // Rethrow to trigger p-retry
            }
            // For non-rate-limit errors, throw immediately (don't retry)
            throw new pRetry.AbortError(error);
          }
        },
        {
          retries: 7,
          minTimeout: 2000,
          maxTimeout: 128000,
          factor: 2,
        }
      )
    )
  );
  
  return await Promise.all(processingPromises);
}

// Generate presentation slides based on analysis data
export async function generatePresentationSlides(data: {
  overallScore: number;
  positiveCount: number;
  negativeCount: number;
  neutralCount: number;
  totalReviews: number;
}): Promise<any[]> {
  try {
    console.log("[Presentation Generation] Starting with data:", data);
    
    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a business analyst creating stakeholder presentations. Generate 5 professional slides based on sentiment analysis data. 
          
          IMPORTANT: Return ONLY a JSON object with this EXACT structure:
          {
            "slides": [
              {
                "title": "Slide Title",
                "content": ["Bullet point 1", "Bullet point 2", "Bullet point 3"]
              }
            ]
          }
          
          Each slide MUST have:
          - A clear, professional title
          - 3-5 specific, data-driven bullet points with actual numbers from the metrics
          - Actionable insights, not generic statements`
        },
        {
          role: "user",
          content: `Create a 5-slide presentation using these ACTUAL metrics:
          
          CURRENT DATA:
          - Overall Sentiment Score: ${data.overallScore}/100
          - Total Reviews Analyzed: ${data.totalReviews.toLocaleString()}
          - Positive Reviews: ${data.positiveCount} (${Math.round((data.positiveCount/data.totalReviews)*100)}%)
          - Negative Reviews: ${data.negativeCount} (${Math.round((data.negativeCount/data.totalReviews)*100)}%)
          - Neutral Reviews: ${data.neutralCount} (${Math.round((data.neutralCount/data.totalReviews)*100)}%)
          
          Create slides covering:
          1. Executive Summary - Use the ACTUAL score ${data.overallScore}/100 and real percentages
          2. Sentiment Distribution - Show EXACT counts: ${data.positiveCount} positive, ${data.negativeCount} negative, ${data.neutralCount} neutral
          3. iPhone 17 Performance Analysis - Analyze strengths and areas for improvement based on sentiment data
          4. Key Findings - Data-driven insights from the ${data.totalReviews} reviews analyzed
          5. Recommended Actions - Specific next steps based on the ${data.negativeCount} negative reviews
          
          Use the REAL numbers provided above. Be specific and data-driven.`
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2000,
    });

    const result = JSON.parse(response.choices[0]?.message?.content || "{}");
    console.log("[Presentation Generation] GPT response:", JSON.stringify(result).substring(0, 300));
    
    // Ensure slides have the 'content' field (not 'bullets')
    const slides = (result.slides || []).map((slide: any) => ({
      title: slide.title,
      content: slide.content || slide.bullets || []
    }));
    
    console.log("[Presentation Generation] Generated", slides.length, "slides");
    return slides;
  } catch (error) {
    console.error("Presentation generation error:", error);
    // Return default slides on error
    return [
      {
        title: "Executive Summary",
        content: [
          `Overall Sentiment Score: ${data.overallScore}/100`,
          `Total Reviews Analyzed: ${data.totalReviews}`,
          `Positive Sentiment: ${Math.round((data.positiveCount/data.totalReviews)*100)}%`,
          `Areas for Improvement Identified: ${data.negativeCount}`,
        ]
      },
      {
        title: "Sentiment Distribution",
        content: [
          `${data.positiveCount} Positive Reviews (${Math.round((data.positiveCount/data.totalReviews)*100)}%)`,
          `${data.negativeCount} Negative Reviews (${Math.round((data.negativeCount/data.totalReviews)*100)}%)`,
          `${data.neutralCount} Neutral Reviews (${Math.round((data.neutralCount/data.totalReviews)*100)}%)`,
        ]
      },
      {
        title: "iPhone 17 Performance Analysis",
        content: [
          `Current sentiment score: ${data.overallScore}/100`,
          "Strong performance indicators in user feedback",
          "Key strengths: ecosystem integration, performance quality",
        ]
      },
      {
        title: "Key Insights",
        content: [
          "Strong positive sentiment around product quality",
          "Pricing concerns in negative reviews",
          "Customer service response time needs improvement",
        ]
      },
      {
        title: "Recommended Actions",
        content: [
          "Address top 3 negative review themes",
          "Enhance customer support response times",
          "Monitor competitive sentiment trends weekly",
        ]
      },
    ];
  }
}
