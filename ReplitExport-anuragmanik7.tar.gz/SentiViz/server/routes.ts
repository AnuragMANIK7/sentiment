import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import * as XLSX from "xlsx";
import { storage } from "./storage";
import { analyzeSentiment, batchAnalyzeSentiment, generatePresentationSlides } from "./openai";
import { extractLocation } from "./location";
import type { InsertReview } from "@shared/schema";

const upload = multer({ storage: multer.memoryStorage() });

// Helper function to safely parse dates from Excel data
function parseSafeDate(value: any): Date {
  if (!value) return new Date();
  
  const date = new Date(value);
  // Check if date is valid
  if (isNaN(date.getTime())) {
    return new Date(); // Return current date if invalid
  }
  return date;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Upload and analyze Excel file
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      // Parse Excel file
      const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(sheet) as any[];

      if (data.length === 0) {
        return res.status(400).json({ error: "Excel file is empty" });
      }

      // Extract text from reviews (assuming column names like 'review', 'comment', 'text', 'feedback')
      const textColumn = Object.keys(data[0]).find(key =>
        ['review', 'comment', 'text', 'feedback', 'content'].includes(key.toLowerCase())
      );

      if (!textColumn) {
        return res.status(400).json({
          error: "Could not find review text column. Please ensure your Excel has a column named 'review', 'comment', 'text', 'feedback', or 'content'"
        });
      }

      // Filter rows with valid review text and keep metadata aligned
      const validRows = data.filter(row => {
        const text = row[textColumn];
        return text && typeof text === 'string' && text.trim().length > 0;
      });

      if (validRows.length === 0) {
        return res.status(400).json({
          error: "No valid reviews found in the Excel file. Please ensure your review column contains text data."
        });
      }

      // Extract review texts from valid rows
      const reviews = validRows.map(row => row[textColumn]);

      // Create analysis record immediately with "processing" status
      const analysis = await storage.createAnalysis({
        fileName: req.file.originalname,
        uploadedAt: new Date(),
        totalReviews: reviews.length,
        overallSentiment: 50, // Placeholder until analysis completes
        positiveCount: 0,
        negativeCount: 0,
        neutralCount: 0,
        status: "processing",
        progress: 0,
      });

      // Return immediately so frontend can start polling for progress
      res.json(analysis);

      // Process sentiment analysis in background with progress updates
      (async () => {
        try {
          const batchSize = 10;
          const totalBatches = Math.ceil(reviews.length / batchSize);
          const sentiments: any[] = [];

          for (let i = 0; i < reviews.length; i += batchSize) {
            const batch = reviews.slice(i, i + batchSize);
            const batchResults = await batchAnalyzeSentiment(batch);
            sentiments.push(...batchResults);

            const progress = Math.round(((i + batch.length) / reviews.length) * 100);
            await storage.updateAnalysis(analysis.id, { progress });
          }

          // Calculate final statistics
          const positiveCount = sentiments.filter(s => s.sentiment === "positive").length;
          const negativeCount = sentiments.filter(s => s.sentiment === "negative").length;
          const neutralCount = sentiments.filter(s => s.sentiment === "neutral").length;
          const overallSentiment = sentiments.reduce((sum, s) => sum + s.score, 0) / sentiments.length;

          // Update analysis with final results
          await storage.updateAnalysis(analysis.id, {
            overallSentiment,
            positiveCount,
            negativeCount,
            neutralCount,
            status: "completed",
            progress: 100,
          });

          // Store individual reviews with correctly aligned metadata
          for (let i = 0; i < reviews.length; i++) {
            const row = validRows[i];
            const location = extractLocation(reviews[i]);
            const reviewInsert: InsertReview = {
              analysisId: analysis.id,
              content: reviews[i],
              sentiment: sentiments[i].sentiment,
              sentimentScore: sentiments[i].score,
              source: "excel",
              platform: req.file.originalname,
              author: row.author || row.name || "Anonymous",
              timestamp: parseSafeDate(row.date || row.timestamp),
              product: row.product || null,
              country: location.country,
              region: location.region,
            };
            await storage.createReview(reviewInsert);
          }
        } catch (error: any) {
          console.error("Background processing error:", error);
          await storage.updateAnalysis(analysis.id, {
            status: "failed",
            progress: 0,
          });
        }
      })();
    } catch (error: any) {
      console.error("Upload error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get all analyses
  app.get("/api/analyses", async (req, res) => {
    try {
      const analyses = await storage.getAllAnalyses();
      res.json(analyses);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get dashboard stats
  app.get("/api/stats", async (req, res) => {
    try {
      const reviews = await storage.getAllReviews();
      const positiveCount = reviews.filter(r => r.sentiment === "positive").length;
      const negativeCount = reviews.filter(r => r.sentiment === "negative").length;
      const neutralCount = reviews.filter(r => r.sentiment === "neutral").length;
      const totalReviews = reviews.length || 1; // Prevent division by zero
      
      const overallScore = reviews.length > 0
        ? reviews.reduce((sum, r) => sum + r.sentimentScore, 0) / reviews.length
        : 75;

      res.json({
        overallScore: Math.round(overallScore),
        positiveCount,
        negativeCount,
        neutralCount,
        positivePercent: Math.round((positiveCount / totalReviews) * 100),
        negativePercent: Math.round((negativeCount / totalReviews) * 100),
        neutralPercent: Math.round((neutralCount / totalReviews) * 100),
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get trend data
  app.get("/api/trends", async (req, res) => {
    try {
      // Get all reviews to calculate real trend data
      const allReviews = await storage.getAllReviews();
      
      // Create a map to group reviews by date
      const reviewsByDate = new Map<string, { positive: number, negative: number, neutral: number }>();
      
      // Initialize last 30 days with zero counts
      for (let i = 29; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        reviewsByDate.set(dateStr, { positive: 0, negative: 0, neutral: 0 });
      }
      
      // Group reviews by date and sentiment
      allReviews.forEach(review => {
        const reviewDate = new Date(review.timestamp);
        const dateStr = reviewDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        
        // Only include reviews from the last 30 days
        const daysDiff = Math.floor((Date.now() - reviewDate.getTime()) / (1000 * 60 * 60 * 24));
        if (daysDiff <= 29 && reviewsByDate.has(dateStr)) {
          const counts = reviewsByDate.get(dateStr)!;
          if (review.sentiment === "positive") counts.positive++;
          else if (review.sentiment === "negative") counts.negative++;
          else if (review.sentiment === "neutral") counts.neutral++;
        }
      });
      
      // Convert map to array format for chart
      const trendData = Array.from(reviewsByDate.entries()).map(([date, counts]) => ({
        date,
        ...counts
      }));
      
      res.json(trendData);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get top reviews (best and worst)
  app.get("/api/reviews/top", async (req, res) => {
    try {
      const best = await storage.getTopReviews(5, "positive");
      const worst = await storage.getTopReviews(5, "negative");
      
      res.json({ best, worst });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get all reviews
  app.get("/api/reviews", async (req, res) => {
    try {
      const { sentiment } = req.query;
      const reviews = sentiment
        ? await storage.getReviewsBySentiment(sentiment as string)
        : await storage.getAllReviews();
      
      res.json(reviews);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get all tickets
  app.get("/api/tickets", async (req, res) => {
    try {
      const { status } = req.query;
      const tickets = status
        ? await storage.getTicketsByStatus(status as string)
        : await storage.getAllTickets();
      
      // Join with reviews
      const ticketsWithReviews = await Promise.all(
        tickets.map(async (ticket) => {
          const review = await storage.getReview(ticket.reviewId);
          return { ...ticket, review };
        })
      );
      
      res.json(ticketsWithReviews);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create ticket
  app.post("/api/tickets", async (req, res) => {
    try {
      const { reviewId, priority, notes } = req.body;
      
      if (!reviewId || !priority) {
        return res.status(400).json({ error: "reviewId and priority are required" });
      }

      const ticket = await storage.createTicket({
        reviewId,
        priority,
        status: "open",
        assignedTo: null,
        createdAt: new Date(),
        updatedAt: new Date(),
        notes: notes || null,
      });

      res.json(ticket);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update ticket
  app.patch("/api/tickets/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const ticket = await storage.updateTicket(id, updates);
      
      if (!ticket) {
        return res.status(404).json({ error: "Ticket not found" });
      }
      
      res.json(ticket);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get social feeds
  app.get("/api/social-feeds", async (req, res) => {
    try {
      const { platform, sentiment, from, to } = req.query;
      
      let feeds = platform
        ? await storage.getSocialFeedsByPlatform(platform as string)
        : await storage.getAllSocialFeeds();
      
      if (sentiment && sentiment !== "all") {
        feeds = feeds.filter(feed => feed.sentiment === sentiment);
      }
      
      // Filter by date range
      if (from) {
        const fromDate = new Date(from as string);
        feeds = feeds.filter(feed => new Date(feed.timestamp) >= fromDate);
      }
      if (to) {
        const toDate = new Date(to as string);
        feeds = feeds.filter(feed => new Date(feed.timestamp) <= toDate);
      }
      
      res.json(feeds);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Trigger social media monitoring (fetch and analyze new posts)
  app.post("/api/social-monitor", async (req, res) => {
    try {
      const { fetchAndAnalyzeSocialFeeds } = await import("./social-monitor");
      
      console.log('Triggering social media monitoring...');
      const analyzedFeeds = await fetchAndAnalyzeSocialFeeds(20);
      
      // Store the analyzed feeds in the database
      for (const feed of analyzedFeeds) {
        const location = extractLocation(feed.content);
        await storage.createSocialFeed({
          platform: feed.platform,
          content: feed.content,
          sentiment: feed.sentiment,
          sentimentScore: feed.sentimentScore,
          author: feed.author,
          timestamp: feed.timestamp,
          url: feed.url,
          engagement: feed.engagement,
          product: feed.product,
          country: location.country,
          region: location.region,
        });
      }
      
      console.log(`Stored ${analyzedFeeds.length} social media posts`);
      res.json({ 
        success: true, 
        count: analyzedFeeds.length,
        message: `Successfully monitored and stored ${analyzedFeeds.length} posts` 
      });
    } catch (error: any) {
      console.error('Social monitoring error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get social media stats
  app.get("/api/social-stats", async (req, res) => {
    try {
      const feeds = await storage.getAllSocialFeeds();
      const positive = feeds.filter(f => f.sentiment === "positive").length;
      const negative = feeds.filter(f => f.sentiment === "negative").length;
      const neutral = feeds.filter(f => f.sentiment === "neutral").length;
      
      const platformCounts = {
        youtube: feeds.filter(f => f.platform === "youtube").length,
        news: feeds.filter(f => f.platform === "news").length,
      };
      
      res.json({
        positive,
        negative,
        neutral,
        platformCounts,
        trendingTopics: [
          { tag: "#iPhone17Pro", mentions: 1234 },
          { tag: "#TechReview", mentions: 567 },
          { tag: "#AppleEvent", mentions: 443 },
        ],
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get geographic distribution
  app.get("/api/analytics/geographic", async (req, res) => {
    try {
      const reviews = await storage.getAllReviews();
      const feeds = await storage.getAllSocialFeeds();
      
      // Combine all items with country data
      const allItems = [
        ...reviews.map(r => ({ country: r.country, region: r.region })),
        ...feeds.map(f => ({ country: f.country, region: f.region }))
      ];
      
      // Count mentions by country
      const countryCounts = new Map<string, number>();
      allItems.forEach(item => {
        if (item.country) {
          countryCounts.set(item.country, (countryCounts.get(item.country) || 0) + 1);
        }
      });
      
      // Convert to array and sort by count
      const countries = Array.from(countryCounts.entries())
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10); // Top 10 countries
      
      res.json(countries);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Generate presentation
  app.post("/api/presentations", async (req, res) => {
    try {
      const { title } = req.body;
      
      if (!title) {
        return res.status(400).json({ error: "Title is required" });
      }

      // Get current stats
      const reviews = await storage.getAllReviews();
      const positiveCount = reviews.filter(r => r.sentiment === "positive").length;
      const negativeCount = reviews.filter(r => r.sentiment === "negative").length;
      const neutralCount = reviews.filter(r => r.sentiment === "neutral").length;
      const totalReviews = reviews.length || 1;
      const overallScore = reviews.length > 0
        ? Math.round(reviews.reduce((sum, r) => sum + r.sentimentScore, 0) / reviews.length)
        : 75;

      // Generate slides using AI
      const slides = await generatePresentationSlides({
        overallScore,
        positiveCount,
        negativeCount,
        neutralCount,
        totalReviews,
      });

      const presentation = await storage.createPresentation({
        title,
        analysisId: null,
        createdAt: new Date(),
        slides: JSON.stringify(slides),
      });

      res.json(presentation);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get all presentations
  app.get("/api/presentations", async (req, res) => {
    try {
      const presentations = await storage.getAllPresentations();
      res.json(presentations);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get word frequency data for word cloud
  app.get("/api/analytics/wordcloud", async (req, res) => {
    try {
      const reviews = await storage.getAllReviews();
      const feeds = await storage.getAllSocialFeeds();
      
      // Combine all text from reviews and social feeds
      const allText = [
        ...reviews.map(r => r.content),
        ...feeds.map(f => f.content)
      ].join(' ');
      
      // Common stop words to filter out
      const stopWords = new Set([
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'been', 'be',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these',
        'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'what', 'which',
        'who', 'when', 'where', 'why', 'how', 'all', 'each', 'every', 'both',
        'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not',
        'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just', 'my', 'me',
        'about', 'into', 'through', 'during', 'before', 'after', 'above',
        'below', 'up', 'down', 'out', 'off', 'over', 'under', 'again', 'then',
        'there', 'here', 'one', 'two', 'its', 'their', 'them', 'your', 'our'
      ]);
      
      // Extract words and count frequencies
      const words = allText
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ') // Remove punctuation
        .split(/\s+/)
        .filter(word => word.length > 3 && !stopWords.has(word));
      
      const wordFreq = new Map<string, number>();
      words.forEach(word => {
        wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
      });
      
      // Convert to array and sort by frequency
      const wordData = Array.from(wordFreq.entries())
        .map(([text, value]) => ({ text, value }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 60); // Top 60 words
      
      res.json(wordData);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
