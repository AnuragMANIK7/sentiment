import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { socialFeeds } from "@shared/schema";
import { randomUUID } from "crypto";

const sql = neon(process.env.DATABASE_URL!);
const db = drizzle(sql);

const mockFeeds = [
  {
    platform: "twitter",
    content: "Just got the new iPhone 17! The camera quality is absolutely incredible. Best upgrade yet! #iPhone17",
    sentiment: "positive",
    sentimentScore: 92,
    author: "@techreview_mike",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    product: "iphone",
    engagement: 1234,
  },
  {
    platform: "twitter",
    content: "Disappointed with the battery life on Samsung Galaxy. Expected better performance for the price.",
    sentiment: "negative",
    sentimentScore: 32,
    author: "@gadgetfan_sara",
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
    product: "samsung",
    engagement: 456,
  },
  {
    platform: "youtube",
    content: "The display on the iPhone 17 is stunning, but the price is really steep. Not sure if worth the upgrade.",
    sentiment: "neutral",
    sentimentScore: 55,
    author: "TechReviews Daily",
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
    product: "iphone",
    engagement: 892,
  },
  {
    platform: "instagram",
    content: "Samsung Galaxy camera system is amazing for night photography! Highly recommend for photo enthusiasts.",
    sentiment: "positive",
    sentimentScore: 88,
    author: "photography_pro",
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    product: "samsung",
    engagement: 2341,
  },
  {
    platform: "news",
    content: "iPhone 17 sets new benchmark for smartphone performance according to latest industry tests.",
    sentiment: "positive",
    sentimentScore: 85,
    author: "Tech News Network",
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
    product: "iphone",
    engagement: 5678,
  },
];

async function seed() {
  console.log("Seeding social feeds...");
  
  for (const feed of mockFeeds) {
    await db.insert(socialFeeds).values({ ...feed, id: randomUUID() });
  }
  
  console.log("Seeding complete!");
}

seed().catch(console.error);
