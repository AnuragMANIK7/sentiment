// Social Media Monitoring Service
// Fetches real-time data from YouTube and NewsAPI for sentiment analysis

import { google } from 'googleapis';
// @ts-ignore - newsapi doesn't have type definitions
import NewsAPI from 'newsapi';
import { batchAnalyzeSentiment } from './openai';

// Lazy initialization to avoid crashes when API keys are missing
let youtube: any = null;
let newsapi: any = null;

function getYouTubeClient() {
  if (!youtube && process.env.YOUTUBE_API_KEY) {
    youtube = google.youtube({
      version: 'v3',
      auth: process.env.YOUTUBE_API_KEY,
    });
  }
  return youtube;
}

function getNewsAPIClient() {
  if (!newsapi && process.env.NEWS_API_KEY) {
    newsapi = new NewsAPI(process.env.NEWS_API_KEY);
  }
  return newsapi;
}

export interface SocialPost {
  platform: 'youtube' | 'news';
  content: string;
  author: string;
  timestamp: Date;
  url?: string;
  engagement?: number;
}

// Fetch recent YouTube comments about iPhone 17
export async function fetchYouTubeComments(maxResults: number = 20): Promise<SocialPost[]> {
  try {
    const youtube = getYouTubeClient();
    if (!youtube) {
      console.log('YouTube API key not configured, skipping...');
      return [];
    }

    const posts: SocialPost[] = [];
    
    // Expanded search queries for comprehensive iPhone 17 coverage
    const searchQueries = [
      'iPhone 17 review',
      'iPhone 17 Pro Max review',
      'iPhone 17 camera review',
      'iPhone 17 battery life',
      'iPhone 17 performance',
      'iPhone 17 unboxing',
      'iPhone 17 vs iPhone 16',
      'iPhone 17 features',
      'Best iPhone 2025'
    ];

    for (const query of searchQueries) {
      try {
        // Search for relevant videos (last 6 months for comprehensive data)
        const searchResponse = await youtube.search.list({
          part: ['id'],
          q: query,
          type: ['video'],
          maxResults: 3,
          order: 'relevance',
          publishedAfter: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(), // Last 6 months
        });

        const videoIds = searchResponse.data.items?.map(item => item.id?.videoId).filter(Boolean) || [];

        // Fetch comments for each video
        for (const videoId of videoIds) {
          if (!videoId) continue;
          
          try {
            const commentsResponse = await youtube.commentThreads.list({
              part: ['snippet'],
              videoId: videoId,
              maxResults: Math.min(5, Math.floor(maxResults / searchQueries.length)),
              order: 'relevance',
            });

            const comments = commentsResponse.data.items || [];
            
            for (const comment of comments) {
              const snippet = comment.snippet?.topLevelComment?.snippet;
              if (snippet?.textDisplay) {
                posts.push({
                  platform: 'youtube',
                  content: snippet.textDisplay.replace(/<[^>]*>/g, ''), // Strip HTML tags
                  author: snippet.authorDisplayName || 'Unknown',
                  timestamp: new Date(snippet.publishedAt || Date.now()),
                  url: `https://www.youtube.com/watch?v=${videoId}`,
                  engagement: snippet.likeCount || 0,
                });
              }
            }
          } catch (commentError) {
            console.error(`Error fetching comments for video ${videoId}:`, commentError);
          }
        }
      } catch (searchError) {
        console.error(`Error searching YouTube for "${query}":`, searchError);
      }
    }

    return posts.slice(0, maxResults);
  } catch (error) {
    console.error('YouTube API error:', error);
    return [];
  }
}

// Fetch recent news articles about iPhone 17
export async function fetchNewsArticles(maxResults: number = 20): Promise<SocialPost[]> {
  try {
    const newsapi = getNewsAPIClient();
    if (!newsapi) {
      console.log('News API key not configured, skipping...');
      return [];
    }

    const posts: SocialPost[] = [];
    
    // Expanded search queries for comprehensive iPhone 17 news coverage
    const queries = [
      'iPhone 17 review',
      'iPhone 17 Pro Max',
      'iPhone 17 release',
      'iPhone 17 features',
      'iPhone 17 camera',
      'iPhone 17 battery',
      'iPhone 17 price',
      'iPhone 17 announcement',
      'Apple iPhone 2025',
      'iPhone 17 technology'
    ];

    for (const query of queries) {
      try {
        const response = await newsapi.v2.everything({
          q: query,
          language: 'en',
          sortBy: 'publishedAt',
          pageSize: Math.min(8, Math.floor(maxResults / queries.length)),
          from: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(), // Last 6 months
        });

        const articles = response.articles || [];
        
        for (const article of articles) {
          // Combine title and description for better sentiment analysis
          const content = `${article.title || ''}. ${article.description || ''}`;
          
          if (content.trim()) {
            posts.push({
              platform: 'news',
              content: content,
              author: article.source?.name || article.author || 'Unknown',
              timestamp: new Date(article.publishedAt || Date.now()),
              url: article.url,
              engagement: 0,
            });
          }
        }
      } catch (queryError) {
        console.error(`Error fetching news for "${query}":`, queryError);
      }
    }

    return posts.slice(0, maxResults);
  } catch (error) {
    console.error('News API error:', error);
    return [];
  }
}

// Fetch and analyze social media posts from all enabled platforms
export async function fetchAndAnalyzeSocialFeeds(maxPerPlatform: number = 50) {
  try {
    console.log('Starting social media monitoring (fetching up to 6 months of data)...');

    // Fetch posts from all platforms in parallel (increased limits for 6 months of data)
    const [youtubePosts, newsPosts] = await Promise.all([
      fetchYouTubeComments(maxPerPlatform),
      fetchNewsArticles(maxPerPlatform),
    ]);

    const allPosts = [...youtubePosts, ...newsPosts];
    console.log(`Fetched ${allPosts.length} posts (YouTube: ${youtubePosts.length}, News: ${newsPosts.length})`);

    if (allPosts.length === 0) {
      return [];
    }

    // Analyze sentiment for all posts
    const texts = allPosts.map(post => post.content);
    const sentiments = await batchAnalyzeSentiment(texts);

    // Combine posts with sentiment analysis
    const analyzedFeeds = allPosts.map((post, index) => {
      const sentiment = sentiments[index];
      
      // Determine product category from content (iPhone 17 focus)
      let product: 'iphone' | 'other' = 'other';
      const contentLower = post.content.toLowerCase();
      
      if (contentLower.includes('iphone') || contentLower.includes('apple')) {
        product = 'iphone';
      }

      return {
        platform: post.platform,
        content: post.content,
        sentiment: sentiment.sentiment,
        sentimentScore: sentiment.score,
        author: post.author,
        timestamp: post.timestamp,
        url: post.url,
        engagement: post.engagement,
        product,
      };
    });

    console.log(`Analyzed ${analyzedFeeds.length} posts with sentiment`);
    return analyzedFeeds;
  } catch (error) {
    console.error('Error in fetchAndAnalyzeSocialFeeds:', error);
    return [];
  }
}
