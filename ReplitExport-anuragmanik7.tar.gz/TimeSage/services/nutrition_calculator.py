import math
from datetime import datetime, timedelta

class NutritionCalculator:
    """Advanced nutrition calculations and goal tracking"""
    
    def __init__(self):
        self.bmr_formula = "mifflin_st_jeor"  # More accurate than Harris-Benedict
        self.indian_macro_distribution = {
            "carbs": 0.55,  # Higher carbs for Indian diet
            "protein": 0.15,  # Adequate protein
            "fat": 0.30     # Healthy fat ratio
        }
    
    def calculate_bmr(self, weight_kg, height_cm, age_years, gender="male"):
        """Calculate Basal Metabolic Rate using Mifflin-St Jeor equation"""
        if gender.lower() == "male":
            bmr = (10 * weight_kg) + (6.25 * height_cm) - (5 * age_years) + 5
        else:
            bmr = (10 * weight_kg) + (6.25 * height_cm) - (5 * age_years) - 161
        
        return round(bmr, 1)
    
    def calculate_tdee(self, bmr, activity_level, additional_exercise_calories=0):
        """Calculate Total Daily Energy Expenditure"""
        activity_multipliers = {
            "sedentary": 1.2,           # Desk job, no exercise
            "lightly_active": 1.375,    # Light exercise 1-3 days/week
            "moderately_active": 1.55,  # Moderate exercise 3-5 days/week
            "very_active": 1.725,       # Hard exercise 6-7 days/week
            "extremely_active": 1.9     # Physical job + exercise
        }
        
        multiplier = activity_multipliers.get(activity_level.lower(), 1.2)
        tdee = bmr * multiplier + additional_exercise_calories
        
        return round(tdee, 1)
    
    def calculate_daily_targets(self, tdee, goal, goal_rate=0.5):
        """
        Calculate daily calorie and macro targets
        goal: 'maintain', 'lose', 'gain'
        goal_rate: kg per week (0.25, 0.5, 0.75, 1.0)
        """
        
        # 1 kg body weight = ~7700 calories
        weekly_calorie_adjustment = goal_rate * 7700
        daily_calorie_adjustment = weekly_calorie_adjustment / 7
        
        if goal.lower() == "lose":
            target_calories = tdee - daily_calorie_adjustment
        elif goal.lower() == "gain":
            target_calories = tdee + daily_calorie_adjustment
        else:
            target_calories = tdee
        
        # Ensure minimum calories for health
        target_calories = max(target_calories, 1200)
        
        # Calculate macro targets using Indian diet distribution
        target_carbs = (target_calories * self.indian_macro_distribution["carbs"]) / 4
        target_protein = (target_calories * self.indian_macro_distribution["protein"]) / 4
        target_fat = (target_calories * self.indian_macro_distribution["fat"]) / 9
        
        return {
            "calories": round(target_calories),
            "protein": round(target_protein, 1),
            "carbs": round(target_carbs, 1),
            "fat": round(target_fat, 1),
            "fiber": round(target_calories / 1000 * 25, 1)  # 25g per 1000 calories
        }
    
    def calculate_meal_distribution(self, daily_targets, meal_pattern="traditional_indian"):
        """Calculate calorie distribution across meals"""
        
        patterns = {
            "traditional_indian": {
                "breakfast": 0.25,      # Light breakfast
                "lunch": 0.40,          # Heavy lunch (main meal)
                "evening_snack": 0.10,  # Tea time snack
                "dinner": 0.25          # Light dinner
            },
            "modern_indian": {
                "breakfast": 0.30,
                "lunch": 0.35,
                "evening_snack": 0.10,
                "dinner": 0.25
            },
            "three_meals": {
                "breakfast": 0.25,
                "lunch": 0.40,
                "dinner": 0.35
            }
        }
        
        distribution = patterns.get(meal_pattern, patterns["traditional_indian"])
        meal_targets = {}
        
        for meal, percentage in distribution.items():
            meal_targets[meal] = {
                "calories": round(daily_targets["calories"] * percentage),
                "protein": round(daily_targets["protein"] * percentage, 1),
                "carbs": round(daily_targets["carbs"] * percentage, 1),
                "fat": round(daily_targets["fat"] * percentage, 1)
            }
        
        return meal_targets
    
    def analyze_macro_balance(self, consumed_nutrition, targets):
        """Analyze macro balance and provide insights"""
        
        analysis = {
            "calorie_status": self._get_status(consumed_nutrition.get("calories", 0), targets["calories"]),
            "protein_status": self._get_status(consumed_nutrition.get("protein", 0), targets["protein"]),
            "carbs_status": self._get_status(consumed_nutrition.get("carbs", 0), targets["carbs"]),
            "fat_status": self._get_status(consumed_nutrition.get("fat", 0), targets["fat"]),
            "fiber_status": self._get_status(consumed_nutrition.get("fiber", 0), targets.get("fiber", 25))
        }
        
        # Generate insights
        insights = self._generate_macro_insights(analysis, consumed_nutrition, targets)
        
        return {
            "status": analysis,
            "insights": insights,
            "recommendations": self._get_indian_food_recommendations(analysis)
        }
    
    def _get_status(self, consumed, target):
        """Get status of a macro relative to target"""
        if target == 0:
            return "unknown"
        
        percentage = (consumed / target) * 100
        
        if percentage < 50:
            return "very_low"
        elif percentage < 80:
            return "low"
        elif percentage <= 110:
            return "good"
        elif percentage <= 130:
            return "slightly_high"
        else:
            return "high"
    
    def _generate_macro_insights(self, analysis, consumed, targets):
        """Generate personalized insights based on macro analysis"""
        insights = []
        
        if analysis["calorie_status"] == "low":
            insights.append("🍽️ You're under your calorie goal. Consider adding healthy snacks like nuts or fruits.")
        elif analysis["calorie_status"] == "high":
            insights.append("⚠️ You've exceeded your calorie goal. Try smaller portions or lighter evening meals.")
        
        if analysis["protein_status"] == "low":
            insights.append("🥛 Low protein intake. Add more dal, paneer, eggs, or Greek yogurt to your meals.")
        
        if analysis["carbs_status"] == "low":
            insights.append("🌾 Low carb intake. Include more rice, roti, or fruits in your diet.")
        elif analysis["carbs_status"] == "high":
            insights.append("🌾 High carb intake. Consider reducing rice/roti portions and adding more vegetables.")
        
        if analysis["fat_status"] == "low":
            insights.append("🥑 Low healthy fat intake. Add nuts, seeds, or use ghee in moderation.")
        elif analysis["fat_status"] == "high":
            insights.append("🥑 High fat intake. Reduce oil/ghee in cooking and limit fried foods.")
        
        if analysis["fiber_status"] == "low":
            insights.append("🥬 Low fiber intake. Add more vegetables, fruits, and whole grains to your meals.")
        
        return insights
    
    def _get_indian_food_recommendations(self, analysis):
        """Get specific Indian food recommendations based on macro needs"""
        recommendations = []
        
        if analysis["protein_status"] in ["low", "very_low"]:
            recommendations.extend([
                "🥛 Add more dal varieties (moong, masoor, chana)",
                "🧀 Include paneer or tofu in curries",
                "🥚 Have boiled eggs as snacks",
                "🐟 Add fish curry (if non-vegetarian)"
            ])
        
        if analysis["carbs_status"] in ["low", "very_low"]:
            recommendations.extend([
                "🍚 Include brown rice or quinoa",
                "🫓 Have whole wheat rotis",
                "🍌 Add fruits like bananas or dates",
                "🥔 Include sweet potato or regular potatoes"
            ])
        
        if analysis["fat_status"] in ["low", "very_low"]:
            recommendations.extend([
                "🥥 Use coconut in South Indian dishes",
                "🌰 Snack on almonds, walnuts, or seeds",
                "🧈 Use ghee in moderation for cooking",
                "🥑 Add avocado to salads (if available)"
            ])
        
        if analysis["fiber_status"] in ["low", "very_low"]:
            recommendations.extend([
                "🥬 Include more leafy greens (palak, methi)",
                "🥒 Add cucumber and tomato salads",
                "🫘 Include rajma, chole, or other legumes",
                "🍎 Have whole fruits instead of juices"
            ])
        
        return recommendations[:6]  # Limit to 6 recommendations
    
    def calculate_weekly_progress(self, daily_logs, targets):
        """Calculate weekly nutrition progress"""
        if not daily_logs:
            return None
        
        # Calculate averages
        total_days = len(daily_logs)
        weekly_avg = {}
        
        for nutrient in ["calories", "protein", "carbs", "fat", "fiber"]:
            total = sum(day.get(nutrient, 0) for day in daily_logs)
            weekly_avg[nutrient] = round(total / total_days, 1)
        
        # Compare with targets
        weekly_analysis = {}
        for nutrient, avg_value in weekly_avg.items():
            target_value = targets.get(nutrient, 0)
            if target_value > 0:
                percentage = (avg_value / target_value) * 100
                weekly_analysis[nutrient] = {
                    "average": avg_value,
                    "target": target_value,
                    "percentage": round(percentage, 1),
                    "status": self._get_status(avg_value, target_value)
                }
        
        # Calculate consistency score
        consistency_score = self._calculate_consistency_score(daily_logs, targets)
        
        return {
            "weekly_averages": weekly_avg,
            "target_comparison": weekly_analysis,
            "consistency_score": consistency_score,
            "total_days_logged": total_days
        }
    
    def _calculate_consistency_score(self, daily_logs, targets):
        """Calculate how consistent user is with their nutrition goals"""
        if not daily_logs or not targets:
            return 0
        
        consistent_days = 0
        total_days = len(daily_logs)
        
        for day in daily_logs:
            # Count day as consistent if within 20% of targets for major macros
            calories_ok = abs(day.get("calories", 0) - targets["calories"]) <= (targets["calories"] * 0.2)
            protein_ok = abs(day.get("protein", 0) - targets["protein"]) <= (targets["protein"] * 0.2)
            
            if calories_ok and protein_ok:
                consistent_days += 1
        
        consistency_percentage = (consistent_days / total_days) * 100
        return round(consistency_percentage, 1)
    
    def predict_weight_change(self, avg_daily_calories, tdee, days=30):
        """Predict weight change based on calorie balance"""
        daily_surplus_deficit = avg_daily_calories - tdee
        total_surplus_deficit = daily_surplus_deficit * days
        
        # 7700 calories ≈ 1 kg body weight
        predicted_weight_change = total_surplus_deficit / 7700
        
        return {
            "weight_change_kg": round(predicted_weight_change, 2),
            "daily_balance": round(daily_surplus_deficit),
            "total_balance": round(total_surplus_deficit),
            "prediction_days": days
        }
