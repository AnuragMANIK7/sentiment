import json
from datetime import datetime

class RecipeBuilder:
    """Recipe builder for home-cooked Indian dishes with raw ingredient tracking"""
    
    def __init__(self, ifct_db):
        self.ifct_db = ifct_db
        self.recipe_templates = self._load_recipe_templates()
    
    def _load_recipe_templates(self):
        """Load common Indian recipe templates"""
        return {
            "basic_dal": {
                "name": "Basic Dal Template",
                "category": "Pulses",
                "base_ingredients": [
                    {"name": "Dal (any variety)", "amount": 100, "unit": "grams"},
                    {"name": "Water", "amount": 300, "unit": "ml"},
                    {"name": "Salt", "amount": 1, "unit": "tsp"},
                    {"name": "Turmeric", "amount": 0.5, "unit": "tsp"}
                ],
                "cooking_oil": {"amount": 1, "unit": "tsp"},
                "optional_ingredients": [
                    {"name": "Onion", "amount": 50, "unit": "grams"},
                    {"name": "Tomato", "amount": 50, "unit": "grams"},
                    {"name": "Ginger-garlic paste", "amount": 1, "unit": "tsp"},
                    {"name": "Cumin seeds", "amount": 0.5, "unit": "tsp"}
                ],
                "cooking_method": "Pressure cook dal, then temper with oil and spices",
                "servings": 2,
                "cooking_time": 20
            },
            "basic_sabzi": {
                "name": "Basic Vegetable Sabzi Template", 
                "category": "Vegetables",
                "base_ingredients": [
                    {"name": "Vegetables (mixed)", "amount": 200, "unit": "grams"},
                    {"name": "Salt", "amount": 0.5, "unit": "tsp"},
                    {"name": "Turmeric", "amount": 0.25, "unit": "tsp"}
                ],
                "cooking_oil": {"amount": 2, "unit": "tsp"},
                "optional_ingredients": [
                    {"name": "Onion", "amount": 50, "unit": "grams"},
                    {"name": "Tomato", "amount": 30, "unit": "grams"},
                    {"name": "Ginger-garlic paste", "amount": 0.5, "unit": "tsp"},
                    {"name": "Spice powder", "amount": 1, "unit": "tsp"}
                ],
                "cooking_method": "Sauté vegetables with oil and spices until tender",
                "servings": 2,
                "cooking_time": 15
            },
            "basic_curry": {
                "name": "Basic Curry Template",
                "category": "Curry",
                "base_ingredients": [
                    {"name": "Main ingredient (paneer/chicken/etc.)", "amount": 150, "unit": "grams"},
                    {"name": "Onion", "amount": 100, "unit": "grams"},
                    {"name": "Tomato", "amount": 100, "unit": "grams"},
                    {"name": "Salt", "amount": 0.5, "unit": "tsp"}
                ],
                "cooking_oil": {"amount": 3, "unit": "tsp"},
                "optional_ingredients": [
                    {"name": "Ginger-garlic paste", "amount": 1, "unit": "tsp"},
                    {"name": "Curry powder", "amount": 1, "unit": "tsp"},
                    {"name": "Water/stock", "amount": 100, "unit": "ml"},
                    {"name": "Cream/curd", "amount": 2, "unit": "tbsp"}
                ],
                "cooking_method": "Make base gravy with onion-tomato, add main ingredient",
                "servings": 2,
                "cooking_time": 25
            },
            "rice_preparation": {
                "name": "Basic Rice Template",
                "category": "Cereals",
                "base_ingredients": [
                    {"name": "Rice (basmati/regular)", "amount": 150, "unit": "grams"},
                    {"name": "Water", "amount": 300, "unit": "ml"},
                    {"name": "Salt", "amount": 0.5, "unit": "tsp"}
                ],
                "cooking_oil": {"amount": 1, "unit": "tsp"},
                "optional_ingredients": [
                    {"name": "Whole spices (bay leaf, etc.)", "amount": 1, "unit": "piece"},
                    {"name": "Ghee", "amount": 0.5, "unit": "tsp"}
                ],
                "cooking_method": "Boil rice in salted water until tender",
                "servings": 3,
                "cooking_time": 15
            }
        }
    
    def get_thali_templates(self):
        """Get common Indian thali combinations"""
        return {
            "north_indian_thali": {
                "name": "North Indian Thali",
                "components": [
                    {"type": "cereal", "items": ["2 medium rotis", "0.5 katori rice"]},
                    {"type": "pulse", "items": ["1 katori dal"]},
                    {"type": "vegetable", "items": ["1 katori mixed sabzi"]},
                    {"type": "dairy", "items": ["0.5 katori curd"]},
                    {"type": "other", "items": ["pickle", "papad"]}
                ],
                "estimated_calories": 650,
                "region": "North India"
            },
            "south_indian_thali": {
                "name": "South Indian Thali",
                "components": [
                    {"type": "cereal", "items": ["1 cup rice", "1 small dosa/idli"]},
                    {"type": "pulse", "items": ["1 katori sambar", "0.5 katori rasam"]},
                    {"type": "vegetable", "items": ["1 katori poriyal/kootu"]},
                    {"type": "dairy", "items": ["0.5 katori curd rice"]},
                    {"type": "other", "items": ["pickle", "papad", "coconut chutney"]}
                ],
                "estimated_calories": 680,
                "region": "South India"
            },
            "gujarati_thali": {
                "name": "Gujarati Thali",
                "components": [
                    {"type": "cereal", "items": ["2 small rotis", "0.5 katori rice"]},
                    {"type": "pulse", "items": ["1 katori dal", "0.5 katori kadhi"]},
                    {"type": "vegetable", "items": ["1 katori sabzi", "0.5 katori shaak"]},
                    {"type": "dairy", "items": ["0.5 katori curd"]},
                    {"type": "other", "items": ["jaggery", "pickle", "papad"]}
                ],
                "estimated_calories": 720,
                "region": "Gujarat"
            },
            "bengali_thali": {
                "name": "Bengali Thali",
                "components": [
                    {"type": "cereal", "items": ["1.5 cups rice"]},
                    {"type": "pulse", "items": ["1 katori dal"]},
                    {"type": "vegetable", "items": ["1 katori mixed vegetable curry"]},
                    {"type": "fish", "items": ["1 piece fish curry"]},
                    {"type": "dairy", "items": ["0.5 katori mishti doi"]},
                    {"type": "other", "items": ["pickle", "begun bhaja"]}
                ],
                "estimated_calories": 750,
                "region": "West Bengal"
            }
        }
    
    def create_recipe_from_template(self, template_id, customizations=None):
        """Create a recipe from template with customizations"""
        if template_id not in self.recipe_templates:
            return None
        
        template = self.recipe_templates[template_id].copy()
        
        if customizations:
            # Apply customizations
            if "servings" in customizations:
                # Scale ingredients based on serving size
                scale_factor = customizations["servings"] / template["servings"]
                template = self._scale_recipe(template, scale_factor)
            
            if "ingredients" in customizations:
                # Update specific ingredients
                template["base_ingredients"].extend(customizations["ingredients"])
            
            if "oil_amount" in customizations:
                template["cooking_oil"]["amount"] = customizations["oil_amount"]
        
        return template
    
    def _scale_recipe(self, recipe, scale_factor):
        """Scale recipe ingredients based on serving size"""
        scaled_recipe = recipe.copy()
        
        # Scale base ingredients
        for ingredient in scaled_recipe["base_ingredients"]:
            ingredient["amount"] = round(ingredient["amount"] * scale_factor, 1)
        
        # Scale optional ingredients
        for ingredient in scaled_recipe["optional_ingredients"]:
            ingredient["amount"] = round(ingredient["amount"] * scale_factor, 1)
        
        # Scale cooking oil
        scaled_recipe["cooking_oil"]["amount"] = round(
            scaled_recipe["cooking_oil"]["amount"] * scale_factor, 1
        )
        
        scaled_recipe["servings"] = round(recipe["servings"] * scale_factor)
        
        return scaled_recipe
    
    def calculate_recipe_nutrition(self, recipe):
        """Calculate total nutrition for a recipe"""
        total_nutrition = {
            "calories": 0,
            "protein": 0,
            "carbs": 0,
            "fat": 0,
            "fiber": 0
        }
        
        ingredient_details = []
        
        # Calculate nutrition for base ingredients
        for ingredient in recipe.get("base_ingredients", []):
            nutrition = self._get_ingredient_nutrition(ingredient)
            if nutrition:
                for key in total_nutrition:
                    total_nutrition[key] += nutrition[key]
                ingredient_details.append({
                    "name": ingredient["name"],
                    "amount": ingredient["amount"],
                    "unit": ingredient["unit"],
                    "nutrition": nutrition
                })
        
        # Add cooking oil calories
        oil_info = recipe.get("cooking_oil", {})
        if oil_info.get("amount", 0) > 0:
            oil_calories = oil_info["amount"] * 40  # ~40 calories per tsp
            oil_fat = oil_info["amount"] * 4.5  # ~4.5g fat per tsp
            total_nutrition["calories"] += oil_calories
            total_nutrition["fat"] += oil_fat
            
            ingredient_details.append({
                "name": "Cooking Oil",
                "amount": oil_info["amount"],
                "unit": oil_info.get("unit", "tsp"),
                "nutrition": {"calories": oil_calories, "fat": oil_fat, "protein": 0, "carbs": 0, "fiber": 0}
            })
        
        # Calculate per serving
        servings = recipe.get("servings", 1)
        per_serving = {}
        for key, value in total_nutrition.items():
            per_serving[key] = round(value / servings, 1)
        
        return {
            "total_nutrition": total_nutrition,
            "per_serving_nutrition": per_serving,
            "ingredient_breakdown": ingredient_details,
            "servings": servings
        }
    
    def _get_ingredient_nutrition(self, ingredient):
        """Get nutrition data for an ingredient"""
        ingredient_name = ingredient["name"].lower()
        amount = ingredient["amount"]
        unit = ingredient["unit"]
        
        # Convert to grams if needed
        if unit == "ml" and "water" not in ingredient_name:
            # For most liquid ingredients, assume density ~1g/ml
            amount_grams = amount
        elif unit == "ml" and "water" in ingredient_name:
            # Water has no calories
            return {"calories": 0, "protein": 0, "carbs": 0, "fat": 0, "fiber": 0}
        elif unit in ["tsp", "tbsp"]:
            # Convert spoon measurements
            if unit == "tsp":
                amount_grams = amount * 5  # 1 tsp ≈ 5g
            else:
                amount_grams = amount * 15  # 1 tbsp ≈ 15g
        else:
            amount_grams = amount
        
        # Try to find matching food in IFCT database
        search_results = self.ifct_db.search_food(ingredient_name)
        
        if search_results:
            # Use the first match
            food_id = search_results[0]["id"]
            nutrition = self.ifct_db.calculate_nutrition(food_id, amount_grams)
            if nutrition:
                return {
                    "calories": nutrition["calories"],
                    "protein": nutrition["protein"],
                    "carbs": nutrition["carbs"],
                    "fat": nutrition["fat"],
                    "fiber": nutrition["fiber"]
                }
        
        # Fallback: use generic estimates for common ingredients
        generic_nutrition = self._get_generic_nutrition(ingredient_name, amount_grams)
        return generic_nutrition
    
    def _get_generic_nutrition(self, ingredient_name, amount_grams):
        """Generic nutrition estimates for common ingredients not in IFCT"""
        
        # Common ingredients with approximate nutrition per 100g
        generic_data = {
            "onion": {"calories": 40, "protein": 1.1, "carbs": 9.3, "fat": 0.1, "fiber": 1.7},
            "tomato": {"calories": 18, "protein": 0.9, "carbs": 3.9, "fat": 0.2, "fiber": 1.2},
            "ginger": {"calories": 80, "protein": 1.8, "carbs": 18, "fat": 0.8, "fiber": 2.0},
            "garlic": {"calories": 149, "protein": 6.4, "carbs": 33, "fat": 0.5, "fiber": 2.1},
            "salt": {"calories": 0, "protein": 0, "carbs": 0, "fat": 0, "fiber": 0},
            "turmeric": {"calories": 354, "protein": 7.8, "carbs": 65, "fat": 9.9, "fiber": 21},
            "cumin": {"calories": 375, "protein": 18, "carbs": 44, "fat": 22, "fiber": 11},
            "water": {"calories": 0, "protein": 0, "carbs": 0, "fat": 0, "fiber": 0}
        }
        
        # Find matching ingredient
        for key, nutrition_per_100g in generic_data.items():
            if key in ingredient_name:
                # Scale nutrition based on amount
                multiplier = amount_grams / 100.0
                return {
                    "calories": round(nutrition_per_100g["calories"] * multiplier, 1),
                    "protein": round(nutrition_per_100g["protein"] * multiplier, 1),
                    "carbs": round(nutrition_per_100g["carbs"] * multiplier, 1),
                    "fat": round(nutrition_per_100g["fat"] * multiplier, 1),
                    "fiber": round(nutrition_per_100g["fiber"] * multiplier, 1)
                }
        
        # Default fallback
        return {"calories": 20, "protein": 1, "carbs": 4, "fat": 0, "fiber": 0}
    
    def save_custom_recipe(self, recipe_data):
        """Save a custom recipe for future use"""
        recipe_data["created_date"] = datetime.now().isoformat()
        recipe_data["id"] = f"custom_{int(datetime.now().timestamp())}"
        
        # Calculate and add nutrition
        nutrition = self.calculate_recipe_nutrition(recipe_data)
        recipe_data["nutrition"] = nutrition
        
        return recipe_data
    
    def get_recipe_suggestions(self, available_ingredients):
        """Suggest recipes based on available ingredients"""
        suggestions = []
        
        for template_id, template in self.recipe_templates.items():
            # Check if user has ingredients for this recipe
            base_ingredients = [ing["name"].lower() for ing in template["base_ingredients"]]
            user_ingredients = [ing.lower() for ing in available_ingredients]
            
            # Calculate match percentage
            matches = sum(1 for ing in base_ingredients if any(user_ing in ing for user_ing in user_ingredients))
            match_percentage = (matches / len(base_ingredients)) * 100 if base_ingredients else 0
            
            if match_percentage >= 50:  # At least 50% ingredient match
                suggestions.append({
                    "template_id": template_id,
                    "name": template["name"],
                    "match_percentage": round(match_percentage, 1),
                    "missing_ingredients": [ing for ing in base_ingredients 
                                          if not any(user_ing in ing for user_ing in user_ingredients)]
                })
        
        # Sort by match percentage
        suggestions.sort(key=lambda x: x["match_percentage"], reverse=True)
        return suggestions
