import streamlit as st
import plotly.graph_objects as go
from datetime import datetime, date

class GentleMode:
    """Gentle mode component for users who prefer ranges over exact numbers"""
    
    def __init__(self):
        self.range_categories = {
            "very_low": {"label": "Well Below", "color": "#FFE5E5", "icon": "🔽"},
            "low": {"label": "Below Range", "color": "#FFF3E0", "icon": "📉"},
            "good": {"label": "In Range", "color": "#E8F5E8", "icon": "✅"},
            "slightly_high": {"label": "Above Range", "color": "#FFF3E0", "icon": "📈"},
            "high": {"label": "Well Above", "color": "#FFE5E5", "icon": "🔼"}
        }
    
    def render_gentle_dashboard(self, user_data):
        """Render the complete gentle mode dashboard"""
        
        st.header("🧘 Gentle Mode - Focus on Balance, Not Perfection")
        st.markdown("*Your nutrition journey without the stress of exact numbers*")
        
        # Get today's data
        today = date.today().isoformat()
        today_meals = [meal for meal in user_data.get('logged_meals', []) 
                      if meal.get('date') == today]
        
        # Calculate today's totals
        today_totals = self._calculate_daily_totals(today_meals)
        
        # Get targets
        targets = {
            'calories': user_data.get('daily_calories', 2000),
            'protein': user_data.get('daily_protein', 150),
            'carbs': user_data.get('daily_carbs', 250),
            'fat': user_data.get('daily_fat', 67)
        }
        
        # Main gentle visualization
        self._render_balance_view(today_totals, targets)
        
        st.markdown("---")
        
        # Gentle insights
        self._render_gentle_insights(today_totals, targets, today_meals)
        
        st.markdown("---")
        
        # Habits tracking
        self._render_habits_tracking(user_data)
        
        st.markdown("---")
        
        # Weekly consistency
        self._render_weekly_consistency(user_data)
    
    def render_gentle_meal_view(self, meals):
        """Render meals in gentle mode format"""
        
        st.subheader("🍽️ Today's Eating Pattern")
        
        if not meals:
            st.info("🌱 Start your day by nourishing your body with wholesome foods!")
            return
        
        # Group meals by category
        meal_categories = {}
        for meal in meals:
            category = meal.get('meal_category', 'Other')
            if category not in meal_categories:
                meal_categories[category] = []
            meal_categories[category].append(meal)
        
        # Display in a more gentle way
        for category, category_meals in meal_categories.items():
            with st.expander(f"{self._get_meal_emoji(category)} {category} - {self._get_meal_balance_description(category_meals)}", expanded=False):
                
                for meal in category_meals:
                    st.write(f"🍽️ {meal.get('food_name', 'Food')}")
                    
                    # Show gentle feedback instead of exact numbers
                    calories = meal.get('calories', 0)
                    balance_desc = self._get_calorie_balance_description(calories)
                    st.caption(f"Energy: {balance_desc}")
    
    def _render_balance_view(self, totals, targets):
        """Render the gentle balance visualization"""
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Create gentle visualization
            fig = self._create_gentle_chart(totals, targets)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.subheader("🎯 Today's Balance")
            
            # Show status for each macro
            for macro in ['calories', 'protein', 'carbs', 'fat']:
                current = totals.get(macro, 0)
                target = targets.get(macro, 1)
                status = self._get_gentle_status(current, target)
                
                status_info = self.range_categories[status]
                st.markdown(f"**{macro.title()}:** {status_info['icon']} {status_info['label']}")
            
            # Overall day assessment
            st.markdown("---")
            overall_assessment = self._get_overall_assessment(totals, targets)
            st.markdown(f"**Today's Overall Balance:**\n{overall_assessment}")
    
    def _render_gentle_insights(self, totals, targets, meals):
        """Render gentle insights and encouragement"""
        
        st.subheader("💡 Gentle Insights")
        
        insights = self._generate_gentle_insights(totals, targets, meals)
        
        # Show insights in a supportive way
        for insight in insights:
            if insight['type'] == 'encouragement':
                st.success(insight['message'])
            elif insight['type'] == 'suggestion':
                st.info(insight['message'])
            elif insight['type'] == 'reminder':
                st.warning(insight['message'])
    
    def _render_habits_tracking(self, user_data):
        """Render habits tracking instead of precise metrics"""
        
        st.subheader("🌱 Building Healthy Habits")
        
        # Today's habit checklist
        habits = {
            "ate_breakfast": "🌅 Had a nourishing breakfast",
            "included_vegetables": "🥬 Included vegetables in meals",
            "stayed_hydrated": "💧 Drank enough water",
            "mindful_eating": "🧘 Ate mindfully and slowly",
            "balanced_meals": "⚖️ Had balanced, varied meals"
        }
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Today's Habits:**")
            
            for habit_key, habit_description in habits.items():
                checked = st.checkbox(
                    habit_description,
                    key=f"habit_{habit_key}",
                    value=st.session_state.get(f"habit_{habit_key}_today", False)
                )
                
                if checked:
                    st.session_state[f"habit_{habit_key}_today"] = True
        
        with col2:
            # Weekly habit score
            weekly_score = self._calculate_weekly_habit_score(user_data)
            
            st.write("**This Week's Progress:**")
            st.progress(weekly_score / 100)
            st.caption(f"You're building consistent habits! {weekly_score:.0f}% of goals achieved this week.")
            
            if weekly_score >= 80:
                st.success("🎉 Excellent consistency!")
            elif weekly_score >= 60:
                st.info("👍 Good progress, keep it up!")
            else:
                st.warning("💪 Every small step counts!")
    
    def _render_weekly_consistency(self, user_data):
        """Render weekly consistency in gentle terms"""
        
        st.subheader("📅 Weekly Consistency")
        
        meals = user_data.get('logged_meals', [])
        
        if len(meals) < 7:
            st.info("🌱 Keep logging your meals to see your consistency patterns!")
            return
        
        # Calculate days with logged meals in last 7 days
        from datetime import datetime, timedelta
        
        last_7_days = [(datetime.now() - timedelta(days=i)).date() for i in range(7)]
        logged_days = set()
        
        for meal in meals:
            meal_date = datetime.fromisoformat(meal['date']).date()
            if meal_date in last_7_days:
                logged_days.add(meal_date)
        
        consistency_days = len(logged_days)
        
        # Visual representation
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Days Logged", f"{consistency_days}/7")
        
        with col2:
            consistency_percentage = (consistency_days / 7) * 100
            st.metric("Consistency", f"{consistency_percentage:.0f}%")
        
        with col3:
            # Streak calculation
            streak = self._calculate_current_streak(meals)
            st.metric("Current Streak", f"{streak} days")
        
        # Encouragement based on consistency
        if consistency_days >= 6:
            st.success("🎉 Amazing consistency! You're building a strong healthy routine.")
        elif consistency_days >= 4:
            st.info("👍 Good consistency! Small daily actions lead to big results.")
        elif consistency_days >= 2:
            st.warning("💪 Building momentum! Remember, progress isn't always linear.")
        else:
            st.info("🌱 Every journey starts with a single step. You're already on the right path!")
        
        # Show gentle weekly pattern
        self._render_weekly_pattern(last_7_days, logged_days)
    
    def _create_gentle_chart(self, totals, targets):
        """Create a gentle, non-intimidating chart"""
        
        fig = go.Figure()
        
        macros = ['Calories', 'Protein', 'Carbs', 'Fat']
        statuses = []
        colors = []
        
        for macro in ['calories', 'protein', 'carbs', 'fat']:
            current = totals.get(macro, 0)
            target = targets.get(macro, 1)
            status = self._get_gentle_status(current, target)
            
            statuses.append(self.range_categories[status]['label'])
            colors.append(self.range_categories[status]['color'])
        
        # Create a simple, friendly bar chart
        fig.add_trace(go.Bar(
            x=macros,
            y=[1, 1, 1, 1],  # Equal height bars
            text=statuses,
            textposition='inside',
            marker_color=colors,
            showlegend=False
        ))
        
        fig.update_layout(
            title="Your Nutrition Balance Today",
            yaxis=dict(showticklabels=False, showgrid=False, zeroline=False),
            xaxis_title="Nutrition Categories",
            height=300,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def _calculate_daily_totals(self, meals):
        """Calculate total nutrition for the day"""
        totals = {
            'calories': sum(meal.get('calories', 0) for meal in meals),
            'protein': sum(meal.get('protein', 0) for meal in meals),
            'carbs': sum(meal.get('carbs', 0) for meal in meals),
            'fat': sum(meal.get('fat', 0) for meal in meals),
            'fiber': sum(meal.get('fiber', 0) for meal in meals)
        }
        return totals
    
    def _get_gentle_status(self, current, target):
        """Get gentle status category"""
        if target == 0:
            return "good"
        
        percentage = (current / target) * 100
        
        if percentage < 50:
            return "very_low"
        elif percentage < 80:
            return "low"
        elif percentage <= 120:
            return "good"
        elif percentage <= 140:
            return "slightly_high"
        else:
            return "high"
    
    def _generate_gentle_insights(self, totals, targets, meals):
        """Generate gentle, encouraging insights"""
        insights = []
        
        # Always start with encouragement
        if meals:
            insights.append({
                "type": "encouragement",
                "message": f"🌟 Great job logging {len(meals)} meals today! Every mindful choice matters."
            })
        
        # Gentle suggestions based on balance
        calories_status = self._get_gentle_status(totals.get('calories', 0), targets['calories'])
        protein_status = self._get_gentle_status(totals.get('protein', 0), targets['protein'])
        
        if calories_status == "low":
            insights.append({
                "type": "suggestion",
                "message": "🍽️ Your body might appreciate some additional nourishment today. Listen to your hunger cues!"
            })
        elif calories_status == "high":
            insights.append({
                "type": "reminder",
                "message": "🧘 Remember, it's okay to have days where you eat more. Tomorrow is a fresh start!"
            })
        
        if protein_status == "low":
            insights.append({
                "type": "suggestion",
                "message": "💪 Consider adding some protein-rich foods like dal, paneer, or yogurt to support your body."
            })
        
        # Hydration reminder
        current_hour = datetime.now().hour
        if current_hour > 14:  # After 2 PM
            insights.append({
                "type": "reminder",
                "message": "💧 Don't forget to stay hydrated! Your body will thank you."
            })
        
        # Evening encouragement
        if current_hour > 18:
            insights.append({
                "type": "encouragement",
                "message": "🌙 As your day winds down, appreciate the nourishing choices you made today."
            })
        
        return insights[:4]  # Limit to 4 insights
    
    def _get_overall_assessment(self, totals, targets):
        """Get overall day assessment in gentle terms"""
        
        statuses = []
        for macro in ['calories', 'protein', 'carbs', 'fat']:
            current = totals.get(macro, 0)
            target = targets.get(macro, 1)
            status = self._get_gentle_status(current, target)
            statuses.append(status)
        
        good_count = statuses.count('good')
        
        if good_count >= 3:
            return "🌟 **Beautifully Balanced** - You're nourishing your body well today!"
        elif good_count >= 2:
            return "✅ **Pretty Good Balance** - You're making mindful choices!"
        elif good_count >= 1:
            return "🌱 **Building Balance** - Every healthy choice is a step forward!"
        else:
            return "💚 **Learning and Growing** - Tomorrow is a new opportunity to nourish yourself!"
    
    def _get_meal_balance_description(self, meals):
        """Get gentle description of meal balance"""
        total_calories = sum(meal.get('calories', 0) for meal in meals)
        
        if total_calories < 200:
            return "Light and gentle"
        elif total_calories < 500:
            return "Moderately nourishing"
        elif total_calories < 800:
            return "Hearty and satisfying"
        else:
            return "Abundant and fulfilling"
    
    def _get_calorie_balance_description(self, calories):
        """Get gentle description of calorie content"""
        if calories < 100:
            return "Light energy boost"
        elif calories < 300:
            return "Moderate nourishment"
        elif calories < 500:
            return "Satisfying fuel"
        else:
            return "Hearty sustenance"
    
    def _get_meal_emoji(self, category):
        """Get emoji for meal category"""
        emojis = {
            'Breakfast': '🌅',
            'Lunch': '🌞', 
            'Dinner': '🌙',
            'Snacks': '🍎',
            'Other': '🍽️'
        }
        return emojis.get(category, '🍽️')
    
    def _calculate_weekly_habit_score(self, user_data):
        """Calculate weekly habit consistency score"""
        # This is a simplified calculation
        # In a real app, you'd track habits over time
        
        meals = user_data.get('logged_meals', [])
        
        # Count logged days in last 7 days
        from datetime import datetime, timedelta
        
        last_7_days = [(datetime.now() - timedelta(days=i)).date() for i in range(7)]
        logged_days = set()
        
        for meal in meals:
            try:
                meal_date = datetime.fromisoformat(meal['date']).date()
                if meal_date in last_7_days:
                    logged_days.add(meal_date)
            except:
                continue
        
        # Simple scoring based on consistency
        consistency_score = (len(logged_days) / 7) * 100
        
        # Add bonus for habit tracking (if implemented)
        habit_bonus = 0
        for habit_key in ['ate_breakfast', 'included_vegetables', 'stayed_hydrated']:
            if st.session_state.get(f"habit_{habit_key}_today", False):
                habit_bonus += 5
        
        return min(100, consistency_score + habit_bonus)
    
    def _calculate_current_streak(self, meals):
        """Calculate current logging streak"""
        if not meals:
            return 0
        
        # Sort meals by date
        sorted_meals = sorted(meals, key=lambda x: x.get('date', ''), reverse=True)
        
        # Count consecutive days
        from datetime import datetime, timedelta
        
        current_date = datetime.now().date()
        streak = 0
        
        # Get unique logged dates
        logged_dates = set()
        for meal in sorted_meals:
            try:
                meal_date = datetime.fromisoformat(meal['date']).date()
                logged_dates.add(meal_date)
            except:
                continue
        
        logged_dates = sorted(logged_dates, reverse=True)
        
        # Count streak
        for i, logged_date in enumerate(logged_dates):
            expected_date = current_date - timedelta(days=i)
            if logged_date == expected_date:
                streak += 1
            else:
                break
        
        return streak
    
    def _render_weekly_pattern(self, last_7_days, logged_days):
        """Render gentle weekly pattern visualization"""
        
        st.markdown("**This Week's Pattern:**")
        
        pattern_cols = st.columns(7)
        
        for i, day in enumerate(reversed(last_7_days)):
            with pattern_cols[i]:
                day_name = day.strftime("%a")
                
                if day in logged_days:
                    st.markdown(f"✅ **{day_name}**")
                elif day == datetime.now().date():
                    st.markdown(f"📍 **{day_name}**\n(Today)")
                else:
                    st.markdown(f"⭕ {day_name}")
        
        st.caption("✅ Logged day • ⭕ No log • 📍 Today")
