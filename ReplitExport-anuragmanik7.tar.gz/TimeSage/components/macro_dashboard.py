import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, date, timedelta
import pandas as pd

class MacroDashboard:
    """Interactive macro dashboard with rings, progress, and insights"""
    
    def render(self, user_data):
        """Render the complete macro dashboard"""
        
        # Get today's data
        today = date.today().isoformat()
        today_meals = [meal for meal in user_data.get('logged_meals', []) 
                      if meal.get('date') == today]
        
        # Calculate today's totals
        today_totals = self._calculate_daily_totals(today_meals)
        
        # Get targets
        targets = {
            'calories': user_data.get('daily_calories', 2000),
            'protein': user_data.get('daily_protein', 150),
            'carbs': user_data.get('daily_carbs', 250),
            'fat': user_data.get('daily_fat', 67)
        }
        
        # Header with date
        st.header(f"📊 Today's Nutrition Dashboard - {datetime.now().strftime('%B %d, %Y')}")
        
        # Main dashboard layout
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Macro rings visualization
            self._render_macro_rings(today_totals, targets, user_data.get('gentle_mode', False))
        
        with col2:
            # Quick stats and insights
            self._render_quick_stats(today_totals, targets, user_data.get('gentle_mode', False))
        
        # Meal breakdown section
        st.markdown("---")
        self._render_meal_breakdown(today_meals, user_data.get('gentle_mode', False))
        
        # Progress trends
        st.markdown("---")
        self._render_progress_trends(user_data)
        
        # Today's insights and recommendations
        st.markdown("---")
        self._render_daily_insights(today_totals, targets, today_meals)
    
    def _calculate_daily_totals(self, meals):
        """Calculate total nutrition for the day"""
        totals = {
            'calories': sum(meal.get('calories', 0) for meal in meals),
            'protein': sum(meal.get('protein', 0) for meal in meals),
            'carbs': sum(meal.get('carbs', 0) for meal in meals),
            'fat': sum(meal.get('fat', 0) for meal in meals),
            'fiber': sum(meal.get('fiber', 0) for meal in meals)
        }
        return totals
    
    def _render_macro_rings(self, totals, targets, gentle_mode):
        """Render interactive macro rings using Plotly"""
        
        # Create macro rings
        fig = go.Figure()
        
        if gentle_mode:
            # In gentle mode, show ranges instead of exact numbers
            self._add_gentle_rings(fig, totals, targets)
            st.subheader("🧘 Gentle Mode - Nutrition Ranges")
        else:
            self._add_precise_rings(fig, totals, targets)
            st.subheader("🎯 Macro Targets Progress")
        
        # Layout configuration
        fig.update_layout(
            showlegend=True,
            height=400,
            margin=dict(t=50, b=50, l=50, r=50),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)'
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    def _add_precise_rings(self, fig, totals, targets):
        """Add precise macro rings to the figure"""
        
        # Color scheme
        colors = {
            'calories': '#FF6B35',
            'protein': '#4ECDC4', 
            'carbs': '#45B7D1',
            'fat': '#96CEB4'
        }
        
        # Ring dimensions
        ring_width = 0.15
        center_x, center_y = 0, 0
        
        macros = ['calories', 'protein', 'carbs', 'fat']
        
        for i, macro in enumerate(macros):
            current = totals.get(macro, 0)
            target = targets.get(macro, 1)
            percentage = min((current / target) * 100, 100)
            
            # Outer radius for each ring
            outer_radius = 0.8 - (i * 0.18)
            inner_radius = outer_radius - ring_width
            
            # Background ring (full circle)
            fig.add_trace(go.Scatter(
                x=[center_x], y=[center_y],
                mode='markers',
                marker=dict(
                    size=outer_radius * 200,
                    color='rgba(200, 200, 200, 0.3)',
                    line=dict(width=ring_width * 200, color='rgba(200, 200, 200, 0.3)')
                ),
                showlegend=False,
                hoverinfo='skip'
            ))
            
            # Progress ring (arc based on percentage)
            if percentage > 0:
                # Create arc coordinates
                import numpy as np
                theta = np.linspace(0, 2 * np.pi * percentage / 100, max(int(percentage), 1))
                x_coords = outer_radius * np.cos(theta)
                y_coords = outer_radius * np.sin(theta)
                
                # Progress arc
                fig.add_trace(go.Scatter(
                    x=x_coords, y=y_coords,
                    mode='lines',
                    line=dict(width=ring_width * 200, color=colors[macro]),
                    name=f"{macro.title()}: {current:.0f}/{target:.0f}",
                    hovertemplate=f"<b>{macro.title()}</b><br>" +
                                  f"Current: {current:.1f}<br>" +
                                  f"Target: {target:.1f}<br>" +
                                  f"Progress: {percentage:.1f}%<extra></extra>"
                ))
        
        # Center text with total calories
        fig.add_annotation(
            x=0, y=0,
            text=f"<b>{totals.get('calories', 0):.0f}</b><br>calories",
            showarrow=False,
            font=dict(size=20, color="black"),
            align="center"
        )
    
    def _add_gentle_rings(self, fig, totals, targets):
        """Add gentle mode rings with ranges instead of exact numbers"""
        
        # Color scheme for gentle mode
        colors = {
            'calories': '#B8E6B8',
            'protein': '#B8D4E6', 
            'carbs': '#E6D4B8',
            'fat': '#E6B8D4'
        }
        
        macros = ['calories', 'protein', 'carbs', 'fat']
        
        for i, macro in enumerate(macros):
            current = totals.get(macro, 0)
            target = targets.get(macro, 1)
            
            # Create range categories
            if current < target * 0.7:
                status = "Low"
                color = colors[macro]
                opacity = 0.4
            elif current <= target * 1.2:
                status = "Good"
                color = colors[macro]
                opacity = 0.8
            else:
                status = "High"
                color = colors[macro]
                opacity = 0.6
            
            # Simple bar representation for gentle mode
            fig.add_trace(go.Bar(
                x=[macro.title()],
                y=[1],  # Normalized height
                name=f"{macro.title()}: {status}",
                marker_color=color,
                opacity=opacity,
                hovertemplate=f"<b>{macro.title()}</b><br>Status: {status}<extra></extra>"
            ))
        
        fig.update_layout(
            xaxis_title="Nutrition Categories",
            yaxis=dict(showticklabels=False, showgrid=False),
            bargap=0.3
        )
    
    def _render_quick_stats(self, totals, targets, gentle_mode):
        """Render quick statistics sidebar"""
        
        st.subheader("📈 Quick Stats")
        
        if gentle_mode:
            # Gentle mode stats
            st.markdown("### 🧘 Today's Balance")
            
            for macro in ['calories', 'protein', 'carbs', 'fat']:
                current = totals.get(macro, 0)
                target = targets.get(macro, 1)
                
                if current < target * 0.7:
                    status = "🔽 Below range"
                    color = "blue"
                elif current <= target * 1.2:
                    status = "✅ In range"
                    color = "green"
                else:
                    status = "🔼 Above range"
                    color = "orange"
                
                st.markdown(f"**{macro.title()}:** {status}")
        else:
            # Precise mode stats
            for macro in ['calories', 'protein', 'carbs', 'fat']:
                current = totals.get(macro, 0)
                target = targets.get(macro, 1)
                remaining = max(0, target - current)
                percentage = (current / target) * 100
                
                # Color based on progress
                if percentage >= 90:
                    color = "green"
                elif percentage >= 70:
                    color = "blue" 
                elif percentage >= 50:
                    color = "orange"
                else:
                    color = "red"
                
                # Format units
                if macro == 'calories':
                    unit = 'cal'
                else:
                    unit = 'g'
                
                st.metric(
                    label=f"{macro.title()} ({unit})",
                    value=f"{current:.0f}",
                    delta=f"{remaining:.0f} remaining" if remaining > 0 else "Target reached!",
                    delta_color="inverse" if remaining > 0 else "normal"
                )
        
        # Hydration reminder
        st.markdown("---")
        st.markdown("### 💧 Hydration")
        
        water_glasses = st.slider(
            "Water glasses today",
            min_value=0,
            max_value=12,
            value=st.session_state.get('water_glasses', 0),
            format="%d glasses"
        )
        
        st.session_state.water_glasses = water_glasses
        
        if water_glasses < 6:
            st.warning("💧 Aim for 8+ glasses of water daily!")
        else:
            st.success("🎉 Great hydration!")
    
    def _render_meal_breakdown(self, meals, gentle_mode):
        """Render meal-by-meal breakdown"""
        
        st.subheader("🍽️ Today's Meals")
        
        if not meals:
            st.info("🍽️ No meals logged today. Start by taking a photo or manually adding food!")
            return
        
        # Group meals by category
        meal_categories = {}
        for meal in meals:
            category = meal.get('meal_category', 'Other')
            if category not in meal_categories:
                meal_categories[category] = []
            meal_categories[category].append(meal)
        
        # Display each meal category
        for category, category_meals in meal_categories.items():
            with st.expander(f"{self._get_meal_emoji(category)} {category} ({len(category_meals)} items)", expanded=False):
                
                # Calculate category totals
                cat_calories = sum(meal.get('calories', 0) for meal in category_meals)
                cat_protein = sum(meal.get('protein', 0) for meal in category_meals)
                cat_carbs = sum(meal.get('carbs', 0) for meal in category_meals)
                cat_fat = sum(meal.get('fat', 0) for meal in category_meals)
                
                if gentle_mode:
                    st.markdown(f"**Total: ~{cat_calories:.0f} calories** (approximate)")
                else:
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Calories", f"{cat_calories:.0f}")
                    with col2:
                        st.metric("Protein", f"{cat_protein:.1f}g")
                    with col3:
                        st.metric("Carbs", f"{cat_carbs:.1f}g")
                    with col4:
                        st.metric("Fat", f"{cat_fat:.1f}g")
                
                # List individual items
                for i, meal in enumerate(category_meals):
                    col1, col2, col3 = st.columns([3, 1, 1])
                    
                    with col1:
                        st.write(f"**{meal.get('food_name', 'Unknown')}** - {meal.get('portion', '1 serving')}")
                        if meal.get('source') == 'photo_ai':
                            confidence = meal.get('confidence', 0.5)
                            conf_icon = "🟢" if confidence > 0.8 else "🟡" if confidence > 0.5 else "🔴"
                            st.caption(f"📸 Photo AI {conf_icon} {confidence:.0%} confidence")
                    
                    with col2:
                        if not gentle_mode:
                            st.write(f"⚡ {meal.get('calories', 0):.0f} cal")
                        else:
                            # Show range in gentle mode
                            cal_range = self._get_gentle_range(meal.get('calories', 0))
                            st.write(f"⚡ {cal_range}")
                    
                    with col3:
                        if st.button("🗑️", key=f"delete_{category}_{i}", help="Remove this item"):
                            # Remove from logged meals
                            if 'logged_meals' in st.session_state.user_data:
                                st.session_state.user_data['logged_meals'].remove(meal)
                            st.rerun()
    
    def _render_progress_trends(self, user_data):
        """Render weekly progress trends"""
        
        st.subheader("📈 Weekly Progress")
        
        meals = user_data.get('logged_meals', [])
        if len(meals) < 2:
            st.info("📊 Log meals for a few days to see your trends!")
            return
        
        # Create DataFrame for analysis
        df = pd.DataFrame(meals)
        df['date'] = pd.to_datetime(df['date'])
        
        # Last 7 days data
        seven_days_ago = datetime.now() - timedelta(days=7)
        recent_df = df[df['date'] >= seven_days_ago]
        
        if recent_df.empty:
            st.info("📊 No data in the last 7 days to show trends.")
            return
        
        # Group by date and sum nutrition
        daily_totals = recent_df.groupby('date').agg({
            'calories': 'sum',
            'protein': 'sum',
            'carbs': 'sum',
            'fat': 'sum'
        }).reset_index()
        
        # Calorie trend chart
        fig = px.line(
            daily_totals,
            x='date',
            y='calories',
            title='Daily Calorie Intake Trend',
            markers=True
        )
        
        # Add target line
        target_calories = user_data.get('daily_calories', 2000)
        fig.add_hline(
            y=target_calories,
            line_dash="dash",
            line_color="red",
            annotation_text=f"Target: {target_calories} cal"
        )
        
        fig.update_layout(height=300)
        st.plotly_chart(fig, use_container_width=True)
        
        # Weekly averages
        col1, col2, col3 = st.columns(3)
        
        avg_calories = daily_totals['calories'].mean()
        avg_protein = daily_totals['protein'].mean()
        avg_carbs = daily_totals['carbs'].mean()
        
        with col1:
            st.metric(
                "Weekly Avg Calories",
                f"{avg_calories:.0f}",
                delta=f"{avg_calories - target_calories:.0f} vs target"
            )
        with col2:
            target_protein = user_data.get('daily_protein', 150)
            st.metric(
                "Weekly Avg Protein",
                f"{avg_protein:.1f}g",
                delta=f"{avg_protein - target_protein:.1f}g vs target"
            )
        with col3:
            consistency = len(daily_totals)
            st.metric("Days Logged", f"{consistency}/7", delta=f"{consistency - 7} days")
    
    def _render_daily_insights(self, totals, targets, meals):
        """Render personalized daily insights and recommendations"""
        
        st.subheader("💡 Today's Insights")
        
        insights = []
        recommendations = []
        
        # Calorie analysis
        cal_percentage = (totals.get('calories', 0) / targets['calories']) * 100
        
        if cal_percentage < 70:
            insights.append("🍽️ **Under-eating**: You're significantly under your calorie goal today.")
            recommendations.append("Consider adding a healthy snack like nuts, fruits, or a protein smoothie.")
        elif cal_percentage > 120:
            insights.append("⚠️ **Over-target**: You've exceeded your calorie goal for today.")
            recommendations.append("Focus on vegetables and lighter options for remaining meals.")
        else:
            insights.append("✅ **Good balance**: Your calorie intake is on track today!")
        
        # Protein analysis
        protein_percentage = (totals.get('protein', 0) / targets['protein']) * 100
        
        if protein_percentage < 70:
            insights.append("💪 **Low protein**: Consider adding more protein-rich foods.")
            recommendations.append("Try adding dal, paneer, eggs, or yogurt to your next meal.")
        elif protein_percentage > 150:
            insights.append("💪 **High protein**: Great job meeting your protein goals!")
        
        # Indian food specific insights
        if meals:
            oil_heavy_meals = [m for m in meals if m.get('oil_ghee_tsp', 0) > 2]
            if len(oil_heavy_meals) > 2:
                insights.append("🛢️ **Oil-heavy day**: Multiple meals with high oil content detected.")
                recommendations.append("Consider steamed, boiled, or grilled options for your next meal.")
            
            # Photo AI vs manual ratio
            photo_meals = [m for m in meals if m.get('source') == 'photo_ai']
            if photo_meals and len(photo_meals) / len(meals) > 0.5:
                insights.append("📸 **AI-assisted logging**: Great job using photo logging for accuracy!")
        
        # Time-based recommendations
        current_hour = datetime.now().hour
        
        if current_hour < 12 and totals.get('calories', 0) < targets['calories'] * 0.3:
            recommendations.append("🌅 **Morning boost**: Consider a more substantial breakfast to fuel your day.")
        elif current_hour > 18 and totals.get('calories', 0) < targets['calories'] * 0.7:
            recommendations.append("🌆 **Evening catch-up**: You might need a larger dinner to meet your daily goals.")
        elif current_hour > 20 and cal_percentage < 90:
            recommendations.append("🌙 **Light evening**: Consider a small, protein-rich snack before bed.")
        
        # Display insights
        for insight in insights[:3]:  # Limit to 3 insights
            st.info(insight)
        
        # Display recommendations
        if recommendations:
            st.markdown("### 🎯 Recommendations")
            for rec in recommendations[:3]:  # Limit to 3 recommendations
                st.success(rec)
        
        # Motivational message
        if len(meals) > 0:
            st.balloons() if len(meals) >= 3 else None
            if len(meals) >= 3:
                st.success("🎉 Great job logging your meals today! Consistency is key to reaching your goals.")
            else:
                st.info("📝 Keep logging your meals to get more personalized insights!")
    
    def _get_meal_emoji(self, category):
        """Get emoji for meal category"""
        emojis = {
            'Breakfast': '🌅',
            'Lunch': '🌞', 
            'Dinner': '🌙',
            'Snacks': '🍎',
            'Other': '🍽️'
        }
        return emojis.get(category, '🍽️')
    
    def _get_gentle_range(self, value):
        """Convert exact value to gentle range"""
        if value < 100:
            return "50-150 cal"
        elif value < 300:
            return "150-350 cal"
        elif value < 500:
            return "350-550 cal"
        else:
            return "500+ cal"
