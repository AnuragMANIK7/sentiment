import streamlit as st
from PIL import Image
import io
import time

class PhotoUploader:
    """Component for uploading and analyzing food photos with AI"""
    
    def __init__(self, ai_analyzer):
        self.ai_analyzer = ai_analyzer
    
    def render(self):
        """Render the photo upload and analysis interface"""
        st.header("📸 Photo Food Logger")
        st.markdown("*Snap a photo of your meal for instant AI-powered nutrition analysis*")
        
        # Photo upload
        uploaded_file = st.file_uploader(
            "Choose a food image...",
            type=['jpg', 'jpeg', 'png'],
            help="Take a clear photo of your meal for best results"
        )
        
        if uploaded_file is not None:
            # Display the image
            image = Image.open(uploaded_file)
            
            col1, col2 = st.columns([1, 1])
            
            with col1:
                st.image(image, caption="Your meal", use_container_width=True)
                
                # Image quality check
                width, height = image.size
                file_size = len(uploaded_file.getvalue())
                
                st.caption(f"📐 Size: {width}×{height} pixels | 📁 {file_size/1024:.1f}KB")
                
                # Quality indicators
                if width < 300 or height < 300:
                    st.warning("⚠️ Image resolution is low. Consider taking a clearer photo for better accuracy.")
                elif file_size < 50000:  # 50KB
                    st.warning("⚠️ Image file is very small. This might affect analysis quality.")
                else:
                    st.success("✅ Good image quality for analysis")
            
            with col2:
                if st.button("🔍 Analyze Food", type="primary", use_container_width=True):
                    self._analyze_and_display(uploaded_file.getvalue())
                
                # Tips for better photos
                with st.expander("📷 Tips for Better Food Photos"):
                    st.markdown("""
                    **For accurate AI analysis:**
                    - 📱 Good lighting (natural light preferred)
                    - 🍽️ Show the entire plate/bowl
                    - 📏 Include reference objects (spoon, coin) for size
                    - 🎯 Focus clearly on the food
                    - 🔄 Take from slightly above (bird's eye view)
                    - 🥄 Separate different foods on the plate clearly
                    """)
        
        # Quick photo tips
        st.markdown("---")
        st.subheader("🤖 AI Analysis Features")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("""
            **🎯 Dual AI Models**
            - OpenAI GPT-5 for general food recognition
            - Anthropic Claude-4 for Indian cuisine expertise
            - Combined analysis for better accuracy
            """)
        
        with col2:
            st.markdown("""
            **🍛 Indian Food Focus**
            - Recognizes regional Indian dishes
            - Estimates cooking oil/ghee content
            - Understands Indian portion sizes
            """)
        
        with col3:
            st.markdown("""
            **📊 Smart Adjustments**
            - Oil/ghee slider for cooking methods
            - Portion confidence indicators
            - Manual corrections allowed
            """)
    
    def _analyze_and_display(self, image_bytes):
        """Analyze the image and display results"""
        
        # Show loading spinner
        with st.spinner("🤖 AI models analyzing your food..."):
            
            # Progress bar for user feedback
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            status_text.text("🔍 Initializing AI analysis...")
            progress_bar.progress(20)
            time.sleep(0.5)
            
            status_text.text("🧠 OpenAI analyzing image...")
            progress_bar.progress(40)
            
            # Analyze the image
            analysis_result = self.ai_analyzer.analyze_food_image(image_bytes)
            
            status_text.text("🍛 Claude analyzing Indian food details...")
            progress_bar.progress(70)
            time.sleep(0.5)
            
            status_text.text("🔄 Combining AI analyses...")
            progress_bar.progress(90)
            time.sleep(0.3)
            
            status_text.text("✅ Analysis complete!")
            progress_bar.progress(100)
            time.sleep(0.5)
            
            # Clear progress indicators
            progress_bar.empty()
            status_text.empty()
        
        # Display results
        if analysis_result.get("success", False):
            self._display_analysis_results(analysis_result)
        else:
            st.error("❌ AI analysis failed. Please try with a clearer image or use manual logging.")
            if "error" in analysis_result:
                st.error(f"Error details: {analysis_result['error']}")
    
    def _display_analysis_results(self, results):
        """Display the AI analysis results"""
        
        # Overall confidence and summary
        confidence = results.get("overall_confidence", 0.5)
        total_calories = results.get("total_estimated_calories", 0)
        
        # Confidence indicator
        confidence_color = "🔴" if confidence < 0.5 else "🟡" if confidence < 0.8 else "🟢"
        
        st.success(f"✅ **Analysis Complete!** {confidence_color} Confidence: {confidence:.1%}")
        
        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Calories", f"{total_calories:.0f}")
        with col2:
            st.metric("Food Items", len(results.get("food_items", [])))
        with col3:
            st.metric("Confidence", f"{confidence:.1%}")
        with col4:
            st.metric("AI Source", results.get("analysis_source", "unknown").title())
        
        # Detailed food breakdown
        st.subheader("🍽️ Identified Food Items")
        
        food_items = results.get("food_items", [])
        total_nutrition = {"calories": 0, "protein": 0, "carbs": 0, "fat": 0}
        
        for i, item in enumerate(food_items):
            with st.expander(f"🍛 {item.get('name', 'Unknown food')} - {item.get('estimated_calories', 0):.0f} cal", expanded=i==0):
                
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    st.write(f"**Category:** {item.get('category', 'Unknown')}")
                    st.write(f"**Portion Estimate:** {item.get('portion_estimate', 'Unknown')}")
                    st.write(f"**Cooking Method:** {item.get('cooking_method', 'Unknown')}")
                    st.write(f"**Oil/Ghee Estimate:** {item.get('oil_ghee_estimate', '1 tsp')}")
                    
                    # Item confidence
                    item_confidence = item.get('confidence', 0.5)
                    conf_color = "🔴" if item_confidence < 0.5 else "🟡" if item_confidence < 0.8 else "🟢"
                    st.write(f"**AI Confidence:** {conf_color} {item_confidence:.1%}")
                
                with col2:
                    # Nutrition breakdown
                    st.write("**Estimated Nutrition:**")
                    calories = item.get('estimated_calories', 0)
                    st.write(f"🔥 {calories:.0f} calories")
                    
                    # Add to total
                    total_nutrition['calories'] += calories
                
                # Oil/Ghee adjustment slider
                st.markdown("---")
                st.write("🛠️ **Adjust for Cooking Method:**")
                
                current_oil = item.get('oil_ghee_estimate', '1 tsp')
                oil_tsp = st.slider(
                    f"Oil/Ghee content for {item.get('name', 'this item')}",
                    min_value=0.0,
                    max_value=4.0,
                    value=1.0,
                    step=0.5,
                    format="%.1f tsp",
                    key=f"oil_slider_{i}",
                    help="Adjust based on your cooking method. Restaurant food typically uses 2-4 tsp per serving."
                )
                
                # Calculate adjusted calories
                base_calories = calories - 40  # Remove default 1 tsp oil calories
                adjusted_calories = base_calories + (oil_tsp * 40)  # Add selected oil calories
                
                if oil_tsp != 1.0:
                    st.info(f"Adjusted calories: {adjusted_calories:.0f} (was {calories:.0f})")
                
                # Save/Add button for this item
                if st.button(f"➕ Add {item.get('name', 'item')} to Log", key=f"add_item_{i}", type="secondary"):
                    self._add_to_meal_log(item, oil_tsp, adjusted_calories)
        
        # Cooking insights
        cooking_notes = results.get("cooking_notes", "")
        if cooking_notes:
            st.subheader("👨‍🍳 Cooking Analysis")
            st.info(cooking_notes)
        
        # Portion confidence explanation
        portion_conf = results.get("portion_confidence", "Medium")
        st.subheader("📏 Portion Estimation")
        
        if portion_conf == "High":
            st.success("🎯 **High Confidence**: Portions clearly visible with good reference points")
        elif portion_conf == "Medium":
            st.warning("⚖️ **Medium Confidence**: Portions estimated based on typical serving sizes")
        else:
            st.error("❓ **Low Confidence**: Difficult to estimate portions. Consider manual adjustment")
        
        # Manual correction option
        st.markdown("---")
        if st.button("✏️ Make Manual Corrections", type="secondary"):
            st.session_state.show_manual_corrections = True
            st.rerun()
        
        # Add all items at once
        st.markdown("---")
        if st.button("➕ Add All Items to Today's Log", type="primary", use_container_width=True):
            for item in food_items:
                self._add_to_meal_log(item, 1.0, item.get('estimated_calories', 0))
            
            st.success(f"✅ Added {len(food_items)} food items to your meal log!")
            time.sleep(1)
            st.rerun()
    
    def _add_to_meal_log(self, item, oil_tsp, calories):
        """Add a food item to the meal log"""
        
        # Get current meal time
        from datetime import datetime
        now = datetime.now()
        
        # Determine meal category based on time
        hour = now.hour
        if 5 <= hour < 10:
            meal_category = "Breakfast"
        elif 10 <= hour < 16:
            meal_category = "Lunch"
        elif 16 <= hour < 19:
            meal_category = "Snacks"
        else:
            meal_category = "Dinner"
        
        # Create meal entry
        meal_entry = {
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M"),
            "meal_category": meal_category,
            "food_name": item.get('name', 'Unknown food'),
            "portion": item.get('portion_estimate', '1 serving'),
            "calories": round(calories, 1),
            "protein": round(calories * 0.15 / 4, 1),  # Estimate protein
            "carbs": round(calories * 0.55 / 4, 1),    # Estimate carbs  
            "fat": round((calories * 0.30 + oil_tsp * 40) / 9, 1),  # Include oil in fat
            "oil_ghee_tsp": oil_tsp,
            "source": "photo_ai",
            "confidence": item.get('confidence', 0.5)
        }
        
        # Add to session state
        if 'logged_meals' not in st.session_state.user_data:
            st.session_state.user_data['logged_meals'] = []
        
        st.session_state.user_data['logged_meals'].append(meal_entry)
        
        st.success(f"✅ Added {item.get('name', 'food item')} to your {meal_category.lower()} log!")
