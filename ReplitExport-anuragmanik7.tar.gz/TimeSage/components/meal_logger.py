import streamlit as st
from datetime import datetime, date
import pandas as pd

class MealLogger:
    """Manual meal logging component with IFCT database and Indian portions"""
    
    def __init__(self, ifct_db, portions):
        self.ifct_db = ifct_db
        self.portions = portions
    
    def render(self):
        """Render the manual meal logging interface"""
        st.header("🍽️ Manual Meal Logger")
        st.markdown("*Log your meals manually with precise Indian portions and IFCT nutrition data*")
        
        # Quick add buttons for common foods
        self._render_quick_add_section()
        
        st.markdown("---")
        
        # Main logging interface
        col1, col2 = st.columns([2, 1])
        
        with col1:
            self._render_food_search_and_add()
        
        with col2:
            self._render_recent_foods()
        
        st.markdown("---")
        
        # Bulk add and saved meals
        self._render_bulk_add_section()
    
    def _render_quick_add_section(self):
        """Render quick add buttons for very common Indian foods"""
        st.subheader("⚡ Quick Add Common Foods")
        
        # Most common Indian foods based on Reddit findings
        quick_foods = [
            {"name": "Medium Roti", "food_id": "roti_wheat", "portion": "roti_medium", "qty": 1},
            {"name": "Rice (1 katori)", "food_id": "rice_boiled", "portion": "katori", "qty": 1},
            {"name": "Dal (1 katori)", "food_id": "dal_arhar", "portion": "katori", "qty": 1},
            {"name": "Curd (1 katori)", "food_id": "curd", "portion": "katori", "qty": 1},
            {"name": "Paneer Curry", "food_id": "palak_paneer", "portion": "katori", "qty": 1},
            {"name": "Aloo Sabzi", "food_id": "aloo_sabzi", "portion": "katori", "qty": 1}
        ]
        
        cols = st.columns(3)
        
        for i, food in enumerate(quick_foods):
            with cols[i % 3]:
                if st.button(f"➕ {food['name']}", key=f"quick_{i}", use_container_width=True):
                    self._quick_add_food(food)
    
    def _render_food_search_and_add(self):
        """Render food search and detailed adding interface"""
        st.subheader("🔍 Search & Add Foods")
        
        # Search functionality
        search_method = st.selectbox(
            "Search Method",
            ["🔤 Search by Name", "📂 Browse by Category", "⭐ My Favorites"]
        )
        
        if search_method == "🔤 Search by Name":
            self._render_name_search()
        elif search_method == "📂 Browse by Category":
            self._render_category_browse()
        else:
            self._render_favorites()
    
    def _render_name_search(self):
        """Render food name search interface"""
        search_query = st.text_input(
            "Search for food",
            placeholder="e.g., dal, roti, chicken curry, dosa...",
            help="Search for Indian foods by name"
        )
        
        if search_query and len(search_query) >= 2:
            # Search in IFCT database
            search_results = self.ifct_db.search_food(search_query)
            
            if search_results:
                st.write(f"Found {len(search_results)} results:")
                
                for result in search_results[:10]:  # Limit to 10 results
                    with st.expander(f"🍛 {result['name']} - {result['calories_per_100g']} cal/100g"):
                        self._render_food_add_interface(result['id'], result['name'])
            else:
                st.warning(f"No foods found for '{search_query}'. Try different keywords or browse by category.")
                
                # Suggest similar foods
                st.info("💡 **Try searching for:** dal, roti, rice, paneer, chicken, fish, sabzi, curry")
    
    def _render_category_browse(self):
        """Render category-based food browsing"""
        categories = self.ifct_db.get_categories()
        
        selected_category = st.selectbox(
            "Select Food Category",
            [""] + categories,
            format_func=lambda x: f"📂 {x}" if x else "Select a category..."
        )
        
        if selected_category:
            foods_in_category = self.ifct_db.get_foods_by_category(selected_category)
            
            st.write(f"**{selected_category}** ({len(foods_in_category)} items)")
            
            # Display foods in a more compact format
            for food in foods_in_category:
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.write(f"🍛 **{food['name']}**")
                with col2:
                    st.write(f"{food['calories_per_100g']} cal/100g")
                with col3:
                    if st.button("Add", key=f"cat_add_{food['id']}", type="secondary"):
                        self._show_add_interface(food['id'], food['name'])
    
    def _render_favorites(self):
        """Render user's favorite foods"""
        favorites = st.session_state.get('favorite_foods', [])
        
        if not favorites:
            st.info("⭐ No favorite foods yet! Add foods to your favorites by using the ⭐ button when logging meals.")
            return
        
        st.write("Your favorite foods:")
        
        for fav in favorites:
            col1, col2, col3 = st.columns([3, 1, 1])
            
            with col1:
                st.write(f"⭐ **{fav['name']}**")
            with col2:
                st.write(f"~{fav.get('avg_calories', 0):.0f} cal")
            with col3:
                if st.button("Add", key=f"fav_add_{fav['id']}", type="secondary"):
                    self._show_add_interface(fav['id'], fav['name'])
    
    def _render_food_add_interface(self, food_id, food_name):
        """Render detailed interface for adding a specific food"""
        food_data = self.ifct_db.get_food_by_id(food_id)
        if not food_data:
            st.error("Food data not found!")
            return
        
        st.markdown(f"**Adding: {food_name}**")
        
        # Get appropriate portion options for this food category
        category = food_data.get('category', 'Unknown')
        portion_options = self.portions.get_portion_options(category)
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Portion selection
            portion_names = []
            for portion_id in portion_options:
                portion_def = self.portions.portion_definitions.get(portion_id, {})
                portion_names.append(f"{portion_def.get('name', portion_id)}")
            
            selected_portion_idx = st.selectbox(
                "Portion Size",
                range(len(portion_names)),
                format_func=lambda x: portion_names[x],
                key=f"portion_{food_id}"
            )
            
            selected_portion_id = portion_options[selected_portion_idx]
            
            # Show portion description
            portion_desc = self.portions.get_portion_description(selected_portion_id)
            st.caption(portion_desc)
        
        with col2:
            # Quantity
            quantity = st.number_input(
                "Quantity",
                min_value=0.1,
                max_value=10.0,
                value=1.0,
                step=0.1,
                key=f"qty_{food_id}"
            )
        
        # Calculate portion in grams
        household_defaults = st.session_state.user_data.get('household_defaults', {})
        adjustment_factor = self.portions.get_household_adjustment_factor(selected_portion_id, household_defaults)
        
        portion_grams = self.portions.convert_portion_to_grams(selected_portion_id, quantity)
        adjusted_grams = portion_grams * adjustment_factor
        
        # Calculate nutrition
        nutrition = self.ifct_db.calculate_nutrition(food_id, adjusted_grams)
        
        if nutrition:
            # Show nutrition preview
            st.markdown("**Nutrition Preview:**")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Calories", f"{nutrition['calories']:.0f}")
            with col2:
                st.metric("Protein", f"{nutrition['protein']:.1f}g")
            with col3:
                st.metric("Carbs", f"{nutrition['carbs']:.1f}g")
            with col4:
                st.metric("Fat", f"{nutrition['fat']:.1f}g")
            
            # Oil/Ghee adjustment for cooked foods
            if category in ["Vegetables", "Curry", "Meat", "Fish"]:
                st.markdown("**Cooking Oil/Ghee Adjustment:**")
                oil_options = self.portions.get_oil_ghee_options()
                
                oil_level = st.select_slider(
                    "Oil content",
                    options=range(len(oil_options['oil_levels'])),
                    value=2,  # Default to "Normal oil"
                    format_func=lambda x: oil_options['oil_levels'][x]['label'],
                    key=f"oil_{food_id}"
                )
                
                oil_calories = oil_options['oil_levels'][oil_level]['calories']
                total_calories = nutrition['calories'] + oil_calories
                
                if oil_calories > 0:
                    st.info(f"🛢️ Added {oil_calories} calories from cooking oil. Total: {total_calories:.0f} calories")
                    nutrition['calories'] = total_calories
                    nutrition['fat'] += oil_options['oil_levels'][oil_level]['tsp'] * 4.5  # 4.5g fat per tsp oil
            
            # Meal category and timing
            col1, col2 = st.columns(2)
            
            with col1:
                meal_category = st.selectbox(
                    "Meal Category",
                    ["Breakfast", "Lunch", "Dinner", "Snacks"],
                    index=self._get_current_meal_index(),
                    key=f"meal_cat_{food_id}"
                )
            
            with col2:
                meal_time = st.time_input(
                    "Time",
                    value=datetime.now().time(),
                    key=f"meal_time_{food_id}"
                )
            
            # Add to log button
            col1, col2, col3 = st.columns([1, 1, 1])
            
            with col1:
                if st.button(f"➕ Add to Log", key=f"add_{food_id}", type="primary", use_container_width=True):
                    self._add_meal_to_log(nutrition, meal_category, meal_time, selected_portion_id, quantity, food_id)
            
            with col2:
                if st.button(f"⭐ Add to Favorites", key=f"fav_{food_id}", use_container_width=True):
                    self._add_to_favorites(food_id, food_name, nutrition['calories'])
            
            with col3:
                if st.button(f"📋 Copy Entry", key=f"copy_{food_id}", use_container_width=True):
                    self._copy_entry_to_clipboard(food_name, nutrition)
    
    def _render_recent_foods(self):
        """Render recently logged foods for quick re-adding"""
        st.subheader("🕐 Recent Foods")
        
        recent_meals = st.session_state.user_data.get('logged_meals', [])
        
        if not recent_meals:
            st.info("No recent foods. Start logging to see your frequently eaten items here!")
            return
        
        # Get unique recent foods (last 20 meals)
        recent_unique = {}
        for meal in reversed(recent_meals[-20:]):
            food_name = meal.get('food_name')
            if food_name and food_name not in recent_unique:
                recent_unique[food_name] = meal
        
        st.write("Quick re-add from recent meals:")
        
        for food_name, meal_data in list(recent_unique.items())[:8]:  # Show last 8 unique foods
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.write(f"🍽️ **{food_name}**")
                st.caption(f"~{meal_data.get('calories', 0):.0f} cal | {meal_data.get('portion', '1 serving')}")
            
            with col2:
                if st.button("Add", key=f"recent_{food_name}", type="secondary", use_container_width=True):
                    # Re-add the same meal
                    new_meal = meal_data.copy()
                    new_meal['date'] = date.today().isoformat()
                    new_meal['time'] = datetime.now().strftime("%H:%M")
                    
                    st.session_state.user_data['logged_meals'].append(new_meal)
                    st.success(f"✅ Added {food_name} to today's log!")
                    st.rerun()
    
    def _render_bulk_add_section(self):
        """Render bulk add and saved meals functionality"""
        st.subheader("🍱 Bulk Add & Saved Meals")
        
        tab1, tab2, tab3 = st.tabs(["🍱 Thali Templates", "💾 Saved Meals", "📝 Bulk Entry"])
        
        with tab1:
            self._render_thali_templates()
        
        with tab2:
            self._render_saved_meals()
        
        with tab3:
            self._render_bulk_entry()
    
    def _render_thali_templates(self):
        """Render Indian thali templates for quick meal logging"""
        from assets.thali_templates import ThaliTemplates
        
        thali_templates = ThaliTemplates()
        templates = thali_templates.get_all_templates()
        
        st.write("Quick add complete Indian meals:")
        
        for template_id, template in templates.items():
            with st.expander(f"🍽️ {template['name']} (~{template['estimated_calories']} cal)"):
                
                st.write(f"**Region:** {template['region']}")
                st.write("**Components:**")
                
                for component in template['components']:
                    items_text = ", ".join(component['items'])
                    st.write(f"• **{component['type'].title()}:** {items_text}")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    serving_size = st.selectbox(
                        "Serving Size",
                        ["Small (0.8x)", "Regular (1.0x)", "Large (1.2x)", "Extra Large (1.5x)"],
                        index=1,
                        key=f"thali_size_{template_id}"
                    )
                
                with col2:
                    meal_category = st.selectbox(
                        "Meal Time",
                        ["Lunch", "Dinner", "Breakfast"],
                        key=f"thali_meal_{template_id}"
                    )
                
                if st.button(f"➕ Add {template['name']}", key=f"add_thali_{template_id}", type="primary"):
                    self._add_thali_to_log(template, serving_size, meal_category)
    
    def _render_saved_meals(self):
        """Render saved meal combinations"""
        saved_meals = st.session_state.get('saved_meals', [])
        
        if not saved_meals:
            st.info("💾 No saved meals yet! Save your common meal combinations for quick logging.")
            
            # Show how to save meals
            st.markdown("""
            **How to save meals:**
            1. Log multiple food items
            2. Use the "Save as Meal" button in the dashboard
            3. Give it a name like "My usual breakfast"
            4. Re-use anytime with one click!
            """)
            return
        
        for i, saved_meal in enumerate(saved_meals):
            with st.expander(f"💾 {saved_meal['name']} (~{saved_meal['total_calories']:.0f} cal)"):
                
                st.write("**Items in this meal:**")
                for item in saved_meal['items']:
                    st.write(f"• {item['food_name']} - {item['portion']}")
                
                if st.button(f"➕ Add {saved_meal['name']}", key=f"add_saved_{i}", type="primary"):
                    self._add_saved_meal_to_log(saved_meal)
    
    def _render_bulk_entry(self):
        """Render bulk text entry for multiple foods"""
        st.write("Enter multiple foods at once (one per line):")
        st.caption("Format: Food name, portion (optional)")
        
        bulk_text = st.text_area(
            "Bulk Food Entry",
            placeholder="""Examples:
2 medium roti
1 katori dal
1 cup rice
paneer curry, 1 serving
curd, small bowl""",
            height=150
        )
        
        if bulk_text and st.button("🔍 Parse & Add Foods", type="primary"):
            self._process_bulk_entry(bulk_text)
    
    def _quick_add_food(self, food_data):
        """Quickly add a pre-defined food"""
        # Get portion in grams
        portion_grams = self.portions.convert_portion_to_grams(food_data['portion'], food_data['qty'])
        
        # Calculate nutrition
        nutrition = self.ifct_db.calculate_nutrition(food_data['food_id'], portion_grams)
        
        if nutrition:
            # Determine current meal
            meal_category = self._get_current_meal_category()
            
            # Create meal entry
            meal_entry = {
                "date": date.today().isoformat(),
                "time": datetime.now().strftime("%H:%M"),
                "meal_category": meal_category,
                "food_name": nutrition['food_name'],
                "portion": f"{food_data['qty']} {self.portions.portion_definitions[food_data['portion']]['name']}",
                "calories": nutrition['calories'],
                "protein": nutrition['protein'],
                "carbs": nutrition['carbs'],
                "fat": nutrition['fat'],
                "fiber": nutrition['fiber'],
                "source": "manual_quick",
                "food_id": food_data['food_id']
            }
            
            # Add to logged meals
            if 'logged_meals' not in st.session_state.user_data:
                st.session_state.user_data['logged_meals'] = []
            
            st.session_state.user_data['logged_meals'].append(meal_entry)
            
            st.success(f"✅ Added {food_data['name']} to your {meal_category.lower()} log!")
            st.rerun()
    
    def _show_add_interface(self, food_id, food_name):
        """Show detailed add interface in a modal-like expander"""
        with st.expander(f"Add {food_name}", expanded=True):
            self._render_food_add_interface(food_id, food_name)
    
    def _add_meal_to_log(self, nutrition, meal_category, meal_time, portion_id, quantity, food_id):
        """Add a meal entry to the log"""
        
        # Create portion description
        portion_name = self.portions.portion_definitions.get(portion_id, {}).get('name', 'serving')
        portion_desc = f"{quantity} {portion_name}" if quantity != 1 else portion_name
        
        meal_entry = {
            "date": date.today().isoformat(),
            "time": meal_time.strftime("%H:%M"),
            "meal_category": meal_category,
            "food_name": nutrition['food_name'],
            "portion": portion_desc,
            "calories": nutrition['calories'],
            "protein": nutrition['protein'],
            "carbs": nutrition['carbs'],
            "fat": nutrition['fat'],
            "fiber": nutrition['fiber'],
            "source": "manual_detailed",
            "food_id": food_id,
            "portion_grams": nutrition['portion_grams']
        }
        
        # Add to logged meals
        if 'logged_meals' not in st.session_state.user_data:
            st.session_state.user_data['logged_meals'] = []
        
        st.session_state.user_data['logged_meals'].append(meal_entry)
        
        st.success(f"✅ Added {nutrition['food_name']} to your {meal_category.lower()} log!")
        st.rerun()
    
    def _add_to_favorites(self, food_id, food_name, avg_calories):
        """Add food to favorites"""
        if 'favorite_foods' not in st.session_state:
            st.session_state.favorite_foods = []
        
        # Check if already in favorites
        existing = [f for f in st.session_state.favorite_foods if f['id'] == food_id]
        if existing:
            st.warning("⭐ Already in favorites!")
            return
        
        favorite = {
            'id': food_id,
            'name': food_name,
            'avg_calories': avg_calories
        }
        
        st.session_state.favorite_foods.append(favorite)
        st.success(f"⭐ Added {food_name} to favorites!")
    
    def _copy_entry_to_clipboard(self, food_name, nutrition):
        """Copy nutrition info to clipboard (simulation)"""
        nutrition_text = f"{food_name}: {nutrition['calories']:.0f} cal, {nutrition['protein']:.1f}g protein, {nutrition['carbs']:.1f}g carbs, {nutrition['fat']:.1f}g fat"
        st.info(f"📋 Copied to clipboard: {nutrition_text}")
    
    def _get_current_meal_index(self):
        """Get current meal index based on time"""
        hour = datetime.now().hour
        if 5 <= hour < 10:
            return 0  # Breakfast
        elif 10 <= hour < 16:
            return 1  # Lunch
        elif 16 <= hour < 19:
            return 3  # Snacks
        else:
            return 2  # Dinner
    
    def _get_current_meal_category(self):
        """Get current meal category based on time"""
        categories = ["Breakfast", "Lunch", "Dinner", "Snacks"]
        return categories[self._get_current_meal_index()]
    
    def _add_thali_to_log(self, template, serving_size, meal_category):
        """Add a complete thali to the meal log"""
        # Parse serving size multiplier
        multiplier = 1.0
        if "0.8x" in serving_size:
            multiplier = 0.8
        elif "1.2x" in serving_size:
            multiplier = 1.2
        elif "1.5x" in serving_size:
            multiplier = 1.5
        
        # Calculate scaled calories
        total_calories = template['estimated_calories'] * multiplier
        
        # Create a single thali entry
        meal_entry = {
            "date": date.today().isoformat(),
            "time": datetime.now().strftime("%H:%M"),
            "meal_category": meal_category,
            "food_name": f"{template['name']} ({serving_size})",
            "portion": "1 complete thali",
            "calories": round(total_calories, 1),
            "protein": round(total_calories * 0.15 / 4, 1),  # Estimate
            "carbs": round(total_calories * 0.55 / 4, 1),    # Estimate
            "fat": round(total_calories * 0.30 / 9, 1),      # Estimate
            "fiber": round(total_calories / 1000 * 25, 1),   # Estimate
            "source": "thali_template",
            "template_id": template.get('id', 'unknown')
        }
        
        # Add to logged meals
        if 'logged_meals' not in st.session_state.user_data:
            st.session_state.user_data['logged_meals'] = []
        
        st.session_state.user_data['logged_meals'].append(meal_entry)
        
        st.success(f"✅ Added {template['name']} to your {meal_category.lower()} log!")
        st.rerun()
    
    def _add_saved_meal_to_log(self, saved_meal):
        """Add a saved meal combination to the log"""
        current_time = datetime.now()
        meal_category = self._get_current_meal_category()
        
        # Add each item in the saved meal
        for item in saved_meal['items']:
            meal_entry = item.copy()
            meal_entry['date'] = date.today().isoformat()
            meal_entry['time'] = current_time.strftime("%H:%M")
            meal_entry['meal_category'] = meal_category
            meal_entry['source'] = "saved_meal"
            
            st.session_state.user_data['logged_meals'].append(meal_entry)
        
        st.success(f"✅ Added {saved_meal['name']} to your {meal_category.lower()} log!")
        st.rerun()
    
    def _process_bulk_entry(self, bulk_text):
        """Process bulk text entry for multiple foods"""
        lines = [line.strip() for line in bulk_text.split('\n') if line.strip()]
        
        successful_adds = 0
        failed_items = []
        
        for line in lines:
            # Parse line: "food name, portion" or just "food name"
            parts = [part.strip() for part in line.split(',')]
            food_name = parts[0]
            portion_text = parts[1] if len(parts) > 1 else "1 serving"
            
            # Search for food in database
            search_results = self.ifct_db.search_food(food_name)
            
            if search_results:
                # Use first match
                food_id = search_results[0]['id']
                
                # Estimate portion in grams (simplified)
                estimated_grams = 150  # Default portion
                
                # Calculate nutrition
                nutrition = self.ifct_db.calculate_nutrition(food_id, estimated_grams)
                
                if nutrition:
                    # Add to log
                    meal_entry = {
                        "date": date.today().isoformat(),
                        "time": datetime.now().strftime("%H:%M"),
                        "meal_category": self._get_current_meal_category(),
                        "food_name": nutrition['food_name'],
                        "portion": portion_text,
                        "calories": nutrition['calories'],
                        "protein": nutrition['protein'],
                        "carbs": nutrition['carbs'],
                        "fat": nutrition['fat'],
                        "fiber": nutrition['fiber'],
                        "source": "bulk_entry"
                    }
                    
                    st.session_state.user_data['logged_meals'].append(meal_entry)
                    successful_adds += 1
                else:
                    failed_items.append(food_name)
            else:
                failed_items.append(food_name)
        
        # Show results
        if successful_adds > 0:
            st.success(f"✅ Successfully added {successful_adds} items!")
        
        if failed_items:
            st.warning(f"⚠️ Could not find: {', '.join(failed_items)}")
        
        if successful_adds > 0:
            st.rerun()
