from datetime import datetime

class ThaliTemplates:
    """Indian thali templates for quick complete meal logging"""
    
    def __init__(self):
        self.templates = self._load_thali_templates()
    
    def _load_thali_templates(self):
        """Load comprehensive Indian thali templates"""
        return {
            "north_indian_veg": {
                "id": "north_indian_veg",
                "name": "North Indian Vegetarian Thali",
                "region": "North India",
                "meal_type": "lunch_dinner",
                "estimated_calories": 650,
                "description": "Traditional North Indian vegetarian complete meal",
                "components": [
                    {
                        "type": "grains",
                        "items": ["2 medium rotis (wheat)", "0.5 katori basmati rice"],
                        "calories": 280,
                        "carbs": 58,
                        "protein": 8
                    },
                    {
                        "type": "proteins",
                        "items": ["1 katori dal (arhar/moong)", "0.5 katori curd"],
                        "calories": 200,
                        "protein": 14,
                        "carbs": 20
                    },
                    {
                        "type": "vegetables",
                        "items": ["1 katori mixed sabzi", "small portion achar"],
                        "calories": 120,
                        "carbs": 15,
                        "fiber": 5
                    },
                    {
                        "type": "accompaniments",
                        "items": ["1 papad", "small portion ghee/oil"],
                        "calories": 50,
                        "fat": 5
                    }
                ],
                "nutrition_breakdown": {
                    "calories": 650,
                    "protein": 22,
                    "carbs": 93,
                    "fat": 18,
                    "fiber": 12
                },
                "cooking_notes": "Moderate oil usage, traditional spices",
                "dietary_tags": ["vegetarian", "traditional", "balanced"],
                "region_variations": {
                    "punjabi": "Extra ghee, makki roti option",
                    "rajasthani": "Dal baati, extra spice",
                    "haryanvi": "Bajra roti, lassi instead of curd"
                }
            },
            
            "south_indian_veg": {
                "id": "south_indian_veg",
                "name": "South Indian Vegetarian Thali",
                "region": "South India",
                "meal_type": "lunch_dinner",
                "estimated_calories": 680,
                "description": "Traditional South Indian vegetarian complete meal",
                "components": [
                    {
                        "type": "grains",
                        "items": ["1.5 cups rice", "1 small dosa OR 2 idli"],
                        "calories": 320,
                        "carbs": 68,
                        "protein": 7
                    },
                    {
                        "type": "proteins",
                        "items": ["1 katori sambar", "0.5 katori rasam", "0.5 katori curd"],
                        "calories": 180,
                        "protein": 12,
                        "carbs": 18
                    },
                    {
                        "type": "vegetables",
                        "items": ["1 katori poriyal/kootu", "small portion pickle"],
                        "calories": 130,
                        "carbs": 12,
                        "fiber": 6
                    },
                    {
                        "type": "accompaniments",
                        "items": ["coconut chutney", "1 papad", "curry leaves tempering"],
                        "calories": 50,
                        "fat": 4
                    }
                ],
                "nutrition_breakdown": {
                    "calories": 680,
                    "protein": 19,
                    "carbs": 98,
                    "fat": 20,
                    "fiber": 15
                },
                "cooking_notes": "Coconut oil usage, tamarind, curry leaves",
                "dietary_tags": ["vegetarian", "traditional", "fiber-rich"],
                "region_variations": {
                    "tamil": "More rice, extra rasam",
                    "karnataka": "Ragi mudde option",
                    "kerala": "Extra coconut, fish curry (non-veg)",
                    "andhra": "Spicier, more chili"
                }
            },
            
            "gujarati_thali": {
                "id": "gujarati_thali",
                "name": "Gujarati Thali",
                "region": "Gujarat",
                "meal_type": "lunch_dinner",
                "estimated_calories": 720,
                "description": "Sweet and savory Gujarati complete meal",
                "components": [
                    {
                        "type": "grains",
                        "items": ["2 small rotis/thepla", "0.5 katori rice"],
                        "calories": 250,
                        "carbs": 50,
                        "protein": 8
                    },
                    {
                        "type": "proteins",
                        "items": ["1 katori dal", "0.5 katori kadhi", "0.5 katori curd"],
                        "calories": 220,
                        "protein": 15,
                        "carbs": 22
                    },
                    {
                        "type": "vegetables",
                        "items": ["1 katori bhaji/shaak", "0.5 katori farsan"],
                        "calories": 150,
                        "carbs": 18,
                        "fiber": 4
                    },
                    {
                        "type": "sweets",
                        "items": ["small piece jaggery/gud", "1 small sweet"],
                        "calories": 100,
                        "carbs": 25
                    }
                ],
                "nutrition_breakdown": {
                    "calories": 720,
                    "protein": 23,
                    "carbs": 115,
                    "fat": 22,
                    "fiber": 10
                },
                "cooking_notes": "Sweet-savory balance, minimal oil",
                "dietary_tags": ["vegetarian", "sweet-savory", "traditional"],
                "region_variations": {
                    "kathiawadi": "Spicier, more oil",
                    "kutchi": "Dry preparations",
                    "saurashtra": "Seafood additions (coastal)"
                }
            },
            
            "bengali_fish_thali": {
                "id": "bengali_fish_thali",
                "name": "Bengali Fish Thali",
                "region": "West Bengal",
                "meal_type": "lunch_dinner",
                "estimated_calories": 750,
                "description": "Traditional Bengali meal with fish",
                "components": [
                    {
                        "type": "grains",
                        "items": ["1.5 cups rice (bhaat)"],
                        "calories": 300,
                        "carbs": 65,
                        "protein": 6
                    },
                    {
                        "type": "proteins",
                        "items": ["1 piece fish curry", "1 katori dal", "0.5 katori doi (curd)"],
                        "calories": 280,
                        "protein": 25,
                        "carbs": 15
                    },
                    {
                        "type": "vegetables",
                        "items": ["1 katori mixed vegetable curry", "begun bhaja (fried eggplant)"],
                        "calories": 140,
                        "carbs": 15,
                        "fiber": 6
                    },
                    {
                        "type": "accompaniments",
                        "items": ["kasundi/pickle", "small sweet (mishti)"],
                        "calories": 30,
                        "carbs": 8
                    }
                ],
                "nutrition_breakdown": {
                    "calories": 750,
                    "protein": 31,
                    "carbs": 103,
                    "fat": 25,
                    "fiber": 12
                },
                "cooking_notes": "Mustard oil, panch phoron spices",
                "dietary_tags": ["fish", "traditional", "protein-rich"],
                "region_variations": {
                    "kolkata": "More sweets, street food influence",
                    "rural": "Simpler preparations, more vegetables"
                }
            },
            
            "punjabi_non_veg": {
                "id": "punjabi_non_veg",
                "name": "Punjabi Non-Vegetarian Thali",
                "region": "Punjab",
                "meal_type": "lunch_dinner",
                "estimated_calories": 850,
                "description": "Hearty Punjabi meal with meat",
                "components": [
                    {
                        "type": "grains",
                        "items": ["2 butter naan OR 3 rotis", "small portion rice"],
                        "calories": 350,
                        "carbs": 65,
                        "protein": 12
                    },
                    {
                        "type": "proteins",
                        "items": ["1 portion chicken curry", "1 katori dal makhani"],
                        "calories": 380,
                        "protein": 35,
                        "carbs": 20
                    },
                    {
                        "type": "vegetables",
                        "items": ["1 katori saag", "mixed vegetable curry"],
                        "calories": 100,
                        "carbs": 12,
                        "fiber": 5
                    },
                    {
                        "type": "dairy",
                        "items": ["lassi OR curd", "extra ghee/butter"],
                        "calories": 120,
                        "protein": 6,
                        "fat": 8
                    }
                ],
                "nutrition_breakdown": {
                    "calories": 850,
                    "protein": 53,
                    "carbs": 97,
                    "fat": 35,
                    "fiber": 8
                },
                "cooking_notes": "Rich in ghee/butter, cream-based curries",
                "dietary_tags": ["non-vegetarian", "protein-rich", "indulgent"],
                "region_variations": {
                    "amritsari": "More fried items, kulcha",
                    "rural": "Simpler preparations, more dairy"
                }
            },
            
            "maharashtrian_thali": {
                "id": "maharashtrian_thali",
                "name": "Maharashtrian Thali",
                "region": "Maharashtra",
                "meal_type": "lunch_dinner",
                "estimated_calories": 620,
                "description": "Traditional Maharashtrian complete meal",
                "components": [
                    {
                        "type": "grains",
                        "items": ["2 bhakri/roti", "0.5 katori rice"],
                        "calories": 280,
                        "carbs": 55,
                        "protein": 8
                    },
                    {
                        "type": "proteins",
                        "items": ["1 katori amti/dal", "0.5 katori buttermilk"],
                        "calories": 150,
                        "protein": 12,
                        "carbs": 18
                    },
                    {
                        "type": "vegetables",
                        "items": ["1 katori bhaji", "koshimbir (salad)"],
                        "calories": 120,
                        "carbs": 15,
                        "fiber": 6
                    },
                    {
                        "type": "accompaniments",
                        "items": ["pickle", "papad", "small portion ghee"],
                        "calories": 70,
                        "fat": 6
                    }
                ],
                "nutrition_breakdown": {
                    "calories": 620,
                    "protein": 20,
                    "carbs": 88,
                    "fat": 20,
                    "fiber": 12
                },
                "cooking_notes": "Minimal oil, traditional spices",
                "dietary_tags": ["vegetarian", "balanced", "traditional"],
                "region_variations": {
                    "konkan": "Coconut, fish preparations",
                    "vidarbha": "Spicier, different legumes"
                }
            },
            
            "rajasthani_thali": {
                "id": "rajasthani_thali",
                "name": "Rajasthani Thali",
                "region": "Rajasthan",
                "meal_type": "lunch_dinner",
                "estimated_calories": 780,
                "description": "Rich and flavorful Rajasthani meal",
                "components": [
                    {
                        "type": "grains",
                        "items": ["2 bajra roti", "1 wheat roti", "small portion rice"],
                        "calories": 320,
                        "carbs": 60,
                        "protein": 10
                    },
                    {
                        "type": "proteins",
                        "items": ["1 katori dal baati", "0.5 katori besan gatte"],
                        "calories": 300,
                        "protein": 18,
                        "carbs": 35
                    },
                    {
                        "type": "vegetables",
                        "items": ["1 katori ker sangri", "mixed vegetable curry"],
                        "calories": 120,
                        "carbs": 15,
                        "fiber": 5
                    },
                    {
                        "type": "accompaniments",
                        "items": ["extra ghee", "churma", "pickle"],
                        "calories": 140,
                        "fat": 12,
                        "carbs": 15
                    }
                ],
                "nutrition_breakdown": {
                    "calories": 780,
                    "protein": 28,
                    "carbs": 125,
                    "fat": 30,
                    "fiber": 10
                },
                "cooking_notes": "Rich in ghee, dry preparations",
                "dietary_tags": ["vegetarian", "rich", "traditional"],
                "region_variations": {
                    "marwari": "More sweets, richer preparations",
                    "mewar": "Royal cuisine influence"
                }
            },
            
            "kerala_sadya": {
                "id": "kerala_sadya",
                "name": "Kerala Sadya (Festival Meal)",
                "region": "Kerala",
                "meal_type": "lunch_special",
                "estimated_calories": 900,
                "description": "Traditional Kerala feast served on banana leaf",
                "components": [
                    {
                        "type": "grains",
                        "items": ["2 cups rice (different varieties)"],
                        "calories": 400,
                        "carbs": 85,
                        "protein": 8
                    },
                    {
                        "type": "curries",
                        "items": ["sambar", "rasam", "2-3 vegetable curries", "coconut curry"],
                        "calories": 300,
                        "protein": 15,
                        "carbs": 35
                    },
                    {
                        "type": "sides",
                        "items": ["avial", "thoran", "pickle", "papadam"],
                        "calories": 150,
                        "carbs": 20,
                        "fiber": 8
                    },
                    {
                        "type": "sweets",
                        "items": ["payasam", "banana", "jaggery preparation"],
                        "calories": 150,
                        "carbs": 35
                    }
                ],
                "nutrition_breakdown": {
                    "calories": 900,
                    "protein": 23,
                    "carbs": 175,
                    "fat": 25,
                    "fiber": 18
                },
                "cooking_notes": "Coconut oil, extensive use of coconut",
                "dietary_tags": ["vegetarian", "festival", "fiber-rich"],
                "region_variations": {
                    "malabar": "Different spice combinations",
                    "kochi": "Seafood additions for non-veg version"
                }
            }
        }
    
    def get_all_templates(self):
        """Get all thali templates"""
        return self.templates
    
    def get_template_by_id(self, template_id):
        """Get specific template by ID"""
        return self.templates.get(template_id, None)
    
    def get_templates_by_region(self, region):
        """Get templates for a specific region"""
        return {tid: template for tid, template in self.templates.items() 
                if template['region'].lower() == region.lower()}
    
    def get_vegetarian_templates(self):
        """Get only vegetarian thali templates"""
        return {tid: template for tid, template in self.templates.items() 
                if 'vegetarian' in template['dietary_tags']}
    
    def get_templates_by_meal_type(self, meal_type):
        """Get templates suitable for specific meal type"""
        return {tid: template for tid, template in self.templates.items() 
                if meal_type in template['meal_type']}
    
    def search_templates(self, query):
        """Search templates by name or description"""
        query = query.lower()
        results = {}
        
        for tid, template in self.templates.items():
            if (query in template['name'].lower() or 
                query in template['description'].lower() or
                query in template['region'].lower()):
                results[tid] = template
        
        return results
    
    def get_template_suggestions(self, user_preferences):
        """Get template suggestions based on user preferences"""
        suggestions = []
        
        # Get user's dietary preferences
        is_vegetarian = user_preferences.get('vegetarian', True)
        preferred_regions = user_preferences.get('regions', [])
        calorie_target = user_preferences.get('daily_calories', 2000)
        
        # Calculate meal calorie target (assuming lunch/dinner is 35% of daily calories)
        meal_calorie_target = calorie_target * 0.35
        
        for tid, template in self.templates.items():
            score = 0
            
            # Dietary preference match
            if is_vegetarian and 'vegetarian' in template['dietary_tags']:
                score += 3
            elif not is_vegetarian:
                score += 2
            
            # Region preference match
            if template['region'] in preferred_regions:
                score += 2
            
            # Calorie appropriateness (within 20% of target)
            calorie_diff = abs(template['estimated_calories'] - meal_calorie_target)
            if calorie_diff <= meal_calorie_target * 0.2:
                score += 2
            elif calorie_diff <= meal_calorie_target * 0.4:
                score += 1
            
            if score >= 2:  # Minimum score for suggestion
                suggestions.append({
                    'template_id': tid,
                    'template': template,
                    'match_score': score,
                    'calorie_match': calorie_diff <= meal_calorie_target * 0.2
                })
        
        # Sort by score
        suggestions.sort(key=lambda x: x['match_score'], reverse=True)
        return suggestions[:5]  # Return top 5 suggestions
    
    def customize_template(self, template_id, customizations):
        """Customize a template based on user preferences"""
        template = self.get_template_by_id(template_id)
        if not template:
            return None
        
        customized = template.copy()
        
        # Apply size multiplier
        size_multiplier = customizations.get('size_multiplier', 1.0)
        
        customized['estimated_calories'] = int(template['estimated_calories'] * size_multiplier)
        customized['nutrition_breakdown'] = {
            key: int(value * size_multiplier) if isinstance(value, (int, float)) else value
            for key, value in template['nutrition_breakdown'].items()
        }
        
        # Apply dietary modifications
        if customizations.get('extra_protein', False):
            customized['estimated_calories'] += 100
            customized['nutrition_breakdown']['protein'] += 15
        
        if customizations.get('less_oil', False):
            customized['estimated_calories'] -= 80
            customized['nutrition_breakdown']['fat'] -= 10
            customized['cooking_notes'] += " | Reduced oil preparation"
        
        if customizations.get('extra_vegetables', False):
            customized['estimated_calories'] += 50
            customized['nutrition_breakdown']['fiber'] += 5
        
        # Add customization notes
        customized['customizations'] = customizations
        customized['customized_at'] = datetime.now().isoformat()
        
        return customized
    
    def get_quick_templates(self):
        """Get simplified templates for quick selection"""
        quick_templates = {}
        
        for tid, template in self.templates.items():
            quick_templates[tid] = {
                'name': template['name'],
                'region': template['region'],
                'calories': template['estimated_calories'],
                'tags': template['dietary_tags'][:2],  # First 2 tags only
                'description_short': template['description'][:50] + "..." if len(template['description']) > 50 else template['description']
            }
        
        return quick_templates
    
    def calculate_template_nutrition_detailed(self, template_id, serving_size=1.0):
        """Calculate detailed nutrition for a template with serving adjustment"""
        template = self.get_template_by_id(template_id)
        if not template:
            return None
        
        base_nutrition = template['nutrition_breakdown']
        
        detailed_nutrition = {}
        for nutrient, value in base_nutrition.items():
            if isinstance(value, (int, float)):
                detailed_nutrition[nutrient] = round(value * serving_size, 1)
            else:
                detailed_nutrition[nutrient] = value
        
        # Add micronutrient estimates based on Indian food composition
        detailed_nutrition.update({
            'iron_mg': round(detailed_nutrition.get('calories', 0) * 0.015, 1),  # Estimate
            'calcium_mg': round(detailed_nutrition.get('calories', 0) * 0.8, 1),  # Estimate
            'vitamin_c_mg': round(detailed_nutrition.get('calories', 0) * 0.05, 1),  # Estimate
            'folate_mcg': round(detailed_nutrition.get('calories', 0) * 0.3, 1)  # Estimate
        })
        
        return detailed_nutrition
    
    def export_template_for_meal_log(self, template_id, serving_size=1.0, meal_category="Lunch"):
        """Export template in format suitable for meal logging"""
        template = self.get_template_by_id(template_id)
        if not template:
            return None
        
        nutrition = self.calculate_template_nutrition_detailed(template_id, serving_size)
        
        return {
            "date": datetime.now().date().isoformat(),
            "time": datetime.now().strftime("%H:%M"),
            "meal_category": meal_category,
            "food_name": f"{template['name']} ({serving_size}x)",
            "portion": "1 complete thali",
            "calories": nutrition['calories'],
            "protein": nutrition['protein'],
            "carbs": nutrition['carbs'],
            "fat": nutrition['fat'],
            "fiber": nutrition['fiber'],
            "source": "thali_template",
            "template_id": template_id,
            "serving_multiplier": serving_size,
            "region": template['region'],
            "components": [comp['items'] for comp in template['components']]
        }
