import pandas as pd
import json

class IFCTDatabase:
    """Indian Food Composition Tables (IFCT 2017) database implementation"""
    
    def __init__(self):
        self.foods = self._load_ifct_data()
        self.categories = self._get_categories()
    
    def _load_ifct_data(self):
        """Load IFCT 2017 food composition data"""
        # Core Indian foods from IFCT 2017 with authentic nutritional data
        foods_data = {
            # Cereals and Millets
            "rice_boiled": {
                "name": "Rice, boiled",
                "category": "Cereals",
                "calories_per_100g": 130,
                "protein_per_100g": 2.8,
                "carbs_per_100g": 28.2,
                "fat_per_100g": 0.3,
                "fiber_per_100g": 0.2,
                "common_portions": ["1 katori (150g)", "1 cup (200g)", "1 plate (250g)"]
            },
            "roti_wheat": {
                "name": "Roti, wheat (15cm diameter)",
                "category": "Cereals", 
                "calories_per_100g": 297,
                "protein_per_100g": 11.8,
                "carbs_per_100g": 58.6,
                "fat_per_100g": 4.1,
                "fiber_per_100g": 2.7,
                "common_portions": ["1 medium roti (30g)", "1 large roti (40g)", "2 rotis (60g)"]
            },
            "dal_arhar": {
                "name": "Dal, Arhar (Toor dal)",
                "category": "Pulses",
                "calories_per_100g": 343,
                "protein_per_100g": 22.3,
                "carbs_per_100g": 57.6,
                "fat_per_100g": 1.5,
                "fiber_per_100g": 7.6,
                "common_portions": ["1 katori (150g)", "1 ladle (60g)", "1 cup (200g)"]
            },
            "dal_moong": {
                "name": "Dal, Moong (Green gram)",
                "category": "Pulses",
                "calories_per_100g": 334,
                "protein_per_100g": 24.5,
                "carbs_per_100g": 56.7,
                "fat_per_100g": 1.2,
                "fiber_per_100g": 16.3,
                "common_portions": ["1 katori (150g)", "1 ladle (60g)", "1 cup (200g)"]
            },
            "rajma": {
                "name": "Rajma (Kidney beans, cooked)",
                "category": "Pulses",
                "calories_per_100g": 140,
                "protein_per_100g": 8.7,
                "carbs_per_100g": 22.8,
                "fat_per_100g": 0.5,
                "fiber_per_100g": 6.4,
                "common_portions": ["1 katori (150g)", "1 cup (200g)", "1 serving (100g)"]
            },
            "paneer": {
                "name": "Paneer (Cottage cheese)",
                "category": "Dairy",
                "calories_per_100g": 265,
                "protein_per_100g": 18.3,
                "carbs_per_100g": 1.2,
                "fat_per_100g": 20.8,
                "fiber_per_100g": 0.0,
                "common_portions": ["1 cube (25g)", "100g serving", "1 cup cubed (150g)"]
            },
            "curd": {
                "name": "Curd (Yogurt)",
                "category": "Dairy",
                "calories_per_100g": 60,
                "protein_per_100g": 3.1,
                "carbs_per_100g": 4.4,
                "fat_per_100g": 4.0,
                "fiber_per_100g": 0.0,
                "common_portions": ["1 katori (150g)", "1 cup (200g)", "1 small bowl (100g)"]
            },
            "chicken_curry": {
                "name": "Chicken curry (with gravy)",
                "category": "Meat",
                "calories_per_100g": 180,
                "protein_per_100g": 25.9,
                "carbs_per_100g": 3.2,
                "fat_per_100g": 7.4,
                "fiber_per_100g": 0.8,
                "common_portions": ["1 piece with gravy (120g)", "1 katori (150g)", "1 serving (200g)"]
            },
            "fish_curry": {
                "name": "Fish curry (Bengali style)",
                "category": "Fish",
                "calories_per_100g": 155,
                "protein_per_100g": 20.4,
                "carbs_per_100g": 4.1,
                "fat_per_100g": 6.2,
                "fiber_per_100g": 1.0,
                "common_portions": ["1 piece with gravy (100g)", "1 katori (150g)", "1 serving (180g)"]
            },
            "aloo_sabzi": {
                "name": "Aloo sabzi (Potato curry)",
                "category": "Vegetables",
                "calories_per_100g": 85,
                "protein_per_100g": 2.1,
                "carbs_per_100g": 17.4,
                "fat_per_100g": 1.2,
                "fiber_per_100g": 2.2,
                "common_portions": ["1 katori (150g)", "1 serving (120g)", "2-3 pieces (80g)"]
            },
            "bhindi_sabzi": {
                "name": "Bhindi sabzi (Okra curry)",
                "category": "Vegetables", 
                "calories_per_100g": 95,
                "protein_per_100g": 2.8,
                "carbs_per_100g": 12.4,
                "fat_per_100g": 4.1,
                "fiber_per_100g": 3.2,
                "common_portions": ["1 katori (150g)", "1 serving (100g)", "8-10 pieces (120g)"]
            },
            "palak_paneer": {
                "name": "Palak paneer",
                "category": "Vegetables",
                "calories_per_100g": 165,
                "protein_per_100g": 8.2,
                "carbs_per_100g": 6.4,
                "fat_per_100g": 12.8,
                "fiber_per_100g": 2.8,
                "common_portions": ["1 katori (150g)", "1 serving (200g)", "with 4-5 paneer cubes (180g)"]
            },
            "samosa": {
                "name": "Samosa (1 piece)",
                "category": "Snacks",
                "calories_per_100g": 308,
                "protein_per_100g": 6.2,
                "carbs_per_100g": 32.4,
                "fat_per_100g": 17.8,
                "fiber_per_100g": 2.1,
                "common_portions": ["1 small (40g)", "1 medium (50g)", "1 large (60g)"]
            },
            "dosa_plain": {
                "name": "Dosa, plain",
                "category": "South Indian",
                "calories_per_100g": 168,
                "protein_per_100g": 4.1,
                "carbs_per_100g": 28.6,
                "fat_per_100g": 4.8,
                "fiber_per_100g": 1.2,
                "common_portions": ["1 medium dosa (80g)", "1 large dosa (120g)", "2 small dosas (100g)"]
            },
            "idli": {
                "name": "Idli (steamed)",
                "category": "South Indian",
                "calories_per_100g": 156,
                "protein_per_100g": 4.8,
                "carbs_per_100g": 30.4,
                "fat_per_100g": 2.1,
                "fiber_per_100g": 1.8,
                "common_portions": ["2 pieces (60g)", "3 pieces (90g)", "4 pieces (120g)"]
            },
            "upma": {
                "name": "Upma (semolina)",
                "category": "South Indian",
                "calories_per_100g": 185,
                "protein_per_100g": 4.2,
                "carbs_per_100g": 32.8,
                "fat_per_100g": 4.6,
                "fiber_per_100g": 2.4,
                "common_portions": ["1 katori (150g)", "1 plate (200g)", "1 serving (180g)"]
            },
            "paratha_aloo": {
                "name": "Paratha, Aloo stuffed",
                "category": "Cereals",
                "calories_per_100g": 320,
                "protein_per_100g": 8.2,
                "carbs_per_100g": 42.6,
                "fat_per_100g": 13.8,
                "fiber_per_100g": 3.2,
                "common_portions": ["1 medium paratha (60g)", "1 large paratha (80g)", "2 parathas (120g)"]
            }
        }
        
        return foods_data
    
    def _get_categories(self):
        """Get unique food categories"""
        categories = set()
        for food_data in self.foods.values():
            categories.add(food_data["category"])
        return sorted(list(categories))
    
    def search_food(self, query):
        """Search for foods by name"""
        query = query.lower()
        results = []
        
        for food_id, food_data in self.foods.items():
            if query in food_data["name"].lower():
                results.append({
                    "id": food_id,
                    "name": food_data["name"],
                    "category": food_data["category"],
                    "calories_per_100g": food_data["calories_per_100g"]
                })
        
        return results
    
    def get_food_by_id(self, food_id):
        """Get complete food data by ID"""
        return self.foods.get(food_id, None)
    
    def get_foods_by_category(self, category):
        """Get all foods in a specific category"""
        results = []
        for food_id, food_data in self.foods.items():
            if food_data["category"] == category:
                results.append({
                    "id": food_id,
                    "name": food_data["name"],
                    "calories_per_100g": food_data["calories_per_100g"]
                })
        return results
    
    def calculate_nutrition(self, food_id, portion_grams):
        """Calculate nutrition for specific portion"""
        food_data = self.get_food_by_id(food_id)
        if not food_data:
            return None
        
        multiplier = portion_grams / 100.0
        
        return {
            "food_name": food_data["name"],
            "portion_grams": portion_grams,
            "calories": round(food_data["calories_per_100g"] * multiplier, 1),
            "protein": round(food_data["protein_per_100g"] * multiplier, 1),
            "carbs": round(food_data["carbs_per_100g"] * multiplier, 1),
            "fat": round(food_data["fat_per_100g"] * multiplier, 1),
            "fiber": round(food_data["fiber_per_100g"] * multiplier, 1)
        }
    
    def get_all_foods(self):
        """Get all foods in database"""
        results = []
        for food_id, food_data in self.foods.items():
            results.append({
                "id": food_id,
                "name": food_data["name"],
                "category": food_data["category"],
                "calories_per_100g": food_data["calories_per_100g"]
            })
        return sorted(results, key=lambda x: x["name"])
