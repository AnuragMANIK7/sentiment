class IndianPortions:
    """Standardized Indian portion measurements with regional variations"""
    
    def __init__(self):
        self.portion_definitions = self._load_portion_data()
    
    def _load_portion_data(self):
        """Load standardized Indian portion measurements"""
        return {
            # Basic utensils and containers
            "katori": {
                "name": "Katori (Small Bowl)",
                "ml_range": (120, 200),
                "standard_ml": 150,
                "description": "Traditional small serving bowl for dal, sabzi, rice",
                "regional_notes": "North: 150ml, South: 180ml, East: 160ml",
                "common_foods": ["dal", "sabzi", "rice", "curd"]
            },
            "ladle": {
                "name": "Ladle (Serving Spoon)",
                "ml_range": (45, 80),
                "standard_ml": 60,
                "description": "Standard serving ladle for curry/dal",
                "regional_notes": "Varies by household, typically 60ml",
                "common_foods": ["dal", "curry", "rasam", "sambar"]
            },
            "cup": {
                "name": "Cup (Standard)",
                "ml_range": (200, 250),
                "standard_ml": 240,
                "description": "Standard tea/coffee cup measurement",
                "regional_notes": "International standard, used for liquids",
                "common_foods": ["milk", "water", "tea", "coffee"]
            },
            
            # Bread measurements
            "roti_small": {
                "name": "Roti (Small)",
                "diameter_cm": 12,
                "weight_grams": 25,
                "description": "Small roti, common in households",
                "thickness_mm": 2
            },
            "roti_medium": {
                "name": "Roti (Medium)",
                "diameter_cm": 15,
                "weight_grams": 35,
                "description": "Standard roti size",
                "thickness_mm": 2
            },
            "roti_large": {
                "name": "Roti (Large)",
                "diameter_cm": 18,
                "weight_grams": 45,
                "description": "Large roti, restaurant style",
                "thickness_mm": 2
            },
            "paratha_medium": {
                "name": "Paratha (Medium)",
                "diameter_cm": 15,
                "weight_grams": 60,
                "description": "Stuffed paratha, medium size",
                "thickness_mm": 4
            },
            
            # South Indian items
            "dosa_small": {
                "name": "Dosa (Small)",
                "diameter_cm": 20,
                "weight_grams": 70,
                "description": "Small dosa, breakfast portion"
            },
            "dosa_medium": {
                "name": "Dosa (Medium)",
                "diameter_cm": 25,
                "weight_grams": 90,
                "description": "Standard restaurant dosa"
            },
            "dosa_large": {
                "name": "Dosa (Large/Masala)",
                "diameter_cm": 30,
                "weight_grams": 120,
                "description": "Large masala dosa"
            },
            "idli_piece": {
                "name": "Idli (1 piece)",
                "diameter_cm": 6,
                "weight_grams": 30,
                "description": "Standard idli piece"
            },
            
            # Spoon measurements (for oils, ghee, etc.)
            "tsp": {
                "name": "Teaspoon",
                "ml": 5,
                "grams_oil": 4.5,
                "description": "Standard teaspoon measurement"
            },
            "tbsp": {
                "name": "Tablespoon", 
                "ml": 15,
                "grams_oil": 13.5,
                "description": "Standard tablespoon measurement"
            },
            
            # Hand measurements (traditional)
            "handful": {
                "name": "Handful",
                "description": "Amount that fits in cupped palm",
                "weight_range_grams": (30, 50),
                "common_foods": ["nuts", "dried fruits", "peanuts"]
            },
            "pinch": {
                "name": "Pinch",
                "description": "Amount between thumb and forefinger",
                "weight_grams": 0.5,
                "common_foods": ["salt", "spices", "hing"]
            }
        }
    
    def get_portion_options(self, food_category=None):
        """Get relevant portion options for a food category"""
        if food_category == "Cereals":
            return ["roti_small", "roti_medium", "roti_large", "paratha_medium", "katori", "cup"]
        elif food_category == "South Indian":
            return ["dosa_small", "dosa_medium", "dosa_large", "idli_piece", "katori"]
        elif food_category in ["Pulses", "Vegetables", "Curry"]:
            return ["katori", "ladle", "cup"]
        elif food_category == "Dairy":
            return ["katori", "cup", "handful"]
        else:
            return ["katori", "cup", "handful", "tsp", "tbsp"]
    
    def convert_portion_to_grams(self, portion_id, quantity=1, custom_ml=None):
        """Convert portion measurement to grams"""
        portion_data = self.portion_definitions.get(portion_id)
        if not portion_data:
            return None
        
        if portion_id in ["roti_small", "roti_medium", "roti_large", "paratha_medium"]:
            return portion_data["weight_grams"] * quantity
        elif portion_id in ["dosa_small", "dosa_medium", "dosa_large", "idli_piece"]:
            return portion_data["weight_grams"] * quantity
        elif portion_id in ["katori", "ladle", "cup"]:
            ml_volume = custom_ml if custom_ml else portion_data["standard_ml"]
            # Assuming density similar to water for liquid foods
            # For solid foods like rice, adjust density (rice ~0.75g/ml when cooked)
            return ml_volume * 0.8 * quantity  # Average density for Indian foods
        elif portion_id in ["tsp", "tbsp"]:
            return portion_data.get("grams_oil", portion_data["ml"]) * quantity
        elif portion_id == "handful":
            return portion_data["weight_range_grams"][0] * quantity
        elif portion_id == "pinch":
            return portion_data["weight_grams"] * quantity
        
        return 100 * quantity  # Default fallback
    
    def get_portion_description(self, portion_id):
        """Get description and details for a portion"""
        portion_data = self.portion_definitions.get(portion_id)
        if not portion_data:
            return "Unknown portion"
        
        description = f"{portion_data['name']}: {portion_data['description']}"
        
        if "regional_notes" in portion_data:
            description += f"\n📍 Regional variations: {portion_data['regional_notes']}"
        
        if "ml_range" in portion_data:
            description += f"\n📏 Volume range: {portion_data['ml_range'][0]}-{portion_data['ml_range'][1]}ml"
        
        if "weight_grams" in portion_data:
            description += f"\n⚖️ Weight: ~{portion_data['weight_grams']}g"
        
        return description
    
    def get_household_adjustment_factor(self, portion_id, household_defaults):
        """Calculate adjustment factor based on household defaults"""
        if not household_defaults:
            return 1.0
        
        if portion_id == "katori" and "katori_ml" in household_defaults:
            standard_ml = self.portion_definitions["katori"]["standard_ml"]
            return household_defaults["katori_ml"] / standard_ml
        elif portion_id == "ladle" and "ladle_ml" in household_defaults:
            standard_ml = self.portion_definitions["ladle"]["standard_ml"] 
            return household_defaults["ladle_ml"] / standard_ml
        elif "roti" in portion_id and "roti_diameter" in household_defaults:
            # Adjust roti weight based on diameter (area scales with diameter²)
            if portion_id == "roti_medium":
                standard_diameter = self.portion_definitions["roti_medium"]["diameter_cm"]
                user_diameter = household_defaults["roti_diameter"]
                return (user_diameter / standard_diameter) ** 2
        
        return 1.0
    
    def get_oil_ghee_options(self):
        """Get oil and ghee measurement options for cooking adjustments"""
        return {
            "oil_levels": [
                {"label": "No added oil", "tsp": 0, "calories": 0},
                {"label": "Light oil (½ tsp)", "tsp": 0.5, "calories": 20},
                {"label": "Normal oil (1 tsp)", "tsp": 1, "calories": 40},
                {"label": "Medium oil (1½ tsp)", "tsp": 1.5, "calories": 60},
                {"label": "Heavy oil (2 tsp)", "tsp": 2, "calories": 80},
                {"label": "Very heavy oil (3 tsp)", "tsp": 3, "calories": 120},
                {"label": "Restaurant style (4 tsp)", "tsp": 4, "calories": 160}
            ],
            "ghee_levels": [
                {"label": "No ghee", "tsp": 0, "calories": 0},
                {"label": "Light ghee (½ tsp)", "tsp": 0.5, "calories": 22},
                {"label": "Normal ghee (1 tsp)", "tsp": 1, "calories": 45},
                {"label": "Heavy ghee (1½ tsp)", "tsp": 1.5, "calories": 67},
                {"label": "Very heavy ghee (2 tsp)", "tsp": 2, "calories": 90}
            ]
        }
