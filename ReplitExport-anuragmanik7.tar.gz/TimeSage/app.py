import streamlit as st
import os
from datetime import datetime, date
import pandas as pd
from components.photo_uploader import PhotoUploader
from components.macro_dashboard import MacroDashboard
from components.meal_logger import MealLogger
from components.gentle_mode import GentleMode
from services.ai_food_analyzer import AIFoodAnalyzer
from services.recipe_builder import RecipeBuilder
from utils.storage import UserStorage
from data.ifct_database import IFCTDatabase
from data.indian_portions import IndianPortions

# Page configuration
st.set_page_config(
    page_title="CAL AI - Indian Calorie Tracker",
    page_icon="🍛",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'user_data' not in st.session_state:
    st.session_state.user_data = {
        'daily_calories': 2000,
        'daily_protein': 150,
        'daily_carbs': 250,
        'daily_fat': 67,
        'gentle_mode': False,
        'household_defaults': {},
        'logged_meals': [],
        'user_profile': {}
    }

if 'storage' not in st.session_state:
    st.session_state.storage = UserStorage()

if 'ai_analyzer' not in st.session_state:
    st.session_state.ai_analyzer = AIFoodAnalyzer()

if 'ifct_db' not in st.session_state:
    st.session_state.ifct_db = IFCTDatabase()

if 'portions' not in st.session_state:
    st.session_state.portions = IndianPortions()

def main():
    # Header
    st.title("🍛 CAL AI - Smart Indian Calorie Tracker")
    st.markdown("*AI-powered nutrition tracking optimized for Indian cuisine*")
    
    # Sidebar for user settings
    with st.sidebar:
        st.header("⚙️ Settings")
        
        # User Profile Setup
        with st.expander("👤 User Profile", expanded=False):
            age = st.number_input("Age", min_value=15, max_value=100, value=30)
            weight = st.number_input("Weight (kg)", min_value=30.0, max_value=200.0, value=70.0)
            height = st.number_input("Height (cm)", min_value=100, max_value=250, value=170)
            activity_level = st.selectbox("Activity Level", 
                ["Sedentary", "Lightly Active", "Moderately Active", "Very Active", "Extremely Active"])
            goal = st.selectbox("Goal", ["Maintain Weight", "Lose Weight", "Gain Weight"])
            
            if st.button("Update Profile"):
                st.session_state.user_data['user_profile'] = {
                    'age': age, 'weight': weight, 'height': height,
                    'activity_level': activity_level, 'goal': goal
                }
                # Calculate daily targets based on profile
                bmr = calculate_bmr(weight, height, age)
                tdee = calculate_tdee(bmr, activity_level)
                targets = calculate_targets(tdee, goal)
                st.session_state.user_data.update(targets)
                st.success("Profile updated!")
                st.rerun()
        
        # Gentle Mode Toggle
        st.session_state.user_data['gentle_mode'] = st.toggle(
            "🧘 Gentle Mode", 
            value=st.session_state.user_data['gentle_mode'],
            help="Show ranges instead of exact numbers, focus on habits over perfection"
        )
        
        # Household Defaults
        with st.expander("🏠 Household Measurement Defaults"):
            st.markdown("Set your household-specific portion sizes:")
            katori_ml = st.slider("Your Katori (ml)", 100, 300, 180)
            roti_diameter = st.slider("Your Roti Diameter (cm)", 12, 20, 15)
            ladle_ml = st.slider("Your Ladle (ml)", 30, 100, 60)
            
            st.session_state.user_data['household_defaults'] = {
                'katori_ml': katori_ml,
                'roti_diameter': roti_diameter,
                'ladle_ml': ladle_ml
            }
    
    # Main content tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Dashboard", "📸 Photo Logger", "🍽️ Manual Logger", "🍲 Recipe Builder", "📈 Analytics"
    ])
    
    with tab1:
        # Dashboard with macro rings and today's summary
        dashboard = MacroDashboard()
        dashboard.render(st.session_state.user_data)
    
    with tab2:
        # Photo-based food logging
        photo_uploader = PhotoUploader(st.session_state.ai_analyzer)
        photo_uploader.render()
    
    with tab3:
        # Manual meal logging with IFCT database
        meal_logger = MealLogger(st.session_state.ifct_db, st.session_state.portions)
        meal_logger.render()
    
    with tab4:
        # Recipe builder for home-cooked dishes
        recipe_builder = RecipeBuilder(st.session_state.ifct_db)
        recipe_builder.render()
    
    with tab5:
        # Analytics and trends
        render_analytics()

def calculate_bmr(weight, height, age, gender="male"):
    """Calculate Basal Metabolic Rate using Mifflin-St Jeor Equation"""
    if gender.lower() == "male":
        return (10 * weight) + (6.25 * height) - (5 * age) + 5
    else:
        return (10 * weight) + (6.25 * height) - (5 * age) - 161

def calculate_tdee(bmr, activity_level):
    """Calculate Total Daily Energy Expenditure"""
    multipliers = {
        "Sedentary": 1.2,
        "Lightly Active": 1.375,
        "Moderately Active": 1.55,
        "Very Active": 1.725,
        "Extremely Active": 1.9
    }
    return int(bmr * multipliers[activity_level])

def calculate_targets(tdee, goal):
    """Calculate daily macro targets based on TDEE and goal"""
    if goal == "Lose Weight":
        calories = tdee - 500  # 500 cal deficit
    elif goal == "Gain Weight":
        calories = tdee + 500  # 500 cal surplus
    else:
        calories = tdee
    
    # Indian diet macro distribution: Higher carbs (55%), moderate protein (15%), fat (30%)
    protein = int((calories * 0.15) / 4)  # 4 cal per gram
    carbs = int((calories * 0.55) / 4)    # 4 cal per gram
    fat = int((calories * 0.30) / 9)      # 9 cal per gram
    
    return {
        'daily_calories': calories,
        'daily_protein': protein,
        'daily_carbs': carbs,
        'daily_fat': fat
    }

def render_analytics():
    """Render analytics and trends page"""
    st.header("📈 Your Nutrition Analytics")
    
    if not st.session_state.user_data['logged_meals']:
        st.info("Start logging meals to see your nutrition trends and insights!")
        return
    
    # Get recent meals data
    meals_df = pd.DataFrame(st.session_state.user_data['logged_meals'])
    
    if len(meals_df) > 0:
        # Weekly summary
        st.subheader("📅 Weekly Summary")
        weekly_data = meals_df.groupby(meals_df['date']).agg({
            'calories': 'sum',
            'protein': 'sum',
            'carbs': 'sum',
            'fat': 'sum'
        }).tail(7)
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Avg Daily Calories", f"{int(weekly_data['calories'].mean())}")
        with col2:
            st.metric("Avg Daily Protein", f"{int(weekly_data['protein'].mean())}g")
        with col3:
            st.metric("Avg Daily Carbs", f"{int(weekly_data['carbs'].mean())}g")
        with col4:
            st.metric("Avg Daily Fat", f"{int(weekly_data['fat'].mean())}g")
        
        # Most logged foods
        st.subheader("🍽️ Your Favorite Foods")
        food_counts = meals_df['food_name'].value_counts().head(10)
        st.bar_chart(food_counts)
        
        # Meal timing patterns
        st.subheader("⏰ Meal Timing Patterns")
        if 'time' in meals_df.columns:
            meals_df['hour'] = pd.to_datetime(meals_df['time']).dt.hour
            hourly_meals = meals_df['hour'].value_counts().sort_index()
            st.line_chart(hourly_meals)
    
    # Nutrition insights
    st.subheader("💡 Personalized Insights")
    st.info("🌾 **Indian Diet Tip**: Your diet shows good carb intake from rice/roti. Consider adding more protein from dal and paneer.")
    st.info("🥛 **Hydration**: Don't forget to drink water with meals, especially with spicy Indian foods!")
    st.info("🕐 **Timing**: Traditional Indian eating patterns suggest lighter dinners. Consider shifting calories earlier in the day.")

if __name__ == "__main__":
    main()
