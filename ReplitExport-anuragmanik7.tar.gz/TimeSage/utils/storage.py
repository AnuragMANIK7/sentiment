import json
import os
from datetime import datetime, date
import streamlit as st

class UserStorage:
    """User data storage and management utilities"""
    
    def __init__(self):
        self.storage_dir = ".storage"
        self.ensure_storage_directory()
    
    def ensure_storage_directory(self):
        """Ensure storage directory exists"""
        if not os.path.exists(self.storage_dir):
            os.makedirs(self.storage_dir)
    
    def save_user_data(self, user_id, data):
        """Save user data to file"""
        try:
            # Convert dates to strings for JSON serialization
            serialized_data = self._serialize_data(data)
            
            file_path = os.path.join(self.storage_dir, f"user_{user_id}.json")
            
            with open(file_path, 'w') as f:
                json.dump(serialized_data, f, indent=2, default=str)
            
            return True
            
        except Exception as e:
            st.error(f"Error saving user data: {str(e)}")
            return False
    
    def load_user_data(self, user_id):
        """Load user data from file"""
        try:
            file_path = os.path.join(self.storage_dir, f"user_{user_id}.json")
            
            if not os.path.exists(file_path):
                return self._get_default_user_data()
            
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            # Deserialize data
            return self._deserialize_data(data)
            
        except Exception as e:
            st.error(f"Error loading user data: {str(e)}")
            return self._get_default_user_data()
    
    def backup_user_data(self, user_id):
        """Create a backup of user data"""
        try:
            current_data = self.load_user_data(user_id)
            
            backup_filename = f"backup_user_{user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            backup_path = os.path.join(self.storage_dir, backup_filename)
            
            serialized_data = self._serialize_data(current_data)
            
            with open(backup_path, 'w') as f:
                json.dump(serialized_data, f, indent=2, default=str)
            
            return backup_path
            
        except Exception as e:
            st.error(f"Error creating backup: {str(e)}")
            return None
    
    def export_user_data(self, user_id, format='json'):
        """Export user data in various formats"""
        try:
            data = self.load_user_data(user_id)
            
            if format == 'json':
                return self._export_json(data)
            elif format == 'csv':
                return self._export_csv(data)
            else:
                raise ValueError(f"Unsupported format: {format}")
                
        except Exception as e:
            st.error(f"Error exporting data: {str(e)}")
            return None
    
    def import_user_data(self, user_id, file_content, format='json'):
        """Import user data from file"""
        try:
            if format == 'json':
                data = json.loads(file_content)
                data = self._deserialize_data(data)
            else:
                raise ValueError(f"Unsupported import format: {format}")
            
            # Validate data structure
            if self._validate_user_data(data):
                self.save_user_data(user_id, data)
                return True
            else:
                st.error("Invalid data structure in import file")
                return False
                
        except Exception as e:
            st.error(f"Error importing data: {str(e)}")
            return False
    
    def get_user_statistics(self, user_id):
        """Get user statistics and insights"""
        try:
            data = self.load_user_data(user_id)
            
            meals = data.get('logged_meals', [])
            
            if not meals:
                return {
                    'total_meals': 0,
                    'total_days': 0,
                    'avg_calories_per_day': 0,
                    'most_common_food': 'None',
                    'first_log_date': None,
                    'last_log_date': None
                }
            
            # Calculate statistics
            total_meals = len(meals)
            
            # Get unique dates
            dates = set()
            total_calories = 0
            food_counts = {}
            
            for meal in meals:
                dates.add(meal.get('date', ''))
                total_calories += meal.get('calories', 0)
                
                food_name = meal.get('food_name', 'Unknown')
                food_counts[food_name] = food_counts.get(food_name, 0) + 1
            
            total_days = len(dates)
            avg_calories_per_day = total_calories / total_days if total_days > 0 else 0
            
            # Most common food
            most_common_food = max(food_counts.items(), key=lambda x: x[1])[0] if food_counts else 'None'
            
            # Date range
            sorted_dates = sorted([d for d in dates if d])
            first_log_date = sorted_dates[0] if sorted_dates else None
            last_log_date = sorted_dates[-1] if sorted_dates else None
            
            return {
                'total_meals': total_meals,
                'total_days': total_days,
                'avg_calories_per_day': round(avg_calories_per_day, 1),
                'most_common_food': most_common_food,
                'first_log_date': first_log_date,
                'last_log_date': last_log_date,
                'food_variety': len(food_counts),
                'top_foods': sorted(food_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            }
            
        except Exception as e:
            st.error(f"Error calculating statistics: {str(e)}")
            return {}
    
    def cleanup_old_data(self, days_to_keep=90):
        """Clean up old meal data to save space"""
        try:
            cutoff_date = (datetime.now().date() - timedelta(days=days_to_keep)).isoformat()
            
            for filename in os.listdir(self.storage_dir):
                if filename.startswith('user_') and filename.endswith('.json'):
                    file_path = os.path.join(self.storage_dir, filename)
                    
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                    
                    # Filter out old meals
                    meals = data.get('logged_meals', [])
                    filtered_meals = [meal for meal in meals if meal.get('date', '') >= cutoff_date]
                    
                    if len(filtered_meals) != len(meals):
                        data['logged_meals'] = filtered_meals
                        
                        with open(file_path, 'w') as f:
                            json.dump(data, f, indent=2, default=str)
                        
                        removed_count = len(meals) - len(filtered_meals)
                        st.info(f"Cleaned up {removed_count} old meal entries from {filename}")
            
            return True
            
        except Exception as e:
            st.error(f"Error during cleanup: {str(e)}")
            return False
    
    def _serialize_data(self, data):
        """Serialize data for JSON storage"""
        serialized = data.copy()
        
        # Handle any date objects
        if 'logged_meals' in serialized:
            for meal in serialized['logged_meals']:
                for key, value in meal.items():
                    if isinstance(value, (date, datetime)):
                        meal[key] = value.isoformat()
        
        return serialized
    
    def _deserialize_data(self, data):
        """Deserialize data from JSON storage"""
        # Data is already in the correct format for our use case
        return data
    
    def _get_default_user_data(self):
        """Get default user data structure"""
        return {
            'daily_calories': 2000,
            'daily_protein': 150,
            'daily_carbs': 250,
            'daily_fat': 67,
            'gentle_mode': False,
            'household_defaults': {
                'katori_ml': 150,
                'roti_diameter': 15,
                'ladle_ml': 60
            },
            'logged_meals': [],
            'user_profile': {},
            'favorite_foods': [],
            'saved_meals': [],
            'preferences': {
                'units': 'metric',
                'theme': 'light',
                'notifications': True
            }
        }
    
    def _validate_user_data(self, data):
        """Validate user data structure"""
        required_keys = ['daily_calories', 'daily_protein', 'daily_carbs', 'daily_fat', 'logged_meals']
        
        for key in required_keys:
            if key not in data:
                return False
        
        # Validate logged_meals structure
        if not isinstance(data['logged_meals'], list):
            return False
        
        for meal in data['logged_meals']:
            if not isinstance(meal, dict):
                return False
            
            meal_required_keys = ['food_name', 'calories', 'date']
            for meal_key in meal_required_keys:
                if meal_key not in meal:
                    return False
        
        return True
    
    def _export_json(self, data):
        """Export data as JSON"""
        serialized_data = self._serialize_data(data)
        return json.dumps(serialized_data, indent=2, default=str)
    
    def _export_csv(self, data):
        """Export meal data as CSV"""
        import csv
        from io import StringIO
        
        output = StringIO()
        
        meals = data.get('logged_meals', [])
        
        if not meals:
            return "date,time,meal_category,food_name,portion,calories,protein,carbs,fat\n"
        
        fieldnames = ['date', 'time', 'meal_category', 'food_name', 'portion', 'calories', 'protein', 'carbs', 'fat']
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        
        writer.writeheader()
        
        for meal in meals:
            row = {field: meal.get(field, '') for field in fieldnames}
            writer.writerow(row)
        
        return output.getvalue()
    
    def sync_session_to_storage(self, user_id="default"):
        """Sync session state data to persistent storage"""
        if 'user_data' in st.session_state:
            self.save_user_data(user_id, st.session_state.user_data)
    
    def load_storage_to_session(self, user_id="default"):
        """Load data from storage to session state"""
        stored_data = self.load_user_data(user_id)
        
        if 'user_data' not in st.session_state:
            st.session_state.user_data = {}
        
        # Merge stored data with session data
        for key, value in stored_data.items():
            if key not in st.session_state.user_data:
                st.session_state.user_data[key] = value
    
    def get_storage_info(self):
        """Get information about storage usage"""
        try:
            total_size = 0
            file_count = 0
            
            for filename in os.listdir(self.storage_dir):
                if filename.endswith('.json'):
                    file_path = os.path.join(self.storage_dir, filename)
                    total_size += os.path.getsize(file_path)
                    file_count += 1
            
            return {
                'total_files': file_count,
                'total_size_mb': round(total_size / (1024 * 1024), 2),
                'storage_directory': self.storage_dir
            }
            
        except Exception as e:
            st.error(f"Error getting storage info: {str(e)}")
            return {}
